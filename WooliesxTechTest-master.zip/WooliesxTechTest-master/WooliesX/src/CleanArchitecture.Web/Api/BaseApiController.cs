﻿using Microsoft.AspNetCore.Mvc;

namespace CleanArchitecture.Web.Api
{
    [Route("api/[controller]")]
    public abstract class BaseApiController : ControllerBase
    {
    }
}
