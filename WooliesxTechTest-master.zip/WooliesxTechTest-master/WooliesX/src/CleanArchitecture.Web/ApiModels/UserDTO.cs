﻿namespace CleanArchitecture.Web.ApiModels
{
    public class UserDTO
    {
        public string Name { get; set; }
        public string Token { get; set; } 
    }
}
