﻿
namespace CleanArchitecture.Core.Domain
{
    public class User
    {
        public string Name { get; set; } = "Brahm Gupta";
        public string Token { get; set; } = "1234-455662-22233333-3333";
    }
}
