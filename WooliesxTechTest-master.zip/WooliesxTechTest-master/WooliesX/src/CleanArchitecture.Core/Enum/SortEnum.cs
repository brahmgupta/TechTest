﻿namespace CleanArchitecture.Core.Enum
{
    public enum SortEnum
    {
        Low,
        High,
        Ascending,
        Descending,
        Recommended
    }
}
