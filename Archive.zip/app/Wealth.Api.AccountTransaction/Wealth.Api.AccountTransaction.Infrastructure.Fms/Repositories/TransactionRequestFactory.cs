﻿using System;
using System.Collections.Generic;
using FluentResults;
using MediatR;
using Wealth.Api.AccountTransaction.Domain;
using Wealth.Api.AccountTransaction.Domain.Requests;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Features.GetAnnuityTransactions;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Features.GetCashTransactions;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Features.GetPensionTransactions;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Features.GetSuperannuationTransactions;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Features.GetUnitTrustTransactions;

namespace Wealth.Api.AccountTransaction.Infrastructure.Fms.Repositories
{
    public class TransactionRequestFactory
    {
        private readonly Dictionary<AccountType, Func<GetTransactionsRequest, IRequest<Result<IEnumerable<Transaction>>>>>
            _requestTypeDictionary = new Dictionary<AccountType, Func<GetTransactionsRequest, IRequest<Result<IEnumerable<Transaction>>>>>
            {
                { AccountType.Annuity, (request) => new GetAnnuityTransactionsRequest(request) },
                { AccountType.Superannuation, (request) => new GetSuperannuationTransactionsRequest(request) },
                { AccountType.Pension, (request) => new GetPensionTransactionsRequest(request) },
                { AccountType.Cash, (request) => new GetCashTransactionsRequest(request) },
                { AccountType.UnitTrust, (request) => new GetUnitTrustTransactionsRequest(request) }
            };

        public IRequest<Result<IEnumerable<Transaction>>> CreateRequest(GetTransactionsRequest request)
        {
            return _requestTypeDictionary.ContainsKey(request.AccountType)
                ? _requestTypeDictionary[request.AccountType]
                    .Invoke(request)
                : null;
        }
    }
}
