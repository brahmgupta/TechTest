﻿namespace Wealth.Api.AccountTransaction.Infrastructure.Fms.Infrastructure
{
    public sealed class FmsGatewayApiProxy
    {
        public string BaseUrl { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }
    }
}
