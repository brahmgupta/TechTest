﻿using System.Collections.Generic;
using System.Reflection;
using MediatR;
using Microsoft.Extensions.DependencyInjection;
using Wealth.Api.AccountTransaction.Domain;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Features.GetAccounts;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Features.GetAnnuityTransactions;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Features.GetCashTransactions;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Features.GetPensionTransactions;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Features.GetSuperannuationTransactions;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Features.GetUnitTrustTransactions;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Mappers;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Repositories;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Rpls.Abpb;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Rpls.Atcf;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Rpls.Atex;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Rpls.Atpp;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Rpls.Atsm;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Rpls.Atut;
using Wealth.Toolkit.Fms;
using Wealth.Toolkit.HttpService.Extensions;

namespace Wealth.Api.AccountTransaction.Infrastructure.Fms.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services)
        {
            services
                .AddHttpService<IFmsHttpService, FmsHttpService>();
            return services
                .AddMediatR(Assembly.GetExecutingAssembly())
                .AddMappers()
                .AddRepositories()
                .AddTransient<IFmsResponseHandler, FmsResponseHandler>()
                .AddTransient<TransactionRequestFactory, TransactionRequestFactory>();
        }

        private static IServiceCollection AddMappers(this IServiceCollection services)
        {
            return services
                .AddTransient<IMapper<GetAccountsRplResponse, IEnumerable<AccountDetails>>, AccountsMapper>()

                .AddTransient<IMapper<AnnuityAccountTransactionsRplResponse, IEnumerable<Transaction>>,
                    GetAnnuityTransactionsMapper>()

                .AddTransient<IMapper<PensionAccountTransactionsRplResponse, IEnumerable<Transaction>>,
                    GetPensionTransactionsMapper>()

                .AddTransient<IMapper<SuperannuationAccountTransactionsRplResponse, IEnumerable<Transaction>>,
                    GetSuperannuationTransactionsMapper>()

                .AddTransient<IMapper<SuperannuationAccountTransactionsRplResponse, IEnumerable<TransactionComponent>>,
                    TransactionComponentMapper>()

                .AddTransient<IMapper<UnitTrustAccountTransactionsRplResponse, IEnumerable<Transaction>>,
                    GetUnitTrustTransactionsMapper>()

                .AddTransient<IMapper<CashAccountTransactionsRplResponse, IEnumerable<Transaction>>,
                    GetCashTransactionsMapper>();
        }

        private static IServiceCollection AddRepositories(this IServiceCollection services)
        {
            return services
                .AddTransient<ITransactionRepository, TransactionRepository>();
        }
    }
}