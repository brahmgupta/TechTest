﻿using System.Collections.Generic;
using Wealth.Api.AccountTransaction.Domain;

namespace Wealth.Api.AccountTransaction.Infrastructure.Fms.Mappers
{
    public static class AccountTypeMapper
    {
        private static readonly Dictionary<string, AccountType> ProductCodeAccountMapping = new Dictionary<string, AccountType>()
        {
            {"PP",AccountType.Pension},
            {"AP",AccountType.Pension},
            {"UT",AccountType.UnitTrust},
            {"FF",AccountType.Cash},
            {"CM",AccountType.Cash},
            {"CF",AccountType.Cash},
            {"SF",AccountType.Superannuation},
            {"PS",AccountType.Superannuation},
        };

        public static AccountType GetAccountType(bool isAnnuity, string productCode)
        {
            var accountType = AccountType.Other;

            if (isAnnuity)
            {
                accountType = AccountType.Annuity;
            }
            else if (ProductCodeAccountMapping.ContainsKey(productCode))
            {
                accountType = ProductCodeAccountMapping[productCode];
            }

            return accountType;
        }
    }
}