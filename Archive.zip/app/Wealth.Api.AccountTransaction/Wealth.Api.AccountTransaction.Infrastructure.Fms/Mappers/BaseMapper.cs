﻿using System;

namespace Wealth.Api.AccountTransaction.Infrastructure.Fms.Mappers
{
    public abstract class BaseMapper<TInput, TOutput> : IMapper<TInput, TOutput>
        where TOutput : class
        where TInput : class
    {
        public virtual TOutput Map(TInput input, bool throwIfInputNull = true, params object[] args)
        {
            if (throwIfInputNull && null == input)
            {
                throw new ArgumentNullException(nameof(input));
            }

            return MapObject(input);
        }

        protected abstract TOutput MapObject(TInput input);
    }
}
