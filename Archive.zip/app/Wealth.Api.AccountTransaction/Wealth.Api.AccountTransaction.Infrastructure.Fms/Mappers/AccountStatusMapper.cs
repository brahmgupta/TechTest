﻿using System.Collections.Generic;
using Wealth.Api.AccountTransaction.Domain;

namespace Wealth.Api.AccountTransaction.Infrastructure.Fms.Mappers
{
    public class AccountStatusMapper
    {
        private static readonly Dictionary<string, AccountStatus> ProductCodeAccountMapping =
            new Dictionary<string, AccountStatus>()
            {
                {"O", AccountStatus.Open},
                {"C", AccountStatus.Closed},
                {"P", AccountStatus.Pending},
            };

        public static AccountStatus GetAccountStatus(string status)
        {
            ProductCodeAccountMapping.TryGetValue(status, out var accountStatus);

            return accountStatus;
        }
    }
}
