﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Wealth.Api.AccountTransaction.Domain;

namespace Wealth.Api.AccountTransaction.Infrastructure.Fms.Mappers
{
    public class TransactionMappingHelper
    {
        static readonly HashSet<int> CreditContributionDescriptionCodes = new HashSet<int>() { 11, 95, 99 };
        static readonly Dictionary<int, string> CreditNonContributionMapping = new Dictionary<int, string>() {

            { 16, TransactionDescriptions.DepositInterest },
            { 30, TransactionDescriptions.AdvisorFeeRebate }
        };
        static readonly Dictionary<int, string> DebitNonContributionMapping = new Dictionary<int, string>() {
            { 95, TransactionDescriptions.AdminFee }
        };

        public static TransactionStatus GetStatus(string pendingFlag)
        {
            switch (pendingFlag)
            {
                case "P":
                    return TransactionStatus.Pending;
                case "U":
                    return TransactionStatus.Unfunded;
                default:
                    return TransactionStatus.Completed;
            }
        }

        public static bool IsRefunded(string refundFlag)
        {
            return refundFlag == "*";
        }

        private static TransactionRefundType? GetTransactionRefundType(string refundFlag, string description)
        {
            if (IsRefunded(refundFlag))
            {
                if (IsRedemptionTransaction(description))
                {
                    return TransactionRefundType.Redemption;
                }

                return IsApplicationTransaction(description)
                    ? TransactionRefundType.Application
                    : TransactionRefundType.Others;
            }

            return null;
        }

        public static TransactionRefund GetTransactionRefund(string refundFlag, string description, decimal fees)
        {
            var refundType = TransactionMappingHelper.GetTransactionRefundType(refundFlag, description);
            if (refundType == TransactionRefundType.Application || refundType == TransactionRefundType.Redemption)
            {
                var refund = new TransactionRefund();
                refund.Amount = Math.Abs(fees);
                refund.RefundType = refundType.Value;
                return refund;
            }
            return null;
        }

        public static bool IsSummaryTransaction(long date)
        {
            return DateTime.TryParseExact(
                date.ToString(),
                "yyyyMMdd",
                CultureInfo.InvariantCulture,
                DateTimeStyles.None, out _);
        }

        private static bool IsRedemptionTransaction(string description)
        {
            return description.Equals("Gross rollover withdrawal", StringComparison.InvariantCultureIgnoreCase);
        }

        private static bool IsApplicationTransaction(string description)
        {
            return description.Equals("Application", StringComparison.InvariantCultureIgnoreCase) ||
                   description.Equals("Gross application", StringComparison.InvariantCultureIgnoreCase);
        }

        public static Dictionary<TransactionComponentType, TransactionComponentSetting> TransactionComponentSettings
            = new Dictionary<TransactionComponentType, TransactionComponentSetting>
            {
                {
                    TransactionComponentType.Rollover,
                    new TransactionComponentSetting {Description = "Rollover", IsTaxable = false}
                },
                {
                    TransactionComponentType.PersonalNonConcessionalContribution,
                    new TransactionComponentSetting
                        {Description = "Personal Non-Concessional Contribution", IsTaxable = false}
                },
                {
                    TransactionComponentType.PersonalConcessionalContribution,
                    new TransactionComponentSetting {Description = "Personal Concessional Contribution", IsTaxable = true}
                },
                {
                    TransactionComponentType.VoluntaryEmployerContribution,
                    new TransactionComponentSetting {Description = "Voluntary Employer Contribution", IsTaxable = true}
                },
                {
                    TransactionComponentType.SalarySacrifice,
                    new TransactionComponentSetting {Description = "Salary Sacrifice", IsTaxable = true}
                },
                {
                    TransactionComponentType.SpousalContributions,
                    new TransactionComponentSetting {Description = "Spousal Contributions", IsTaxable = false}
                },
                {
                    TransactionComponentType.SuperGuaranteeFromEmployer,
                    new TransactionComponentSetting {Description = "Super Guarantee from employer", IsTaxable = true}
                },
                {
                    TransactionComponentType.GovernmentContribution,
                    new TransactionComponentSetting {Description = "Government Contribution", IsTaxable = false}
                },
                {
                    TransactionComponentType.CapitalGainsTaxSmallBusinessRetirementExempt,
                    new TransactionComponentSetting
                        {Description = "Capital Gains Tax- Small Business Retirement Exempt", IsTaxable = false}
                },
                {
                    TransactionComponentType.CapitalGainsTaxSmallBusiness15YearExempt,
                    new TransactionComponentSetting
                        {Description = "Capital Gains Tax- Small Business 15 year Exempt", IsTaxable = false}
                },
                {
                    TransactionComponentType.PersonalInjury,
                    new TransactionComponentSetting {Description = "Personal Injury", IsTaxable = false}
                },
            };

        public static TransactionType GetTransactionType(decimal transactionType)
        {
            if (!Enum.IsDefined(typeof(TransactionType), (int)transactionType))
            {
                throw new ArgumentException($"Invalid account transaction type value of {transactionType}",
                    nameof(transactionType));
            }

            return (TransactionType) transactionType;
        }

        public static string GetSuperannuationDescription(string description, TransactionType transactionType, int descriptionCode, IEnumerable<TransactionComponent> components)
        {
            switch (transactionType)
            {
                case TransactionType.Credit when CreditContributionDescriptionCodes.Contains(descriptionCode):
                    return ContributionsDescription(components, description);
                case TransactionType.Credit when CreditNonContributionMapping.ContainsKey(descriptionCode):
                    return CreditNonContributionMapping[descriptionCode];
                case TransactionType.Debit when DebitNonContributionMapping.ContainsKey(descriptionCode):
                    return DebitNonContributionMapping[descriptionCode];
                default:
                    return description;
            }
        }

        private static string ContributionsDescription(IEnumerable<TransactionComponent> components, string description)
        {
            if (components == null || !components.Any())
            {
                return description;
            }

            return components.Count() == 1
                ? components.First().Description
                : TransactionDescriptions.Contributions;
        }
    }
}
