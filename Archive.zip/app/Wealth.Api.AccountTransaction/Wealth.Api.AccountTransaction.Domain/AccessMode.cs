﻿namespace Wealth.Api.AccountTransaction.Domain
{
    public enum AccessMode
    {
        None = 0,
        ReadOnly = 1,
        Full = 2
    }
}
