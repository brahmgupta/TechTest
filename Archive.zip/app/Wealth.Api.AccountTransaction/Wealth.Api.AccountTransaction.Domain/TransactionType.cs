﻿namespace Wealth.Api.AccountTransaction.Domain
{
    public enum TransactionType
    {
        Credit = 1,
        Debit = 2,
        Switch = 13
    }
}