﻿using System.Collections.Generic;

namespace Wealth.Api.AccountTransaction.Domain.Requests
{
    public class RequestContext
    {
        public IDictionary<string, string> OutOfBand { get; set; }
    }
}