using System;

namespace Wealth.Api.AccountTransaction.Domain
{
    public class AccountDetails
    {
        public string AccountNumber { get; set; }

        public string ProductName { get; set; }

        public AccountType AccountType { get; set; }

        public string ProductCode { get; set; }

        public decimal AccountBalance { get; set; }

        public DateTime? EffectiveDate { get; set; }

        public DealerType DealerType { get; set; }

        public AccountStatus Status { get; set; }

        public string ProductAbbreviation { get; set; }

        public DateTime? NextPaymentDate { get; set; }

        public decimal NextPaymentAmount { get; set; }

        public string AccountDesignation { get; set; }

        public string OwnerName { get; set; }

        public string EmployerName { get; set; }

        public string PlanName { get; set; }

        public string CategoryName { get; set; }

        public AccessMode AccessMode { get; set; }
    }
}
