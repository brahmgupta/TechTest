﻿using System;
using System.Collections.Generic;

namespace Wealth.Api.AccountTransaction.Domain
{
    public class Transaction
    {
        public DateTime? Date { get; set; }

        public string Description { get; set; }

        public decimal Amount { get; set; }

        public decimal UnitPrice { get; set; }

        public decimal Units { get; set; }

        public decimal UnitBalance { get; set; }

        public bool IsRefunded { get; set; }

        public TransactionRefund Refund { get; set; }

        public decimal Fees { get; set; }

        public decimal Net { get; set; }

        public decimal AccountBalance { get; set; }

        public int Count { get; set; }

        public TransactionStatus Status { get; set; }

        public TransactionType TransactionType { get; set; }

        public int DescriptionCode { get; set; }

        public IEnumerable<TransactionComponent> TransactionComponents { get; set; }
    }
}
