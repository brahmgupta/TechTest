﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using FluentResults;
using Wealth.Api.AccountTransaction.Domain.Requests;

namespace Wealth.Api.AccountTransaction.Domain
{
    public interface ITransactionRepository
    {
        Task<Result<AccountDetails>> GetAccount(GetAccountRequest request, CancellationToken cancellationToken = default(CancellationToken));
        Task<Result<IEnumerable<Transaction>>> GetTransactions(GetTransactionsRequest request, CancellationToken cancellationToken = default(CancellationToken));
    }
}