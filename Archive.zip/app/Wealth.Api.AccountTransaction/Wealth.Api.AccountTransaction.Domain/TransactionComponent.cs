﻿namespace Wealth.Api.AccountTransaction.Domain
{
    public class TransactionComponent
    {
        public string Description { get; set; }
        public decimal Amount { get; set; }
        public bool IsTaxable { get; set; }
    }
}