﻿using RichardSzalay.MockHttp;

namespace Wealth.Api.AccountTransaction.Tests
{
    public class TestHttpMessageHandler
    {
        public TestHttpMessageHandler()
        {
            Instance = new MockHttpMessageHandler();
        }

        public MockHttpMessageHandler Instance { get; }
    }
}
