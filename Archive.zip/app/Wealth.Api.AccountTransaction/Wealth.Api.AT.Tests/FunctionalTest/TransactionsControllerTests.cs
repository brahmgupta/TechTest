﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Microsoft.AspNetCore.TestHost;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RichardSzalay.MockHttp;
using Wealth.Api.AccountTransaction.Application.Models;
using Wealth.Api.AccountTransaction.Domain;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Rpls.Abpb;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Rpls.Atpp;
using Wealth.Api.AccountTransaction.Infrastructure.Fms.Rpls.Atsm;
using Wealth.Toolkit.Test;
using Xunit;

namespace Wealth.Api.AccountTransaction.Tests.FunctionalTest
{
    public class TransactionsControllerTests : BaseTest
    {
        private const string SESSION_ID = "sessionId";
        private const string COMPANY_CODE = "companyCode";

        private const string ADVISER_CODE = "adviserCode";
        private const string DEALER_CODE = "dealerCode";
        private const string STAFF_OIN = "staffOIN";

        private const string SUPER_FUND = "SF";
        private const string PENSION_FUND = "PP";

        private const string DATE_COMPARISON_FORMAT = "MM/dd/yyyy";

        public TransactionsControllerTests()
        {
            BuildTransactionsMocks();
            BuildTransactionsResponse();
        }

        private class TransactionsTestData
        {
            public decimal AccountValue { get; set; }
            public int AccountNumber { get; set; }
            public string ProductType { get; set; }
            public long TransactionDetailCount { get; set; }
            public IList<long> TransactionDate { get; set; }
            public IList<string> TransactionDescription { get; set; }
            public IList<decimal> TransactionAmount { get; set; }
            public IList<decimal> TransactionUnitPrice { get; set; }
            public IList<decimal> TransactionUnits { get; set; }
            public IList<decimal> TransactionUnitBalance { get; set; }
            public IList<string> Status { get; set; }
            public IList<decimal> TransactionFees { get; set; }
            public IList<string> IsTransactionRefunded { get; set; }
            public IList<decimal> TransactionType { get; set; }
            public List<decimal> DescriptionCode { get; set; }
            public List<decimal> Rollovers { get; set; }
            public List<decimal> PersonalNonConcessional { get; set; }
            public List<decimal> PersonalConcessional { get; set; }
            public List<decimal> EmployerConcessional { get; set; }
            public List<decimal> SalarySacrifice { get; set; }
            public List<decimal> SpouseNonConcessional { get; set; }
            public List<decimal> SuperGuarantee { get; set; }
            public List<decimal> GovtCoContribution { get; set; }
            public List<decimal> SmallBusinessRetirementExemption { get; set; }
            public List<decimal> SmallBusiness15YearExemption { get; set; }
            public List<decimal> PersonalInjury { get; set; }
        }

        private class TransactionsExpectedTestData
        {
            // ReSharper disable once UnusedAutoPropertyAccessor.Local
            public decimal AccountValue { get; set; }
            public string AccountNumber { get; set; }
            public string AccountType { get; set; }
            public bool TransactionLimitReached { get; set; }
            public IList<DateTime> Date { get; set; }
            public IList<string> Description { get; set; }
            public IList<decimal> Amount { get; set; }
            public IList<decimal> UnitPrice { get; set; }
            public IList<decimal> Units { get; set; }
            public IList<decimal> UnitBalance { get; set; }
            public IList<bool> IsRefunded { get; set; }
            public IList<decimal> Fees { get; set; }
            public IList<decimal> Net { get; set; }
            public IList<decimal> AccountBalance { get; set; }
            public IList<string> Status { get; set; }
            public IList<string> RefundType { get; set; }
            public int TransactionsCount { get; set; }
            public IList<string> TransactionType { get; set; }
            public IList<int> DescriptionCode { get; set; }
            public decimal? Refund { get; set; }
            public string TransactionComponents { get; set; }
        }

        private void MockGetAccountsRplResponse(
            decimal accountValue,
            int accountNumber,
            string productType,
            string accessLevel = "02",
            bool isAnnuity = false)
        {
            var productAbbreviation = MyFixture.Create<string>();
            var rplResponse = MyFixture.Build<GetAccountsRplResponse>()
                .With(p => p.AccountNumber, new List<decimal> { accountNumber })
                .With(p => p.AccountValue, new List<decimal> { accountValue })
                .With(p => p.ProductType, new List<string> { productType })
                .With(p => p.ProductAbbreviation, new List<string>() { productAbbreviation })
                .With(p => p.AccountsCount, 1)
                .With(p => p.GroupId, new List<string> { isAnnuity ? "E" : "" })
                .With(p => p.BalanceDate, "20190417")
                .With(p => p.MessageIndicator, 0)
                .With(p => p.NextPaymentDate, new List<string> { "20190417" })
                .With(p => p.NextPaymentAmount, new List<decimal> { 1 })
                .With(p => p.AccountDesignation, new List<string> { "my super account" })
                .With(p => p.OwnerData, "Owner name")
                .With(p => p.Continue, 0)
                .With(p => p.Status, new List<string> { "Open" })
                .With(p => p.AccessLevel, new List<string> { accessLevel })
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRABPBI", rplResponse);
        }

        private void MockRplResponse(string rplName, object expectedRplResponse,
            HttpStatusCode httpStatusCode = HttpStatusCode.OK)
        {
            MockHttp
                .When(HttpMethod.Post, $"{AppSettings.FmsGatewayApi.BaseUrl}/{rplName}")
                .Respond(httpStatusCode, new StringContent(JsonConvert.SerializeObject(expectedRplResponse)));
        }

        private void CallSuperAccountForTransactionsMock(TransactionsTestData transactionsTestData)
        {
            MockGetAccountsRplResponse(transactionsTestData.AccountValue, transactionsTestData.AccountNumber,
                transactionsTestData.ProductType);
            MockGetSuperannuationAccountTransactionsRplResponse(transactionsTestData);
        }

        private void CallPensionAccountForTransactionsMock(TransactionsTestData transactionsTestData)
        {
            MockGetAccountsRplResponse(transactionsTestData.AccountValue, transactionsTestData.AccountNumber,
                transactionsTestData.ProductType);
            MockGetPensionAccountTransactionsRplResponse(transactionsTestData);
        }

        private Dictionary<string, Action<TransactionsTestData>> _callTransactionsMock;

        private void BuildTransactionsMocks()
        {
            _callTransactionsMock = new Dictionary<string, Action<TransactionsTestData>>()
            {
                {SUPER_FUND, CallSuperAccountForTransactionsMock},
                {PENSION_FUND, CallPensionAccountForTransactionsMock}
            };
        }

        private Dictionary<string, Action<TransactionsExpectedTestData, TransactionsViewModel>> _transactionsValidation;

        private void BuildTransactionsResponse()
        {
            _transactionsValidation =
                new Dictionary<string, Action<TransactionsExpectedTestData, TransactionsViewModel>>
                {
                    {SUPER_FUND, ValidateTransactionsData},
                    {PENSION_FUND, ValidateTransactionsData}
                };
        }

        private static void ValidateTransactionsData(TransactionsExpectedTestData expectedData,
            TransactionsViewModel accountTransactions)
        {
            accountTransactions.Transactions.Count().Should().Be(expectedData.TransactionsCount);
            accountTransactions.AccountNumber.Should().Be(expectedData.AccountNumber);
            accountTransactions.AccountType.Should().Be(expectedData.AccountType);
            accountTransactions.TransactionLimitReached.Should().Be(expectedData.TransactionLimitReached);
            var transactionsDto = accountTransactions.Transactions.ToList();

            for (var i = 0; i < expectedData.TransactionsCount; i++)
            {
                transactionsDto[i].AccountBalance.Should().Be(expectedData.AccountBalance[i]);
                transactionsDto[i].Amount.Should().Be(expectedData.Amount[i]);
                transactionsDto[i].Date?.ToString(DATE_COMPARISON_FORMAT).Should()
                    .Be(expectedData.Date[i].ToString(DATE_COMPARISON_FORMAT));
                transactionsDto[i].Description.Should().Be(expectedData.Description[i]);
                transactionsDto[i].Fees.Should().Be(expectedData.Fees[i]);
                transactionsDto[i].IsRefunded.Should().Be(expectedData.IsRefunded[i]);
                transactionsDto[i].Net.Should().Be(expectedData.Net[i]);
                if (expectedData.Refund.HasValue)
                {
                    transactionsDto[i].Refund.Should().NotBeNull();
                    transactionsDto[i].Refund.RefundType.Should().Be(expectedData.RefundType[i]);
                    transactionsDto[i].Refund.Amount.Should().Be(expectedData.Refund.Value);
                }
                else
                {
                    transactionsDto[i].Refund.Should().BeNull();
                }
                transactionsDto[i].Status.Should().Be(expectedData.Status[i]);

                transactionsDto[i].UnitBalance.Should().Be(expectedData.UnitBalance[i]);
                transactionsDto[i].UnitPrice.Should().Be(expectedData.UnitPrice[i]);
                transactionsDto[i].Units.Should().Be(expectedData.Units[i]);
                transactionsDto[i].TransactionType.Should().Be(expectedData.TransactionType[i]);
                transactionsDto[i].DescriptionCode.Should().Be(expectedData.DescriptionCode[i]);

                if (transactionsDto[i].TransactionType == TransactionType.Credit.ToString())
                {
                    var expectedComponents = JToken.Parse(expectedData.TransactionComponents);
                    var actualComponents = JToken.FromObject(transactionsDto[i].TransactionComponents);
                    actualComponents.Should().BeEquivalentTo(expectedComponents);
                }
                else
                {
                    transactionsDto[i].TransactionComponents.Should().BeNull();
                }
            }
        }

        private void MockGetSuperannuationAccountTransactionsRplResponse(TransactionsTestData testData)
        {
            var rplResponse = MyFixture.Build<SuperannuationAccountTransactionsRplResponse>()
                .With(p => p.TransactionType, testData.TransactionType)
                .With(p => p.TransactionDescriptionCode, testData.DescriptionCode)
                .With(p => p.TransactionDetailCount, testData.TransactionDetailCount)
                .With(p => p.TransactionDate, testData.TransactionDate)
                .With(p => p.TransactionDescription, testData.TransactionDescription)
                .With(p => p.TransactionAmount, testData.TransactionAmount)
                .With(p => p.TransactionUnitPrice, testData.TransactionUnitPrice)
                .With(p => p.TransactionUnits, testData.TransactionUnits)
                .With(p => p.TransactionUnitBalance, testData.TransactionUnitBalance)
                .With(p => p.Status, testData.Status)
                .With(p => p.TransactionFees, testData.TransactionFees)
                .With(p => p.IsTransactionRefunded, testData.IsTransactionRefunded)
                .With(p => p.Rollover, testData.Rollovers)
                .With(p => p.PersonalNonConcessional, testData.PersonalNonConcessional)
                .With(p => p.PersonalConcessional, testData.PersonalConcessional)
                .With(p => p.EmployerConcessional, testData.EmployerConcessional)
                .With(p => p.SalarySacrifice, testData.SalarySacrifice)
                .With(p => p.SpouseNonConcessional, testData.SpouseNonConcessional)
                .With(p => p.SuperGuarantee, testData.SuperGuarantee)
                .With(p => p.GovtCoContribution, testData.GovtCoContribution)
                .With(p => p.SmallBusinessRetirementExemption, testData.SmallBusinessRetirementExemption)
                .With(p => p.SmallBusiness15YearExemption, testData.SmallBusiness15YearExemption)
                .With(p => p.PersonalInjury, testData.PersonalInjury)
                .With(p => p.MessageIndicator, 0)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRATSMA", rplResponse);
        }

        private void MockGetPensionAccountTransactionsRplResponse(TransactionsTestData testData)
        {
            var rplResponse = MyFixture.Build<PensionAccountTransactionsRplResponse>()
                .With(p => p.TransactionDetailCount, testData.TransactionDetailCount)
                .With(p => p.TransactionDate, testData.TransactionDate)
                .With(p => p.TransactionDescription, testData.TransactionDescription)
                .With(p => p.TransactionAmount, testData.TransactionAmount)
                .With(p => p.TransactionUnitPrice, testData.TransactionUnitPrice)
                .With(p => p.TransactionUnits, testData.TransactionUnits)
                .With(p => p.TransactionUnitBalance, testData.TransactionUnitBalance)
                .With(p => p.IsTransactionPending, testData.Status)
                .With(p => p.TransactionFees, testData.TransactionFees)
                .With(p => p.IsTransactionRefunded, testData.IsTransactionRefunded)
                .With(p => p.MessageIndicator, 0)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRATPPC", rplResponse);
        }

        [Theory]
        [ExcelData("FunctionalTest\\Account_Get_Transactions_TestData.xlsx")]
        public async Task ShouldSuccessfullyGetTransactions(
            decimal accountValue,
            int accountNumber,
            string productType,
            int transactionDetailCount,
            string transactionTypes,
            string descriptionCodes,
            string transactionDates,
            string transactionDescriptions,
            string transactionAmounts,
            string transactionUnitPrices,
            string transactionUnits,
            string transactionUnitBalances,
            string pendingFlags,
            string transactionFees,
            string isTransactionRefunded,
            string rollovers,
            string personalNonConcessionals,
            string personalConcessionals,
            string employerConcessionals,
            string salarySacrifices,
            string spouseNonConcessionals,
            string superGuarantees,
            string govtCoContributions,
            string smallBusinessRetirementExemptions,
            string smallBusiness15YearExemptions,
            string personalInjuries,
            decimal expectedAccountValue,
            int expectedAccountNumber,
            string expectedTransactionType,
            string expectedDescriptionCode,
            string expectedAccountType,
            bool expectedTransactionLimitReached,
            string expectedDates,
            string expectedDescriptions,
            string expectedAmounts,
            string expectedUnitPrices,
            string expectedUnits,
            string expectedUnitBalances,
            string expectedIsRefunded,
            string expectedFees,
            string expectedNets,
            string expectedAccountBalance,
            string expectedStatus,
            string expectedRefundType,
            int expectedTransactionsCounts,
            string expectedTransactionComponents,
            string expectedRefund
        )
        {
            // Arrange
            var testData = new TransactionsTestData
            {
                AccountValue = accountValue,
                AccountNumber = accountNumber,
                ProductType = productType,
                TransactionDetailCount = transactionDetailCount,
                TransactionType = transactionTypes.Split(",").Select(decimal.Parse).ToList(),
                DescriptionCode = descriptionCodes.Split(",").Select(decimal.Parse).ToList(),
                TransactionDate = transactionDates.Split(",").Select(long.Parse).ToList(),
                TransactionDescription = transactionDescriptions.Split(",").ToList(),
                TransactionAmount = transactionAmounts.Split(",").Select(decimal.Parse).ToList(),
                TransactionUnitPrice = transactionUnitPrices.Split(",").Select(decimal.Parse).ToList(),
                TransactionUnits = transactionUnits.Split(",").Select(decimal.Parse).ToList(),
                TransactionUnitBalance = transactionUnitBalances.Split(",").Select(decimal.Parse).ToList(),
                Status = pendingFlags.Split(",").ToList(),
                TransactionFees = transactionFees.Split(",").Select(decimal.Parse).ToList(),
                IsTransactionRefunded = isTransactionRefunded.Split(",").ToList(),
                Rollovers = rollovers.Split(",").Select(decimal.Parse).ToList(),
                PersonalNonConcessional = personalNonConcessionals.Split(",").Select(decimal.Parse).ToList(),
                PersonalConcessional = personalConcessionals.Split(",").Select(decimal.Parse).ToList(),
                EmployerConcessional = employerConcessionals.Split(",").Select(decimal.Parse).ToList(),
                SalarySacrifice = salarySacrifices.Split(",").Select(decimal.Parse).ToList(),
                SpouseNonConcessional = spouseNonConcessionals.Split(",").Select(decimal.Parse).ToList(),
                SuperGuarantee = superGuarantees.Split(",").Select(decimal.Parse).ToList(),
                GovtCoContribution = govtCoContributions.Split(",").Select(decimal.Parse).ToList(),
                SmallBusinessRetirementExemption = smallBusinessRetirementExemptions.Split(",").Select(decimal.Parse).ToList(),
                SmallBusiness15YearExemption = smallBusiness15YearExemptions.Split(",").Select(decimal.Parse).ToList(),
                PersonalInjury = personalInjuries.Split(",").Select(decimal.Parse).ToList(),
            };

            var expectedTestData = new TransactionsExpectedTestData
            {
                AccountValue = expectedAccountValue,
                AccountNumber = expectedAccountNumber.ToString(),
                AccountType = expectedAccountType,
                TransactionLimitReached = expectedTransactionLimitReached,
                Date = expectedDates.Split(",").Select(DateTime.Parse).ToList(),
                Description = expectedDescriptions.Split(","),
                Amount = expectedAmounts.Split(",").Select(decimal.Parse).ToList(),
                UnitPrice = expectedUnitPrices.Split(",").Select(decimal.Parse).ToList(),
                Units = expectedUnits.Split(",").Select(decimal.Parse).ToList(),
                UnitBalance = expectedUnitBalances.Split(",").Select(decimal.Parse).ToList(),
                IsRefunded = expectedIsRefunded.Split(",").Select(bool.Parse).ToList(),
                Fees = expectedFees.Split(",").Select(decimal.Parse).ToList(),
                Net = expectedNets.Split(",").Select(decimal.Parse).ToList(),
                AccountBalance = expectedAccountBalance.Split(",").Select(decimal.Parse).ToList(),
                Status = expectedStatus.Split(","),
                RefundType = expectedRefundType.Split(","),
                TransactionsCount = expectedTransactionsCounts,
                TransactionType = expectedTransactionType.Split(","),
                DescriptionCode = expectedDescriptionCode.Split(",").Select(int.Parse).ToList(),
                TransactionComponents = expectedTransactionComponents,
                Refund = string.IsNullOrEmpty(expectedRefund) ? null : (decimal?)Decimal.Parse(expectedRefund)
            };

            _callTransactionsMock[productType](testData);

            // Act
            var response =
                await CreateRequestBuilder($"/api/transactions?accountNumber={accountNumber}&customerNumber=12345")
                    .GetAsync();

            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var accountTransactions = JsonConvert.DeserializeObject<TransactionsViewModel>(jsonResponse);

            // Assert
            _transactionsValidation[productType](expectedTestData, accountTransactions);
        }

        private RequestBuilder CreateRequestBuilder(string path, string sessionId = "12345", string companyCode = "001",
            string adviserCode = "1234", string dealerCode = "4321", string staffOin = "12345678")
        {
            return Server
                .CreateRequest(path)
                .AddHeader("Authorization", "Basic dGVzdDp0ZXN0")
                .AddHeader(SESSION_ID, sessionId)
                .AddHeader(COMPANY_CODE, companyCode)
                .AddHeader(ADVISER_CODE, adviserCode)
                .AddHeader(DEALER_CODE, dealerCode)
                .AddHeader(STAFF_OIN, staffOin);
        }
    }
}
