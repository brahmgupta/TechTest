﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NSubstitute;
using Wealth.Api.AccountTransaction.Host;
using Wealth.Lib.ReleaseFeatureToggles;
using Wealth.Toolkit.Fms;

namespace Wealth.Api.AccountTransaction.Tests.FunctionalTest
{
    public class TestStartup : Startup
    {
        public TestStartup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
            : base(configuration, webHostEnvironment)
        {
        }

        public override void ConfigureServices(IServiceCollection services)
        {
            base.ConfigureServices(services);

            var testHttpMessageHandler = new TestHttpMessageHandler();
            var mockHttpClient = testHttpMessageHandler.Instance.ToHttpClient();
            services.AddReleaseFeatureToggle("development");
            services
                .AddTransient<IFmsResponseHandler>(x =>
                    new FmsResponseHandler(Substitute.For<ILogger<FmsResponseHandler>>()));
            services.Configure<AppSettings>(Configuration);

#pragma warning disable ASP0000 // Do not call 'IServiceCollection.BuildServiceProvider' in 'ConfigureServices'
            var serviceProvider = services.BuildServiceProvider();
#pragma warning restore ASP0000 // Do not call 'IServiceCollection.BuildServiceProvider' in 'ConfigureServices'
            var fmsGatewayApiSettings = serviceProvider.GetService<IOptions<FmsGatewayApiSettings>>();
            var fmsResponseHandler = serviceProvider.GetService<IFmsResponseHandler>();
            var logger = Substitute.For<ILogger<FmsHttpService>>();

            services
                .AddSingleton(x => testHttpMessageHandler)
                .AddTransient<IFmsHttpService>(x =>
                    new FmsHttpService(mockHttpClient, fmsGatewayApiSettings, fmsResponseHandler, logger));
        }
    }
}