using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Testing;
using Wealth.Api.AccountTransaction.Host;
using Xunit;

namespace Wealth.Api.AccountTransaction.Tests.FunctionalTest
{
    public class HealthControllerTests : IClassFixture<WebApplicationFactory<Startup>>
    {
        private readonly WebApplicationFactory<Startup> _factory;

        public HealthControllerTests(WebApplicationFactory<Startup> factory)
        {
            _factory = factory;
        }

        [Fact]
        public async Task ShouldReturnOkGivenHealthIsCalled()
        {
            var client = _factory.CreateClient();

            var response = await client.GetAsync("healthcheck");

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }
    }
}
