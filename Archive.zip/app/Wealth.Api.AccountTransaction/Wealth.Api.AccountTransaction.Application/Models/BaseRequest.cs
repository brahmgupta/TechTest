﻿using System.Collections.Generic;

namespace Wealth.Api.AccountTransaction.Application.Models
{
    public abstract class BaseRequest
    {
        public IDictionary<string, string> OutOfBand { get; set; }
    }
}