﻿using System.Collections.Generic;

namespace Wealth.Api.AccountTransaction.Application.Models
{
    public class TransactionsViewModel
    {
        public string AccountNumber { get; set; }

        public string AccountType { get; set; }

        public bool TransactionLimitReached { get; set; }

        public IEnumerable<TransactionDto> Transactions { get; set; }
    }
}
