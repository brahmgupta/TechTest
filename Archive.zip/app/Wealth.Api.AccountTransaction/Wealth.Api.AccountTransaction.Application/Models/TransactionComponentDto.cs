﻿namespace Wealth.Api.AccountTransaction.Application.Models
{
    public class TransactionComponentDto
    {
        public string Description { get; set; }
        public decimal Amount { get; set; }
        public bool IsTaxable { get; set; }
    }
}
