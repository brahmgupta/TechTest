﻿using AutoMapper;
using Wealth.Api.AccountTransaction.Application.Models;
using Wealth.Api.AccountTransaction.Domain;

namespace Wealth.Api.AccountTransaction.Application.Infrastructure
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            AllowNullCollections = true;
            AllowNullDestinationValues = true;

            CreateMap<Transaction, TransactionDto>();
        }
    }
}
