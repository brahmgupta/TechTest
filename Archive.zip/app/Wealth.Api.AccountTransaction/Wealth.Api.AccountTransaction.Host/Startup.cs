using System;
using System.Threading.Tasks;
using FluentValidation.AspNetCore;
using Hellang.Middleware.ProblemDetails;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Wealth.Api.AccountTransaction.Application.Models;
using Wealth.Api.AccountTransaction.Host.Infrastructure;
using Wealth.Lib.ReleaseFeatureToggles;
using Wealth.Toolkit.Configuration;
using Wealth.Toolkit.HttpService.Extensions;
using Wealth.Toolkit.Logging;
using Wealth.Toolkit.Logging.NLog;

[assembly: ApiController]
[assembly: ApiConventionType(typeof(DefaultApiConventions))]
namespace Wealth.Api.AccountTransaction.Host
{
    public class Startup
    {
        private const string API_NAME = "Wealth Api Account Transaction";

        public Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
        {
            configuration.LoadAppSecrets("appSecrets.json", "Wealth.Api.AccountTransaction.appSecrets.key");
            Configuration = configuration;
            WebHostEnvironment = webHostEnvironment;
        }

        public IConfiguration Configuration { get; }
        public IWebHostEnvironment WebHostEnvironment { get; }

        private static Task HandleException(HttpContext context)
        {
            return Task.CompletedTask;
        }

        public virtual void ConfigureServices(IServiceCollection services)
        {
            services
                .AddProblemDetails(options =>
                    ProblemDetailsConfig.ConfigureProblemDetails(options, WebHostEnvironment))
                .AddControllers()
                .AddJsonOptions(options => { options.JsonSerializerOptions.IgnoreNullValues = true; })
                .SetCompatibilityVersion(CompatibilityVersion.Version_3_0)
                .AddFluentValidation(fv => fv.RegisterValidatorsFromAssemblyContaining<BaseRequest>());

            services.AddHealthChecks();
            services.AddReleaseFeatureToggle(WebHostEnvironment.EnvironmentName);
            services.AddHttpServices(Configuration);
            services.AddDependencies(Configuration);

            services
                .AddLogging(logging =>
                {
                    logging.AddConsole();
                    logging.AddConfiguration(Configuration.GetSection("Logging"));
                })
                .AddLoggerContext();

            services.AddSwaggerGen(c => { c.SwaggerDoc("v1", new OpenApiInfo { Title = API_NAME, Version = "v1" }); });
        }

        public virtual void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory, IServiceProvider serviceProvider)
        {
            loggerFactory.UseNlog(serviceProvider);

            app.UseProblemDetails();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthChecks("/healthcheck", new HealthCheckOptions
                {
                    AllowCachingResponses = false,
                    ResponseWriter = WriteHealthCheckResponse
                });
            });

            if (!env.IsProduction())
            {
                app.UseSwagger();
                app.UseSwaggerUI(c => { c.SwaggerEndpoint("../swagger/v1/swagger.json", API_NAME); });
            }

            app.UseExceptionHandler(new ExceptionHandlerOptions
            {
                ExceptionHandler = HandleException
            });

            app.UseHttpServices();

            app.UsePerformanceLogger();

            app.UseHttpsRedirection();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }

        private Task WriteHealthCheckResponse(HttpContext context, HealthReport result)
        {
            return context.Response.WriteAsync($"Success from ({WebHostEnvironment.EnvironmentName})");
        }
    }
}
