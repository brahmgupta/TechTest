﻿using System.Collections.Generic;

namespace Wealth.Api.AccountTransaction.Host.Infrastructure
{
    public static class OutOfBandFactory
    {

        public static IDictionary<string, string> Create(
            string companyCode,
            string customerNumber
        )
        {
            var outOfBand = new Dictionary<string, string>
            {
                {nameof(companyCode), companyCode},
                {nameof(customerNumber), customerNumber}
            };

            return outOfBand;
        }

        private static IDictionary<string, string> With(this IDictionary<string, string> outOfBand, string key, string value)
        {
            if (!string.IsNullOrWhiteSpace(key) && !string.IsNullOrWhiteSpace(value))
            {
                outOfBand.Add(key, value);
            }

            return outOfBand;
        }

        public static IDictionary<string, string> WithSessionId(this IDictionary<string, string> outOfBand, string sessionId)
        {
            return outOfBand.With(nameof(sessionId), sessionId);
        }

        public static IDictionary<string, string> WithChannel(this IDictionary<string, string> outOfBand, string channel)
        {
            return outOfBand.With(nameof(channel), channel);
        }

        public static IDictionary<string, string> WithAdviserCode(this IDictionary<string, string> outOfBand, string adviserCode)
        {
            return outOfBand.With(nameof(adviserCode), adviserCode);
        }

        public static IDictionary<string, string> WithDealerCode(this IDictionary<string, string> outOfBand, string dealerCode)
        {
            return outOfBand.With(nameof(dealerCode), dealerCode);
        }

        public static IDictionary<string, string> WithStaffOin(this IDictionary<string, string> outOfBand, string staffOin)
        {
            return outOfBand.With(nameof(staffOin), staffOin);
        }
    }
}
