using System.ComponentModel.DataAnnotations;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Wealth.Api.AccountTransaction.Application.Models;
using Wealth.Api.AccountTransaction.Application.Queries.GetTransactions;
using Wealth.Api.AccountTransaction.Host.Infrastructure;
using Wealth.Toolkit.Response.Extensions;
using Wealth.Toolkit.Response.Filters;

namespace Wealth.Api.AccountTransaction.Host.Controllers
{
    public class TransactionsController : BaseController
    {
        [HttpGet]
        [ValidateModelState]
        [ProducesResponseType(typeof(TransactionsViewModel), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<TransactionsViewModel>> GetTransactions(
            [FromHeader] [Optional] string sessionId,
            [FromHeader] [Optional] string channel,
            [FromHeader] [Required] string companyCode,
            [FromQuery] [Required] string accountNumber,
            [FromQuery] [Required] string customerNumber,
            [FromQuery] [Optional] string accountType,
            CancellationToken cancellation,
            [FromQuery] int pageIndex = 0,
            [FromQuery] int pageSize = 20)
        {
            var request = new GetTransactionsQuery
            {
                AccountNumber = accountNumber,
                AccountType = accountType,
                OutOfBand = OutOfBandFactory.Create(companyCode, customerNumber)
                    .WithSessionId(sessionId)
                    .WithChannel(channel),
                PageIndex = pageIndex,
                PageSize = pageSize
            };

            var response = await Mediator.Send(request, cancellation);

            return response.ToTypedActionResult<TransactionsViewModel>();
        }
    }
}