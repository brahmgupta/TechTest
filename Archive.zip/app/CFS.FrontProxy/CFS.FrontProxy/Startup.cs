using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using CFS.FrontProxy.Authentication;
using Microsoft.AspNetCore.Http;
using Swashbuckle.AspNetCore.Swagger;
using Wealth.Toolkit.Logging;
using Wealth.Toolkit.Logging.NLog;
using Microsoft.Net.Http.Headers;
using Wealth.Toolkit.Configuration;
using CFS.FrontProxy.Routing;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.DependencyInjection;
using Wealth.Lib.AntiForgery;
using Wealth.Toolkit.HttpService.Extensions;

namespace CFS.FrontProxy
{
    public class Startup
    {
        private const string API_NAME = "CFS FrontProxy";

        public Startup(IConfiguration configuration)
        {
            configuration.LoadAppSecrets();

            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // ReSharper disable once UnusedParameter.Local
        private static Task HandleException(HttpContext context)
        {
            return Task.CompletedTask;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddHttpServices(Configuration);

            services.AddLoggerContext();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Info { Title = API_NAME, Version = "V1" });
            });

            services.AddFrontProxyAuthentication(Configuration);
            services.AddFrontProxyOcelot(Configuration);
            services.AddAntiForgery(Configuration);

            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory, IServiceProvider serviceProvider)
        {
            app.UseRouter(a => a.MapGet("healthcheck", context =>
            {
                context.Response.Headers[HeaderNames.CacheControl] = "no-cache, no-store";
                context.Response.Headers[HeaderNames.Pragma] = "no-cache";
                return context.Response.WriteAsync($"Success from ({env.EnvironmentName})");
            }));

            app.UseHttpServices();

            loggerFactory.UseNlog(serviceProvider);

            app.UseExceptionHandler(new ExceptionHandlerOptions
            {
                ExceptionHandler = HandleException
            });

            app.UsePerformanceLogger();

            app.Use(async (context, next) =>
            {
                if (!context.Response.Headers.ContainsKey(Keys.CorrelationId))
                {
                    context.Response.Headers.Add(Keys.CorrelationId, context.CorrelationId());
                }

                await next.Invoke();
            });

            if (!env.IsProduction())
            {
                app.UseSwagger();
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("../swagger/v1/swagger.json", API_NAME);
                });
            }

            app.UseFrontProxyOcelot();
        }
    }
}
