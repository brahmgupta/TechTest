﻿using System;
using System.Net;
using CFS.FrontProxy.Authentication.AccessToken;
using CFS.FrontProxy.Authentication.AccessToken.Keys;
using CFS.FrontProxy.Authentication.FNI;
using CFS.FrontProxy.Authentication.Sso;
using CFS.FrontProxy.Authentication.Sso.FirstNetWeb;
using CFS.FrontProxy.Authentication.Sso.ModernFni;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using CFS.FrontProxy.Routing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Wealth.Toolkit.HttpService.Extensions;
using ISystemClock = Microsoft.Extensions.Internal.ISystemClock;
using SystemClock = Microsoft.Extensions.Internal.SystemClock;
using Wealth.Lib.InvestorAuthentication;

namespace CFS.FrontProxy.Authentication
{
    public static class AddFrontProxyAuthenticationExtension
    {
        private const string ACCESS_TOKEN_CONFIGURATION_SECTION_NAME = "Authentication:AccessToken";
        private const string TOKEN_SERVICE_CONFIGURATION_SECTION_NAME = "Authentication:AccessToken:TokenService";
        private const string FNI_CONFIGURATION_SECTION_NAME = "Authentication:FNI";
        private const string SSO_CONFIGURATION_SECTION_NAME = "Authentication:SSO";
        private const string ERROR_CODES_CONFIGURATION_SECTION_NAME = "Authentication:ErrorCodes";
        private const string IS_MOCKING_TOKEN_SERVICE = "Authentication:AccessToken:TokenService:IsMocking";

        public static IServiceCollection AddFrontProxyAuthentication(this IServiceCollection @this,
            IConfiguration configuration)
        {
            @this.Configure<AuthenticationErrorCodeMapperSettings>(
                configuration.GetSection(ERROR_CODES_CONFIGURATION_SECTION_NAME)).TryAddSingleton(s =>
                s.GetRequiredService<IOptions<AuthenticationErrorCodeMapperSettings>>().Value);
            @this.TryAddSingleton<AuthenticationErrorCodeMapper>();

            @this
                .AddAccessTokenAuthenticationParts(configuration)
                .AddFirstNetWebAuthenticationParts(configuration)
                .AddFNIAuthentication(configuration, FNI_CONFIGURATION_SECTION_NAME)
                .AddAuthentication()
                .AddScheme<FNIAuthenticationHandlerOptions, FNIAuthenticationHandler>(
                    OcelotAuthenticationSchemes.FNI,
                    o => { o.AuthenticationErrorResponseCode = HttpStatusCode.Forbidden; })
                .AddScheme<FNIAuthenticationHandlerOptions, FNIAuthenticationHandler>(
                    OcelotAuthenticationSchemes.FNIRedirect,
                    o => { o.AuthenticationErrorResponseCode = HttpStatusCode.Redirect; })
                .AddScheme<AccessTokenAuthenticationHandlerOptions, AccessTokenAuthenticationHandler>(
                    OcelotAuthenticationSchemes.AccessToken, o => { })
                .AddScheme<SsoAuthenticationOptions, SsoCallbackAuthenticationHandler>(
                    OcelotAuthenticationSchemes.SsoCallBack, o => { })
                .AddScheme<SsoAuthenticationOptions, PassThroughAuthenticationHandler>(
                    OcelotAuthenticationSchemes.PassThrough, o => { })
                .AddScheme<SsoAuthenticationOptions, FirstNetWebAuthenticationHandler>(
                    OcelotAuthenticationSchemes.FirstNetWeb, o =>
                    {
                        o.ClientId = OcelotAuthenticationSchemes.FirstNetWeb;
                    })
                .AddScheme<SsoAuthenticationOptions, ModernFniSsoAuthenticationHandler>(
                    OcelotAuthenticationSchemes.ModernFniSso, o =>
                    {
                        o.ClientId = OcelotAuthenticationSchemes.ModernFniSso;
                    });

            return @this;
        }


        private static IServiceCollection AddAccessTokenAuthenticationParts(this IServiceCollection @this, IConfiguration configuration)
        {
            @this.Configure<AccessTokenSettings>(configuration.GetSection(ACCESS_TOKEN_CONFIGURATION_SECTION_NAME));
            @this.TryAddSingleton<IAccessTokenSettings>(services =>
                services.GetRequiredService<IOptions<AccessTokenSettings>>().Value);

            @this.Configure<TokenServiceClientSettings>(configuration.GetSection(TOKEN_SERVICE_CONFIGURATION_SECTION_NAME));
            @this.TryAddSingleton<ITokenServiceClientSettings>(services =>
                services.GetRequiredService<IOptions<TokenServiceClientSettings>>().Value);
            @this.TryAddSingleton<IKeysServiceSettings>(services =>
                services.GetRequiredService<IOptions<TokenServiceClientSettings>>().Value);
            @this.TryAddSingleton<ISsoTokenService, SsoTokenService>();

            var isMockTokenService = configuration.GetValue<bool>(IS_MOCKING_TOKEN_SERVICE);
            if (isMockTokenService)
            {
                @this.AddTransient<ITokenServiceClient, TokenMockService>();
            }
            else
            {
                @this.AddHttpService<ITokenServiceClient, TokenServiceClient>();
            }

            @this.AddMemoryCache();
            @this.TryAddSingleton<ISystemClock, SystemClock>();
            @this.TryAddTransient<IKeysService, KeysService>();
            @this.TryAddTransient<IAccessTokenValidator, AccessTokenValidator>();

            return @this;
        }

        public static IServiceCollection AddFirstNetWebAuthenticationParts(this IServiceCollection @this, IConfiguration configuration)
        {
            if (@this == null)
            {
                throw new ArgumentNullException(nameof(@this));
            }

            @this.Configure<SsoSettings>(configuration.GetSection(SSO_CONFIGURATION_SECTION_NAME));
            @this.TryAddSingleton<ISsoSettings>(services =>
                services.GetRequiredService<IOptions<SsoSettings>>().Value);

            return @this;
        }
    }
}