﻿using Microsoft.AspNetCore.Builder;
using Ocelot.Middleware;

namespace CFS.FrontProxy.Routing
{
    public static class UseFrontProxyOcelotExtension
    {
        public static IApplicationBuilder UseFrontProxyOcelot(this IApplicationBuilder app)
        {
            var configuration = new OcelotPipelineConfiguration()
            {
                AuthenticationMiddleware = OcelotAuthenticationMiddleware.Middleware,
            };

            app.UseOcelot(configuration).Wait();

            return app;
        }
    }
}
