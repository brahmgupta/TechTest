﻿namespace CFS.FrontProxy.Routing
{
    public class OcelotAuthenticationSchemes
    {
        public static string FNI => "FNI";
        public static string FNIRedirect => "FNIRedirect";
        public static string AccessToken => "AccessToken";
        public static string SsoCallBack => "SsoCallBack";
        public static string PassThrough => "PassThrough";
        public static string FirstNetWeb => "FirstNetWeb";
        public static string ModernFniSso => "ModernFniSso";
    }
}
