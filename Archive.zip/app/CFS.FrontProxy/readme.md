# CFS FrontProxy

## Routing

FrontProxy is using [Ocelot](https://github.com/ThreeMammals/Ocelot) for the routing. If nothing is explicitly specified below, please follow to the [Ocelot documentation](https://ocelot.readthedocs.io/).

Technically, the custom routing logic (as well as e.g. authentication, returning error codes or adding CorrelationId to downstream requests) is triggered from `OcelotAuthenticationMiddleware`.

### Settings files

FrontProxy doesn't use a fallback settings file for Ocelot. Every environment's routing configuration is entirely contained within `ocelot.{environmentName}.json` where `environmentName` is the hosting environment name. 

Settings file are loaded with the standard ASP.NET Core configuration pattern:

``` csharp
// a line from of Program.cs:
.AddJsonFile($"ocelot.{hostingContext.HostingEnvironment.EnvironmentName}.json")
```

### Passing headers

In opposite to Ocelot, all headers are NOT carried over to the downstream by default. If you want to pass the header from the upstream request to the downstream request, you need to specify it in `UpstreamHeaderTransform` as follow:

* The key is the original header name wrapped in curly brackets.
* The value is empty string.

So to transfer header `X-FirstNet-Code-Purpose`, this will do:

```
"UpstreamHeaderTransform": {
    "{X-FirstNet-Code-Purpose}": ""
}
```

### Authentication for routes

Every route needs to specify the authentication method. The default Ocelot JSON structure (`AuthenticationOptions.AuthenticationProviderKey`) is being used here:

```
"AuthenticationOptions": {
    "AuthenticationProviderKey": "FNI"
}
```

There are two options available (values to be put in `AuthenticationProviderKey`):
* `Cookie` - based on the FNI token, initially for the web requests ([more about Cookie authentication](#cookie-authentication))
* `AccessToken` - based on the IDP Access Token, initially for the mobile/device requests ([more about Access Token authentication](#access-token-authentication)).

### Placeholders

Ocelot has built-in placeholders, e.g.:

* Upstream: `/api/{category}/{id}`
* Downstream `/items/{category}?&productId={id}`

Will route `/api/polo-thisrts/123` to `/items/polo-tshirts?&productId=123`

On top of this, FrontProxy enables using the authenticated user's claims in in placeholders (doesn't matter what authentication method was used), not only in path, but also in headers.

To be able to do that, claims need to be specified in configuration under the `InternalAccessToken.ClaimsEnabledInRoutes` JSON path.

```
"InternalAccessToken": {
    // other stuff....
    "ClaimsEnabledInRoutes": [
        "Oin",
        "CompanyCode",
        "FmsSession"
    ]
}
```

Now, `Oin`, `CompanyCode` and `FmsSession` can be used in routes along with other placeholders in path (+ querystring):

e.g. `/{CompanyCode}/items/{category}?&productId={id}&oin={Oin}&sessionId={FmsSession}`

and in headers:

```
"UpstreamHeaderTransform": {
    "companyCode": "{CompanyCode}",
    "sessionId": "{FmsSession}"
},
```

## Authentication

### Cookie authentication

Cookie authentication is based on the cookie coming from FNI log in (so-called `InvestorCookie`). Technically, the cookie value is a signed JWT containing in payload both raw values and encrypted ones.

Settings are stored under `Authentication.Cookie` path:

* `CookieName` - name of the cookie
* `FniToken` - key used to verify the JWT signature
* `FniTokenPassword` - key used to decrypt the encrypted JWT properties
    * only the values are encrypted
    * same key is used to decrypt all of them
* `CookieClaims` - list of claims to be carry over from the cookie's JWT into the authenticated user (and ultimately into the internal access token).

To investigate the internal flow of cookie authentication, start with `CookieAuthenticationHandler` which triggers the `CookieValidator` where all the logic is wrapped.

Some insights:
* `FniTokenReader` class is responsible for:
    * reading the JWT
    * validating its structure
    * verifying the signature
    * decrypting secured values
* Keys for verification and decryption (`FniToken` and `FniTokenPassword`) are taken from appsettings and appsecret.
    * Both operations are custom and coded entirely in the project
        * `IEncryptionMethod` is used to decrypt the values
        * `IHashAlgorithm` is used to calculate the hash compared with the incoming one to validate the signature
* Two of the claims (`FmsSession` and `Oin`) are hardcoded to be decrypted
    * Also, there is additional validation set for these values - `FniTokenReader` expects them to be numbers (all characters are digits).


### Access token authentication

Access token authentication is based on the JWT issued by `CFS.IdentityProvider`. The JWT is both signed and encrypted (entirely). 

Settings are stored under `Authentication.AccessToken` path:

* `TokenService` - FrontProxy is calling TokenService to get the decryption key and signing key (to verify the signature). Most of the settings properties here are pretty self-descriptive, but few requires additional attension: 
    * `ApiKey` - value will be added to the TokenService request in `cba-api-key` header.
    * `DecryptionKeySecret` - value is used to get the decryption key from TokenService, needs to be exactly the same as the `IdTokenSharedSecret` in Cfs.IdentityProvider.
* `Issuer` - the accepted issuer. **BE EXTRA CAREFULL HERE**, as this value is **NOT** an url, it's a string and needs to be exactly the same as the url which Cfs.IdentityProvider will set up in its internals. When experiencing `InvalidIssuer` error code, double check if the URL is valid and is **100%** same as the one in the access token. Again; technically it's a string, not url, so e.g. slash (`/`) at the end matters! Casing  (`...\Cfs.IdentityProvider` vs `...\cfs.identityprovider`) matters!  
* `Audience` - accepted audience.

To investigate the internal flow of access token authentication, start with `AccessTokenAuthenticationHandler` which triggers the `AccessTokenValidator` where all the logic is wrapped.

Some insights:
* The default value for name claim is `name` and its hardcoded.
* The default configuration is hardcoded and assumes:
    * Signature is required
    * Expiration time is required
    * Audience and issuer validation is enabled
* To call TokenService for the decryption key, a `label` parameter is required. This is the value extracted from the JWT's header (`kid`). How do I know that? I decompiled the `CbaIdentityServer` nuget package used in Cfs.IdentityProvider and found out. 
* TokenService keys have lifetime. It might happens that you will experience the `404` from the api call (and therefore `KeysRetrievalError` error code in the logs), but the real reason is that the key is expired and TokenService returns `404` when trying to request for the key using its label. The expiration time of the encryption key is totally independent from to the access token expiration time.

### Error codes

In case of error, both `Cookie` and `AccessToken` return error codes using a standard `Error` model from `Wealth.Toolkit.Response`.

The error codes for both methods are defined as enum types (respectively `CookieErrorCode` and `AccessTokenErrorCode`).

In some cases error codes are return directly after a simple check, e.g.:

``` csharp
if (string.IsNullOrWhiteSpace(accessToken))
{
    return AccessTokenResult.Failure(AccessTokenErrorCode.TokenNotFound);
}
```

However more cases are just catching exceptions from built-in framework classes and trying to figure out what the error code should be. E.g. this is the snippet from `MapExceptionToResultCode` method from `AccessTokenValidator` that ilustrates the idea: 


``` csharp
if (ExceptionOfType(exception,
    typeof(SecurityTokenException),
    typeof(SecurityTokenDecryptionFailedException),
    typeof(SecurityTokenEncryptionKeyNotFoundException)))
{
    return AccessTokenErrorCode.DecryptionFailed;
}
```

Both authentication methods are implemented as a standard authentication handlers that are part of ASP.NET Core Identity. At the time they were created, it wasn't possible to return any information about the failure, that's why they are injected as HttpContext's Items. 

Before returning the error code to the caller, additional mapping is performed (as a part of `OcelotAuthenticationMiddleware`, where in case of failed authentication, the error code is extracted from `HttpContext.Items`). The mapping is defined in `Authentication.ErrorCodes` and can be used to return an obfuscated error code that will be meaningless for the user, but for us (and e.g. the call center) will be a valuable information.

```
"ErrorCodes": {
    "AccessToken": {
        "TokenNotFound": "AUTH_ERROR_1",     
        "InvalidTokenFormat": "AUTH_ERROR_2",
        "InvalidHeader": "AUTH_ERROR_3",
        // ...
    },
    // ...
    "FallbackErrorCode": "AUTH_ERROR"
}
```

In the example above if `TokenNotFound` is "returned" from access token authentication, user will see only `AUTH_ERROR_1`. 
If the mapping is not defined, the value from `FallbackErrorCode` will be used.