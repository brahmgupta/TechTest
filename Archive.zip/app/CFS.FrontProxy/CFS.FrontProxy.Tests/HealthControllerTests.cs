using System.IO;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Xunit;

namespace CFS.FrontProxy.Tests
{
    public class HealthControllerTests
    {
        private TestServer _server;

        [Fact]
        public async Task ShouldReturnOkGivenHealthIsCalled()
        {
            _server = new TestServer(new WebHostBuilder()
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseStartup<Startup>());

            var response = await _server.CreateRequest("healthcheck").AddHeader("Authorization", "Basic dGVzdDp0ZXN0").GetAsync();

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }
    }
}
