﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using CFS.FrontProxy.Authentication.Sso;
using NSubstitute;
using Xunit;
using Microsoft.Extensions.Logging;

namespace CFS.FrontProxy.Tests.FirstNetWebTests
{
    public class SsoCallbackHandlerTests
    {
        private readonly ISsoSettings _fnCookieSettings;
        private readonly HttpClient _client;
        public SsoCallbackHandlerTests()
        {
            ILoggerFactory loggerFactory = Substitute.For<ILoggerFactory>();
            _fnCookieSettings = Substitute.For<ISsoSettings>();
            _fnCookieSettings.LegacyLoginUrl.Returns("http://test");
            _client = new HttpClient(new SsoCallbackHandler(loggerFactory, _fnCookieSettings));
        }

        [Fact]
        public async void ShouldNotCreate_AuthenticationCookie_When_AccessToken_NotFoundAsync()
        {
            var response = await _client.PostAsync(new Uri("http://test"), null);
            Assert.True(response.StatusCode == HttpStatusCode.Redirect);
            Assert.Equal("http://test/", response.Headers.Location.ToString());
            Assert.DoesNotContain(response.Headers, header => header.Key.Equals("Set-Cookie"));
        }

        [Fact]
        public async void ShouldCreate_AuthenticationCookie_When_AccessToken_PassesValidationAsync()
        {
            _fnCookieSettings.CookieName.Returns("fnac");
            _fnCookieSettings.CookiePath.Returns("/");

            var formContent = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("access_token", "access-token"),
                new KeyValuePair<string, string>("state", "http://test")
            });
            var response = await _client.PostAsync(new Uri("http://test"), formContent);
            Assert.True(response.StatusCode == HttpStatusCode.Redirect);
            Assert.Equal("http://test/", response.Headers.Location.ToString());
            Assert.Single(response.Headers.Where(header => header.Key.Equals("Set-Cookie")));
        }
    }
}