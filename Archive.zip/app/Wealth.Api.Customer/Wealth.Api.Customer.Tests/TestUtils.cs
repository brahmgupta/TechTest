﻿using System.IO;
using System.Threading.Tasks;

namespace Wealth.Api.Customer.Tests
{
    internal static class TestUtils
    {
        public static async Task<string> ReadFileAsync(string path)
        {
            using (var reader = File.OpenText(path))
            {
                return await reader.ReadToEndAsync();
            }
        }
    }
}
