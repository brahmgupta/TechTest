﻿using System;
using System.Net;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using FluentResults;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using NSubstitute;
using Wealth.Api.Customer.Application.Models;
using Wealth.Api.Customer.Domain.CustomerAggregate;
using Xunit;

namespace Wealth.Api.Customer.Tests.FunctionalTest
{
    public class CustomerControllerTests : BaseTests
    {
        private readonly JsonSerializer _serializer;
        private readonly ICustomerRepository _customerRepository;
        private readonly Fixture _fixture;
        private const string SESSION_ID = "sessionId";

        public CustomerControllerTests()
        {
            _fixture = new Fixture();
            _serializer = new JsonSerializer
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                NullValueHandling = NullValueHandling.Ignore
            };

            _customerRepository = Server
                .Host
                .Services
                .GetRequiredService<ICustomerRepository>();
        }

        [Fact]
        public async Task ShouldSuccessfullyGetCustomerForExistingCustomerNumber()
        {
            var customer = GetStubbedCustomer();
            var customerDto = GetStubbedCustomerDto(customer.Value);
            _customerRepository.GetCustomer(Arg.Any<GetCustomerRequest>())
                .ReturnsForAnyArgs(Task.FromResult(customer));

            var response = await Server
                .CreateRequest("/api/customers/1234567890?companyCode=12345")
                .AddHeader(SESSION_ID, "12345")
                .AddHeader("Authorization", "Basic dGVzdDp0ZXN0")
                .GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var entity = JToken.Parse(await response.Content.ReadAsStringAsync());

            Assert.True(JToken.DeepEquals(entity, JToken.FromObject(customerDto, _serializer)));
        }

        private CustomerDto GetStubbedCustomerDto(CustomerDetails customer)
        {
            return Mapper.Map<CustomerDto>(customer);
        }

        [Fact]
        public async Task ShouldFailToGetCustomerWhenNoCustomer()
        {
            _customerRepository.GetCustomer(Arg.Any<GetCustomerRequest>())
                .ReturnsForAnyArgs(Task.FromResult(Results.Fail<CustomerDetails>("error")));

            var response = await Server
                .CreateRequest("/api/customers/123?companyCode=12345")
                .AddHeader(SESSION_ID, "12345")
                .AddHeader("Authorization", "Basic dGVzdDp0ZXN0")
                .GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.InternalServerError);
        }

        [Fact]
        public async Task ShouldFailToGetCustomerWhenBadInputParameter()
        {
            _customerRepository.GetCustomer(Arg.Any<GetCustomerRequest>())
                .ReturnsForAnyArgs(Task.FromResult<Result<CustomerDetails>>(null));

            var response = await Server
                .CreateRequest("/api/customers/%20")
                .AddHeader(SESSION_ID, "12345")
                .AddHeader("Authorization", "Basic dGVzdDp0ZXN0")
                .GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
        }

        private Result<CustomerDetails> GetStubbedCustomer()
        {
            return Results.Ok(new CustomerDetails(
                "123",
                "Mr",
                "John",
                "Smith",
                DateTime.Today.AddMonths(-1),
                _fixture.Create<Address>(),
                _fixture.Create<Address>(),
                _fixture.Create<ContactDetails>(),
                _fixture.Create<string>(),
                _fixture.Create<string>(),
                _fixture.Create<string>(),
                _fixture.Create<int>(),
                AccessMode.Full,
                _fixture.CreateMany<CommunicationPreference>(),
                _fixture.CreateMany<Account>()));
        }
    }
}