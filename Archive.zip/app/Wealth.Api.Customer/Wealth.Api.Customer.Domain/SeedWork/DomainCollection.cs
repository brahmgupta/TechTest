﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Wealth.Api.Customer.Domain.SeedWork
{
    public abstract class DomainCollection<T> : IEnumerable<T>
    {
        protected DomainCollection()
        {
            Items = new List<T>();
        }

        protected DomainCollection(IEnumerable<T> items) : this()
        {
            Guard.AgainstNullArgument(nameof(items), items);

            Items.AddRange(items);
        }

        protected List<T> Items { get; }

        public IEnumerator<T> GetEnumerator()
        {
            return Items.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        internal abstract bool SetItem(T item);

        internal IEnumerable<T> Update(IEnumerable<T> items)
        {
            return items?.Where(SetItem).ToList();
        }
    }
}