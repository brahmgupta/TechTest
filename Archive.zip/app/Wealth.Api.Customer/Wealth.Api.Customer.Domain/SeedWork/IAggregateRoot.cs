﻿namespace Wealth.Api.Customer.Domain.SeedWork
{
    public interface IAggregateRoot { }
}
