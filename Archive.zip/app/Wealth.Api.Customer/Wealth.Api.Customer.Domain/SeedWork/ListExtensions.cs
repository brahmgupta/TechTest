﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Wealth.Api.Customer.Domain.SeedWork
{
    public static class ListExtensions
    {
        public static List<T> AddOrReplace<T>(this List<T> @this, Func<T, bool> predicate, T newItem)
        {
            if (@this == null)
            {
                return null;
            }

            var item = @this.FirstOrDefault(predicate);
            if (item != null)
            {
                @this.Remove(item);
            }
            @this.Add(newItem);

            return @this;
        }
    }
}
