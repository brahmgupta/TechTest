﻿using System;

namespace Wealth.Api.Customer.Domain.Exceptions
{
    public class CustomerDomainException : Exception
    {
        public CustomerDomainException(string message)
            : base(message)
        { }

        public CustomerDomainException(string message, Exception innerException)
            : base(message, innerException)
        { }
    }
}
