﻿using System;
using System.Collections.Generic;
using System.Linq;
using Wealth.Api.Customer.Domain.SeedWork;

namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public class CustomerDetails : Entity<string>, IAggregateRoot
    {
        public CustomerDetails(
            string id,
            string title,
            string givenName,
            string surname,
            DateTime dateOfBirth,
            Address residentialAddress,
            Address mailingAddress,
            ContactDetails contactDetails,
            string employerAndSalarySacrifice,
            string canAdviserCallReporting,
            string canAdviserDetailChange,
            int accountsCount,
            AccessMode accessMode,
            IEnumerable<CommunicationPreference> communicationPreferences,
            IEnumerable<Account> accounts)
        {
            Guard.AgainstNullOrEmptyArgument(nameof(id), id);

            Id = id;
            Title = title;
            GivenName = givenName;
            Surname = surname;
            DateOfBirth = dateOfBirth;
            ContactDetails = contactDetails;
            MailingAddress = mailingAddress;
            ResidentialAddress = residentialAddress;
            EmployerAndSalarySacrifice = employerAndSalarySacrifice;
            CanAdviserCallReporting = canAdviserCallReporting;
            CanAdviserDetailChange = canAdviserDetailChange;
            AccountsCount = accountsCount;
            AccessMode = accessMode;
            CommunicationPreferences = new CommunicationPreferences(communicationPreferences);
            Accounts = new Accounts(accounts);
        }

        public string Title { get; }
        public string GivenName { get; }
        public string Surname { get; }
        public DateTime DateOfBirth { get; }
        public Address ResidentialAddress { get; private set; }
        public Address MailingAddress { get; private set; }
        public ContactDetails ContactDetails { get; private set; }
        public int AccountsCount { get; private set; }
        public string EmployerAndSalarySacrifice { get; private set; }
        public string CanAdviserCallReporting { get; private set; }
        public string CanAdviserDetailChange { get; private set; }

        public AccessMode AccessMode { get; private set; }
        public CommunicationPreferences CommunicationPreferences { get; private set; }
        public Accounts Accounts { get; private set; }

        public bool SetEmployerAndSalarySacrifice(string employerAndSalarySacrifice)
        {
            if (EmployerAndSalarySacrifice != null && EmployerAndSalarySacrifice.Equals(employerAndSalarySacrifice))
            {
                return false;
            }

            EmployerAndSalarySacrifice = employerAndSalarySacrifice;
            OnModified();
            return true;
        }

        public bool SetCanAdviserCallReporting(string canAdviserCallReporting)
        {
            if (CanAdviserCallReporting != null && CanAdviserCallReporting.Equals(canAdviserCallReporting))
            {
                return false;
            }

            CanAdviserCallReporting = canAdviserCallReporting;
            OnModified();
            return true;
        }

        public bool SetCanAdviserDetailChange(string canAdviserDetailChange)
        {
            if (CanAdviserDetailChange != null && CanAdviserDetailChange.Equals(canAdviserDetailChange))
            {
                return false;
            }

            CanAdviserDetailChange = canAdviserDetailChange;
            OnModified();
            return true;
        }

        public bool SetResidentialAddress(Address address)
        {
            if (ResidentialAddress != null && ResidentialAddress.Equals(address))
            {
                return false;
            }

            ResidentialAddress = address;
            OnModified();
            return true;
        }

        public bool SetMailingAddress(Address address)
        {
            if (MailingAddress!= null && MailingAddress.Equals(address))
            {
                return false;
            }

            MailingAddress = address;
            OnModified();
            return true;
        }

        public bool SetContactDetails(ContactDetails contactDetails)
        {
            if (ContactDetails != null && ContactDetails.Equals(contactDetails))
            {
                return false;
            }

            ContactDetails = new ContactDetails(
                homePhone: contactDetails.HomePhone,
                workPhone: contactDetails.WorkPhone,
                mobile: ContactDetails?.Mobile,
                fax: ContactDetails?.Fax,
                emailAddress: contactDetails.EmailAddress);
            OnModified();
            return true;
        }

        public bool SetCommunicationPreferences(IEnumerable<CommunicationPreference> communicationPreferences)
        {
            if (communicationPreferences == null)
            {
                return false;
            }

            if (CommunicationPreferences == null)
            {
                CommunicationPreferences = new CommunicationPreferences(communicationPreferences);
                return true;
            }

            var modifiedItems = CommunicationPreferences.Update(communicationPreferences);
            if (modifiedItems.Any())
            {
                OnModified();
                return true;
            }

            return false;
        }

        public bool SetAccounts(IEnumerable<Account> accounts)
        {
            if (accounts == null)
            {
                return false;
            }

            if (Accounts == null)
            {
                Accounts = new Accounts(accounts);
                return true;
            }

            var modifiedAccounts = Accounts.Update(accounts);
            if (modifiedAccounts.Any())
            {
                OnModified();
                return true;
            }

            return false;
        }
    }
}