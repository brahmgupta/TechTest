﻿using System.Collections.Generic;
using Wealth.Api.Customer.Domain.SeedWork;

namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public class CommunicationPreference : ValueObject
    {
        public CommunicationPreference(
            int id,
            CommunicationPreferenceType type,
            string value,
            string description = "")
        {
            Id = id;
            Description = description;
            Type = type;
            Value = value;
        }

        public int Id { get; }
        public CommunicationPreferenceType Type { get; }
        public string Value { get; }
        public string Description { get; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return Id;
            yield return Type;
            yield return Value;
        }
    }
}