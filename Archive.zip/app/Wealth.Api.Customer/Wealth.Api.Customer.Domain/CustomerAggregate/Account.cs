﻿using System.Collections.Generic;
using System.Linq;
using Wealth.Api.Customer.Domain.SeedWork;

namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public class Account : Entity<string>
    {
        public Account(
            string accountId,
            string accountNumber,
            string accountDesignation,
            string productCode,
            AccountType accountType,
            string productAbbreviation,
            Address mailingAddress,
            IEnumerable<CommunicationPreference> communicationPreferences,
            AccessMode accessMode = AccessMode.None)
        {
            Guard.AgainstNullOrEmptyArgument(nameof(accountNumber), accountNumber);

            Id = accountId;
            AccountNumber = accountNumber;
            AccountDesignation = accountDesignation;
            ProductCode = productCode;
            MailingAddress = mailingAddress;
            CommunicationPreferences = new CommunicationPreferences(communicationPreferences);
            AccessMode = accessMode;
            AccountType = accountType;
            ProductAbbreviation = productAbbreviation;
        }

        public string AccountNumber { get; }
        public string AccountDesignation { get; }

        public string ProductCode { get; }
        public AccountType AccountType { get; }
        public string ProductAbbreviation { get; }
        public AccessMode AccessMode { get; }
        public Address MailingAddress { get; private set; }
        public CommunicationPreferences CommunicationPreferences { get; private set; }

        public bool SetMailingAddress(Address address)
        {
            if (MailingAddress != null && MailingAddress.Equals(address))
            {
                return false;
            }

            MailingAddress = address;
            OnModified();
            return true;
        }

        public bool SetCommunicationPreferences(IEnumerable<CommunicationPreference> communicationPreferences)
        {
            if (communicationPreferences == null)
            {
                return false;
            }

            if (CommunicationPreferences == null)
            {
                CommunicationPreferences = new CommunicationPreferences(communicationPreferences);
                return true;
            }

            var modified = CommunicationPreferences.Update(communicationPreferences);
            if (modified.Any())
            {
                OnModified();
                return true;
            }

            return false;
        }
    }
}