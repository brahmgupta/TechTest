﻿namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public sealed class CustomerConstants
    {
        public const string AustraliaCountryCode = "AU";
        public static readonly string[] AustralianStates = { "NSW", "VIC", "QLD", "NT", "SA", "WA", "ACT", "TAS" };
        public const int MaximumLengthAddressLine = 30;
        public const int MaximumSuburb = 22;
        public const int MaximumState = 3;
        public const int MaximumPostcode = 4;

    }
}
