namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public enum CommunicationPreferenceType
    {
        IqMagazine,
        PromotionalMaterials,
        AnnualReport,
        StatementsAndConfirmations
    }
}