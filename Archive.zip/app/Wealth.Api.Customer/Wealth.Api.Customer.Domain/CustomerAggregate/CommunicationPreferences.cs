﻿using System.Collections.Generic;
using System.Linq;
using Wealth.Api.Customer.Domain.SeedWork;

namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public class CommunicationPreferences : DomainCollection<CommunicationPreference>
    {
        public CommunicationPreferences()
        {
        }

        public CommunicationPreferences(IEnumerable<CommunicationPreference> communicationPreferences):base(communicationPreferences)
        {
        }

        internal override bool SetItem(CommunicationPreference communicationPreference)
        {
            if (communicationPreference == null)
            {
                return false;
            }

            if (this.Any(cp => cp.Id == communicationPreference.Id &&
                                                    !cp.Equals(communicationPreference)))
            {
                Items.AddOrReplace(cp => cp.Id == communicationPreference.Id,
                    communicationPreference);
                return true;
            }

            return false;
        }
    }
}