﻿namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public enum AccountType
    {
        Annuity,
        Cash,
        Pension,
        Superannuation,
        UnitTrust,
        Other
    }
}
