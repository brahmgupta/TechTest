﻿namespace Wealth.Api.Customer.Domain.CustomerAggregate
{
    public class UpdateCustomerRequest : RequestContext
    {
        public CustomerDetails Customer { get; set; }
    }
}
