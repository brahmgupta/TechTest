﻿using System.Threading;
using System.Threading.Tasks;
using FluentResults;
using MediatR;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Wealth.Api.Customer.Domain.CustomerAggregate;
using Wealth.Api.Customer.Infrastructure.Fms.Features.GetCustomerProfileFms;
using Wealth.Api.Customer.Infrastructure.Fms.Features.UpdateCommunicationPreferencesFms;
using Wealth.Api.Customer.Infrastructure.Fms.Features.UpdatePersonalDetailsFms;

namespace Wealth.Api.Customer.Infrastructure.Fms.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly ILogger<CustomerRepository> _logger;
        private readonly IMediator _mediator;

        public CustomerRepository(ILogger<CustomerRepository> logger, IMediator mediator)
        {
            _logger = logger;
            _mediator = mediator;
        }

        public async Task<Result<string>> UpdateCustomer(UpdateCustomerRequest request, CancellationToken cancellationToken = default(CancellationToken))
        {
            var contextLogInfo = GetRequestContextLogInfo(request);

            _logger.LogDebug($"Updating customer {contextLogInfo}");

            var originalCustomer = await GetCustomer(new GetCustomerRequest
            {
                OutOfBand = request.OutOfBand
            }, cancellationToken);
            if (originalCustomer.IsFailed)
            {
                return originalCustomer.ToResult<string>();
            }

            var customerRequest = new UpdatePersonalDetailsFmsRequest(request)
            {
                Customer = request.Customer,
                OriginalCustomer = originalCustomer.Value
            };

            var confirmationId = await _mediator.Send(customerRequest, cancellationToken);
            if (confirmationId.IsFailed)
            {
                return confirmationId.ToResult<string>();
            }

            var updateCommunicationPreferenceRequest = new UpdateCommunicationPreferencesFmsRequest(request)
            {
                ConfirmationId = confirmationId.Value,
                Customer = request.Customer,
                OriginalCustomer = originalCustomer.Value
            };

            var updateCommunicationPreferenceResult = await _mediator.Send(updateCommunicationPreferenceRequest, cancellationToken);
            if (updateCommunicationPreferenceResult.IsFailed)
            {
                return updateCommunicationPreferenceResult.ToResult<string>();
            }

            return Results.Ok(updateCommunicationPreferenceResult.Value.ConfirmationId);
        }

        public async Task<Result<CustomerDetails>> GetCustomer(GetCustomerRequest request, CancellationToken cancellationToken = default(CancellationToken))
        {
            var contextLogInfo = GetRequestContextLogInfo(request);

            _logger.LogDebug($"Retrieving personal details details for {contextLogInfo}");
            var customerProfileRequest = new GetCustomerProfileFmsRequest(request);
            var customerProfileResponse = await _mediator.Send(customerProfileRequest, cancellationToken);

            return customerProfileResponse;
        }

        private static string GetRequestContextLogInfo(RequestContext request)
        {
            return JsonConvert.SerializeObject(request.OutOfBand);
        }
    }
}