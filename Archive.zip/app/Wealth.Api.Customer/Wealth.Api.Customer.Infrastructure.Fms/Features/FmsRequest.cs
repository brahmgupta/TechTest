﻿using System;
using Wealth.Api.Customer.Application.Infrastructure;
using Wealth.Api.Customer.Domain.CustomerAggregate;

namespace Wealth.Api.Customer.Infrastructure.Fms.Features
{
    public abstract class FmsRequest
    {
        protected FmsRequest(RequestContext request)
        {
            request.OutOfBand.TryGetValue(OutOfBandConstants.OutOfBandChannelKey, out var channelValue);
            if (!string.IsNullOrWhiteSpace(channelValue))
            {
                Channel = channelValue;
            }

            request.OutOfBand.TryGetValue(OutOfBandConstants.OutOfBandSessionIdKey, out var sid);
            if (!string.IsNullOrWhiteSpace(sid))
            {
                if (long.TryParse(sid, out var sessionId))
                {
                    SessionId = sessionId;
                }
                else
                {
                    throw new ArgumentException($"The {nameof(SessionId)} must be a number");
                }
            }

            long longCustomerNumber = 0;
            if (request.OutOfBand.TryGetValue(OutOfBandConstants.OutOfBandCustomerNumberKey, out var customerNumber) &&
                !long.TryParse(customerNumber, out longCustomerNumber))
            {
                throw new ArgumentException($"The {nameof(CustomerNumber)} must be a number");
            }
            CustomerNumber = longCustomerNumber;

            request.OutOfBand.TryGetValue(OutOfBandConstants.OutOfBandCompanyCodeKey, out var companyCode);
            CompanyCode = companyCode;
        }

        public long SessionId { get; }
        public string CompanyCode { get; }
        public long CustomerNumber { get; }
        public string Channel { get; }
    }
}
