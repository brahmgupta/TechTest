﻿using Wealth.Api.Customer.Domain.CustomerAggregate;

namespace Wealth.Api.Customer.Infrastructure.Fms.Infrastructure
{
    public static class AddressHelper
    {
        public static bool HasChanges(this Address address, Address origin)
        {
            return address != null && origin != null &&
                   !(address.AddressLine1 == origin.AddressLine1 &&
                     address.AddressLine2 == origin.AddressLine2 &&
                     address.AddressLine3 == origin.AddressLine3 &&
                     address.Country == origin.Country &&
                     address.Postcode == origin.Postcode &&
                     address.State == origin.State &&
                     address.Suburb == origin.Suburb);
        }

        public static string ToPostcode(this decimal postcode) {
            if (string.IsNullOrWhiteSpace(postcode.ToString("#"))) {
                return string.Empty;
            }
            return postcode.ToString("0000");
        }
    }
}