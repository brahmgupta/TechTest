﻿using System.Collections.Generic;
using Wealth.Api.Customer.Domain.CustomerAggregate;

namespace Wealth.Api.Customer.Infrastructure.Fms.Infrastructure
{
    public class AddressComparer : IEqualityComparer<Address>
    {
        public bool Equals(Address x, Address y)
        {
            return !x.HasChanges(y);
        }

        public int GetHashCode(Address address)
        {
            return (address.AddressLine1,
                address.AddressLine2,
                address.AddressLine3,
                address.Country,
                address.Postcode,
                address.State,
                address.Suburb).GetHashCode();
        }
    }
}