﻿using Wealth.Api.Customer.Domain.CustomerAggregate;

namespace Wealth.Api.Customer.Infrastructure.Fms.Infrastructure
{
    public static class ContactHelper
    {
        public static bool HasChanges(this ContactDetails details, ContactDetails origin)
        {
            return details != null && origin != null &&
                   !(details.EmailAddress == origin.EmailAddress &&
                     details.Fax == origin.Fax &&
                     details.HomePhone == origin.HomePhone &&
                     details.Mobile == origin.Mobile &&
                     details.WorkPhone == origin.WorkPhone);
        }
    }
}