﻿using FluentResults;

namespace Wealth.Api.Customer.Infrastructure.Fms.Infrastructure
{
    public class FluentResultReasonHelper : Reason
    {
        public Reason CreateReason(string message)
        {
            Message = message;
            return this;
        }
    }
}
