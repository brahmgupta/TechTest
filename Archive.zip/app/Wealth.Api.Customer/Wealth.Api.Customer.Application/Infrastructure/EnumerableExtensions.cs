﻿using System;
using System.Collections.Generic;
using System.Linq;
using FluentResults;
using Wealth.Toolkit.Response.Models;
using Error = Wealth.Toolkit.Response.Models.Error;

namespace Wealth.Api.Customer.Application.Infrastructure
{
    public static class EnumerableExtensions
    {
        public static IEnumerable<TOut> SafeConvert<TIn, TOut>(this IEnumerable<TIn> @this, Func<TIn, TOut> convert)
        {
            return @this?.Select(convert).Where(item => item != null);
        }
    }
}
