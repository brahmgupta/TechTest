﻿
namespace Wealth.Api.Customer.Application.Infrastructure
{
    public static class OutOfBandConstants
    {
        public const string OutOfBandSessionIdKey = "sessionId";
        public const string OutOfBandChannelKey = "channel";
        public const string OutOfBandCompanyCodeKey = "companyCode";
        public const string OutOfBandCustomerNumberKey = "customerNumber";
        public const string OutOfBandMobileChannelValue = "mobile";
    }
}
