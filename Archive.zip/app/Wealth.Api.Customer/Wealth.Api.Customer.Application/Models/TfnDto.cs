namespace Wealth.Api.Customer.Application.Models
{
    public class TfnDto
    {
        public string Number { get; set; }
        public bool IsProvided { get; set; }
        public string Exemption { get; set; }
    }
}