# Wealth Api Account Consent
---

## Features 
- Consent for Accounts

