﻿using AutoMapper;
using Wealth.Api.Account.Consent.Application.Models;
using Wealth.Api.Account.Consent.Domain.ConsentAggregate;

namespace Wealth.Api.Account.Consent.Application.Infrastructure
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<ConsentDetails, ConsentDto>();
        }
    }
}
