﻿using MediatR;
using Wealth.Api.Account.Consent.Application.Models;
using Wealth.Toolkit.Response.Models;

namespace Wealth.Api.Account.Consent.Application.Commands
{
    public class UpdateConsentCommand : BaseRequest, IRequest<Response>
    {
        public string AccountNumber { get; set; }
        public string ConsentType { get; set; }
        public bool? ConfirmationLetter { get; set; }
    }
}
