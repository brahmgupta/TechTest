﻿namespace Wealth.Api.Account.Consent.Application.Models
{
    public class UpdateConsentRequest
    {
        public bool? ConfirmationLetter { get; set; }
    }
}
