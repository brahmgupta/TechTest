﻿using MediatR;
using Wealth.Api.Account.Consent.Application.Models;
using Wealth.Toolkit.Response.Models;

namespace Wealth.Api.Account.Consent.Application.Queries
{
    public class GetConsentQuery: BaseRequest, IRequest<Response>
    {
        public string AccountNumber { get; set; }
        public string ConsentType { get; set; }
    }
}
