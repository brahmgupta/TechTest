﻿using FluentResults;
using MediatR;
using Microsoft.Extensions.Logging;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Wealth.Api.Account.Consent.Domain.ConsentAggregate;
using Wealth.Toolkit.Response.Models;
using Error = FluentResults.Error;
using System;

namespace Wealth.Api.Account.Consent.Infrastructure.Fms.Repositories
{
    public class ConsentRepository : IConsentRepository
    {
        private readonly ConsentRequestFactory _consentRequestFactory;
        private readonly ILogger<IConsentRepository> _logger;
        private readonly IMediator _mediator;

        public ConsentRepository(IMediator mediator, ILogger<IConsentRepository> logger,
            ConsentRequestFactory consentRequestFactory)
        {
            _mediator = mediator;
            _logger = logger;
            _consentRequestFactory = consentRequestFactory;
        }

        public async Task<Result<ConsentDetails>> GetConsent(GetConsentRequest request,
            CancellationToken cancellationToken = default)
        {
            var contextLogInfo = GetRequestContextLogInfo(request);

            var consentRequest = _consentRequestFactory.CreateGetRequest(request);

            if (consentRequest == null)
            {
                _logger.LogWarning($"Invalid account consent type for {contextLogInfo}");
                return Results.Fail<ConsentDetails>(new Error(ErrorCodes.NotFound));
            }

            var consentDetailsResult = await _mediator.Send(consentRequest, cancellationToken);

            if (consentDetailsResult.IsFailed)
            {
                return consentDetailsResult.ToResult<ConsentDetails>();
            }

            if (consentDetailsResult.Value == null)
            {
                _logger.LogWarning($"No account consent details found for {contextLogInfo}");
                return Results.Fail<ConsentDetails>(new Error(ErrorCodes.NotFound));
            }

            return consentDetailsResult;
        }

        private static string GetRequestContextLogInfo(RequestContext request)
        {
            return JsonConvert.SerializeObject(request.OutOfBand);
        }

        public async Task<Result<ConsentDetails>> UpdateConsent(UpdateConsentRequest updateConsentRequest, CancellationToken cancellationToken = default)
        {
            var contextLogInfo = GetRequestContextLogInfo(updateConsentRequest);

            _logger.LogDebug($"Updating Account Consent {contextLogInfo}");

            var updateIlbaRequest = _consentRequestFactory.CreateUpdateRequest(updateConsentRequest);

            if (updateIlbaRequest == null)
            {
                _logger.LogWarning($"Invalid account consent type for {contextLogInfo}");
                return Results.Fail<ConsentDetails>(new Error(ErrorCodes.NotFound));
            }

            var updateIlbaResult =
                await _mediator.Send(updateIlbaRequest, cancellationToken);

            if (updateIlbaResult.IsFailed)
            {
                return updateIlbaResult.ToResult<ConsentDetails>();
            }

            return updateIlbaResult;
        }
    }
}
