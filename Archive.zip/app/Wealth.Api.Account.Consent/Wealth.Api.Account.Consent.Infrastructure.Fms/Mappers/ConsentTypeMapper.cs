﻿
using System.Collections.Generic;
using Wealth.Api.Account.Consent.Domain.ConsentAggregate;

namespace Wealth.Api.Account.Consent.Infrastructure.Fms.Mappers
{
    public static class ConsentTypeMapper
    {
        private static readonly Dictionary<string, ConsentType> ConsentTypeMapping =
            new Dictionary<string, ConsentType>()
            {
                {"ILBA", ConsentType.ILBA},
            };

        public static ConsentType GetConsentType(string consentCode)
        {
            var consentCodeKey = consentCode.ToUpper();

            if (ConsentTypeMapping.ContainsKey(consentCodeKey))
            {
                return ConsentTypeMapping[consentCodeKey];
            }

            return ConsentType.Other;
        }
    }
}
