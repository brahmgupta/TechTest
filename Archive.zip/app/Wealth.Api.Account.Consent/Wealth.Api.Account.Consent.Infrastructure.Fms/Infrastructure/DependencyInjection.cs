﻿using MediatR;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;
using Wealth.Api.Account.Consent.Domain.ConsentAggregate;
using Wealth.Api.Account.Consent.Infrastructure.Fms.Features.GetIlba;
using Wealth.Api.Account.Consent.Infrastructure.Fms.Infrastructure.Mapping;
using Wealth.Api.Account.Consent.Infrastructure.Fms.Repositories;
using Wealth.Api.Account.Consent.Infrastructure.Fms.Rpls.Ioom;
using Wealth.Toolkit.Fms;
using Wealth.Toolkit.HttpService.Extensions;

namespace Wealth.Api.Account.Consent.Infrastructure.Fms.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services)
        {
            services
                .AddHttpService<IFmsHttpService, FmsHttpService>();
            return services
                .AddMediatR(Assembly.GetExecutingAssembly())
                .AddMappers()
                .AddRepositories()
                .AddTransient<IFmsResponseHandler, FmsResponseHandler>()
                .AddTransient<ConsentRequestFactory, ConsentRequestFactory>();
        }

        private static IServiceCollection AddMappers(this IServiceCollection services)
        {
            return services.AddTransient<IMapper<IlbaOptOutRplResponse, ConsentDetails>,
                GetIlbaMapper>();
        }

        private static IServiceCollection AddRepositories(this IServiceCollection services)
        {
            return services
                .AddTransient<IConsentRepository, ConsentRepository>();
        }
    }
}
