﻿using System;
using System.Threading;
using System.Threading.Tasks;
using FluentResults;
using MediatR;
using Microsoft.Extensions.Logging;
using Wealth.Toolkit.Fms;

namespace Wealth.Api.Account.Consent.Infrastructure.Fms.Rpls
{
    public abstract class RplHandler<TRequest, TResponse> :
        IRequestHandler<TRequest, Result<TResponse>>
        where TRequest : IRequest<Result<TResponse>>
        where TResponse : RplResponse
    {
        private readonly string _rplName;

        private readonly ILogger<RplHandler<TRequest, TResponse>> _logger;
        private readonly IFmsHttpService _fmsHttpService;

        protected RplHandler(IFmsHttpService fmsHttpService, ILogger<RplHandler<TRequest, TResponse>> logger, string rplName)
        {
            _fmsHttpService = fmsHttpService;
            _logger = logger;
            _rplName = rplName;
        }

        public virtual async Task<Result<TResponse>> Handle(TRequest request, CancellationToken cancellationToken)
        {
            Result<TResponse> response;
            _logger.LogDebug($"Calling RPL '{_rplName}'");
            try
            {
                response = await _fmsHttpService.CallFmsAsync<TRequest, TResponse>(request, _rplName, cancellationToken);
                _logger.LogDebug($"Calling RPL '{_rplName}' completed successfully");
            }
            catch (Exception exception)
            {
                _logger.LogWarning(exception, $"Calling RPL '{_rplName}' failed");
                throw;
            }

            return response;
        }
    }
}
