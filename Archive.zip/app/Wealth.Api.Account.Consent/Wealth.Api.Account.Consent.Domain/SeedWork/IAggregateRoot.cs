﻿namespace Wealth.Api.Account.Consent.Domain.SeedWork
{
    public interface IAggregateRoot { }
}
