﻿
namespace Wealth.Api.Account.Consent.Domain.ConsentAggregate
{
    public enum ConsentType
    {
        ILBA,
        Other
    }
}
