﻿using System.Threading;
using System.Threading.Tasks;
using FluentResults;

namespace Wealth.Api.Account.Consent.Domain.ConsentAggregate
{
    public interface IConsentRepository
    {
        Task<Result<ConsentDetails>> GetConsent(GetConsentRequest request, CancellationToken cancellationToken = default(CancellationToken));
        Task<Result<ConsentDetails>> UpdateConsent(UpdateConsentRequest request, CancellationToken cancellationToken = default(CancellationToken));
    }
}
