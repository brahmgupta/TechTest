﻿namespace Wealth.Api.Account.Consent.Domain.ConsentAggregate
{
    public class UpdateConsentRequest : RequestContext
    {
        public string AccountNumber { get; set; }
        public string ConsentType { get; set; }
        public bool? ConfirmationLetter { get; set; }
    }
}
