﻿namespace Wealth.Api.Account.Consent.Domain.ConsentAggregate
{
    public class GetConsentRequest : RequestContext
    {
        public string AccountNumber { get; set; }
        public string ConsentType { get; set; }
    }
}
