﻿using AutoFixture;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;
using RichardSzalay.MockHttp;
using System.IO;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Wealth.Api.Account.Consent.Tests.FunctionalTests
{
    public abstract class BaseTests
    {
        protected TestServer Server { get; }
        protected MockHttpMessageHandler MockHttp { get; }
        public AppSettings AppSettings { get; }

        protected Fixture MyFixture;
        protected BaseTests()
        {
            MyFixture = new Fixture();
            var config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", true, true)
                .Build();

            Server = new TestServer(new WebHostBuilder()
                .UseConfiguration(config)
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseStartup<TestStartup>());

            MockHttp = Server.Host.Services.GetService<TestHttpMessageHandler>().Instance;
            AppSettings = Server.Host.Services.GetService<IOptions<AppSettings>>().Value;
        }

        protected void CleanRoutes()
        {
            MockHttp.Clear();
        }

        protected bool? StringToNullableBool(string str)
        {
            if (str.ToLower().Equals("true")) return true;
            if (str.ToLower().Equals("false")) return false;
            return null;
        }

    }
}
