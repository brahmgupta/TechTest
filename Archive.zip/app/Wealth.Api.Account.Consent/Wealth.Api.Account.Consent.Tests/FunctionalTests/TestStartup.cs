﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NSubstitute;
using Wealth.Toolkit.Fms;
using Microsoft.Extensions.Options;
using Wealth.Toolkit.Response.Filters;
using Wealth.Api.Account.Consent.Host;

namespace Wealth.Api.Account.Consent.Tests.FunctionalTests
{
    public class TestStartup: Startup
    {
        public TestStartup(IConfiguration configuration)
            : base(configuration)
        {
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public override void ConfigureServices(IServiceCollection services)
        {
            base.ConfigureServices(services);
            var testHttpMessageHandler = new TestHttpMessageHandler();
            var mockHttpClient = testHttpMessageHandler.Instance.ToHttpClient();
            services
                .AddTransient<IFmsResponseHandler>(x =>
                    new FmsResponseHandler(Substitute.For<ILogger<FmsResponseHandler>>()));
            services.Configure<AppSettings>(Configuration);

            var serviceProvider = services.BuildServiceProvider();
            var fmsGatewayApiSettings = serviceProvider.GetService<IOptions<FmsGatewayApiSettings>>();
            var fmsResponseHandler = serviceProvider.GetService<IFmsResponseHandler>();
            var logger = Substitute.For<ILogger<FmsHttpService>>();

            services
                .AddMvc(options => { options.Filters.Add(typeof(HttpGlobalExceptionFilter)); });


            services
                .AddSingleton(x => testHttpMessageHandler)
                .AddTransient<IFmsHttpService>(x =>
                    new FmsHttpService(mockHttpClient, fmsGatewayApiSettings, fmsResponseHandler, logger));

        }
    }
}
