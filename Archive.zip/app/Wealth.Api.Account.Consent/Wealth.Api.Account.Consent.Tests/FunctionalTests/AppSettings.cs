﻿namespace Wealth.Api.Account.Consent.Tests.FunctionalTests
{
    public class AppSettings
    {
        public FmsGatewayApi FmsGatewayApi { get; set; }
        public Pact Pact { get; set; }
    }
    public class FmsGatewayApi
    {
        public string BaseUrl { get; set; }
    }    
    public class Pact
    {
        public Broker Broker { get; set; }
        public Local Local { get; set; }
    }
    public class Broker
    {
        public string WebUrl { get; set; }
        public string MobileUrl { get; set; }
    }
    public class Local
    {
        public string WebPath { get; set; }
        public string MobilePath { get; set; }
    }
}
