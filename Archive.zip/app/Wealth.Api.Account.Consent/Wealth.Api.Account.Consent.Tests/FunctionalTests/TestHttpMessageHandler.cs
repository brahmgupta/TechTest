﻿using RichardSzalay.MockHttp;

namespace Wealth.Api.Account.Consent.Tests.FunctionalTests
{
    public class TestHttpMessageHandler
    {
        public TestHttpMessageHandler()
        {
            Instance = new MockHttpMessageHandler();
        }

        public MockHttpMessageHandler Instance { get; }
    }
}
