﻿using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.TestHost;
using Newtonsoft.Json;
using NSubstitute;
using RichardSzalay.MockHttp;
using Wealth.Api.Account.Consent.Application.Models;
using Wealth.Api.Account.Consent.Infrastructure.Fms.Rpls.Ioom;
using Xunit;

namespace Wealth.Api.Account.Consent.Tests.FunctionalTests
{
    public class AccountConsentControllerTests : BaseTests
    {
        private ConsentDto consent;

        private const string SESSION_ID = "sessionId";
        private const string COMPANY_CODE = "companyCode";
        private const string CHANNEL = "channel";
        private const string ADVISER_CODE = "adviserCode";
        private const string DEALER_CODE = "dealerCode";
        private const string STAFF_OIN = "staffOIN";
        private RequestBuilder CreateRequestBuilder(string path, string sessionId = "12345", string companyCode = "001",
            string adviserCode = "1234", string dealerCode = "4321", string staffOIN = "12345678")
        {
            return Server
                .CreateRequest(path)
                .AddHeader("Authorization", "Basic dGVzdDp0ZXN0")
                .AddHeader(SESSION_ID, sessionId)
                .AddHeader(COMPANY_CODE, companyCode)
                .AddHeader(ADVISER_CODE, adviserCode)
                .AddHeader(DEALER_CODE, dealerCode)
                .AddHeader(STAFF_OIN, staffOIN)
                .AddHeader(CHANNEL, "N");
        }

        private void CallConsentMock()
        {
            MockGetConsentRplResponse();
        }

        private void MockGetConsentRplResponse()
        {
            var rplResponse = MyFixture.Build<IlbaOptOutRplResponse>()
                .With(p => p.ExpiryDate, 20190417)
                .With(p => p.ExecutionDate, 20190417)
                .With(p => p.ExecutionTime, 20190417)
                .With(p => p.MessageIndicator, 0)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRIOOMA", rplResponse);
        }

        private void MockRplResponse(string rplName, object expectedRplResponse,
            HttpStatusCode httpStatusCode = HttpStatusCode.OK)
        {
            MockHttp
                .When(HttpMethod.Post, $"{AppSettings.FmsGatewayApi.BaseUrl}/{rplName}")
                .Respond(httpStatusCode, new StringContent(JsonConvert.SerializeObject(expectedRplResponse)));
        }
        [Fact]
        public async Task ShouldSuccessfullyGetConsentForExistingAccountNumber()
        {
            CallConsentMock();
            var accountNumber = MyFixture.Create<int>();
            // Act
            var response = await CreateRequestBuilder($"/api/accounts/{accountNumber}/consents/ILBA?customerNumber=39642251").GetAsync();
            
            // Assert
            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            consent = JsonConvert.DeserializeObject<ConsentDto>(jsonResponse);

            //Test Validation
            consent.ExpiryDate.Should().NotBeNull();
        }

        [Fact]
        public async Task ShouldSuccessfullyPutConsentForExistingAccountNumber()
        {
            CallConsentMock();
            var accountNumber = MyFixture.Create<int>();
            var updateConsentRequest = new UpdateConsentRequest();
            updateConsentRequest.ConfirmationLetter = true;
            var putJson = JsonConvert.SerializeObject(updateConsentRequest);

            // Act
            var response = await CreateRequestBuilder($"/api/accounts/{accountNumber}/consents/ILBA?customerNumber=39642251")
                .And(h => { h.Content = new StringContent(putJson, Encoding.UTF8, "application/json"); })
                .SendAsync("PUT");

            // Assert
            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            consent = JsonConvert.DeserializeObject<ConsentDto>(jsonResponse);

            //Test Validation
            consent.ExpiryDate.Should().NotBeNull();
        }
    }
}