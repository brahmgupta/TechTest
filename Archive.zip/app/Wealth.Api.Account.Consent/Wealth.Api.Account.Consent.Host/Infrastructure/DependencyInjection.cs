﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Wealth.Api.Account.Consent.Application.Infrastructure;
using Wealth.Api.Account.Consent.Infrastructure.Fms.Infrastructure;
using Wealth.Toolkit.Fms;

namespace Wealth.Api.Account.Consent.Host.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddDependencies(this IServiceCollection services, IConfiguration configuration)
        {
            return services
                .Configure<FmsGatewayApiSettings>(configuration.GetSection("FmsGatewayApi"))
                .AddHttpClient()
                .AddOptions()
                .AddHttpContextAccessor()
                .AddApplication()
                .AddInfrastructure();
        }
    }
}
