﻿using System.Collections.Generic;

namespace Wealth.Api.Account.Consent.Host.Infrastructure
{
    public static class OutOfBandFactory
    {
        public static IDictionary<string, string> Create(
            string sessionId,
            string channel,
            string companyCode,
            string customerNumber,
            string adviserCode = null,
            string dealerCode = null,
            string staffOin = null
        )
        {
            var outOfBand = new Dictionary<string, string>
            {
                {nameof(companyCode), companyCode},
                {nameof(customerNumber), customerNumber}
            };

            if (!string.IsNullOrWhiteSpace(sessionId))
            {
                outOfBand.Add(nameof(sessionId), sessionId);
            }

            if (!string.IsNullOrWhiteSpace(channel))
            {
                outOfBand.Add(nameof(channel), channel);
            }

            if (!string.IsNullOrWhiteSpace(adviserCode))
            {
                outOfBand.Add(nameof(adviserCode), adviserCode);
            }

            if (!string.IsNullOrWhiteSpace(dealerCode))
            {
                outOfBand.Add(nameof(dealerCode), dealerCode);
            }

            if (!string.IsNullOrWhiteSpace(staffOin))
            {
                outOfBand.Add(nameof(staffOin), staffOin);
            }

            return outOfBand;
        }
    }
}
