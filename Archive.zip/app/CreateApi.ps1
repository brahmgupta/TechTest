Param (
    [Parameter(Position = 0, Mandatory = $true)][string]$name,
    [Parameter(Position = 1, Mandatory = $false)][string]$friendlyName = $null,
    [Parameter(Position = 2, Mandatory = $false)][string]$serviceName = $null
)

if (!$friendlyName) {
    $friendlyName = $name.Replace(".", " ")
}

if (!$serviceName) {
  $serviceName = $name.ToLowerInvariant().Replace(".", "")
}

$ErrorActionPreference = 'Stop'

$templateName = "Wealth.Api.Template"

$rootDir = Convert-Path $PSScriptRoot

$templatePath = Convert-Path "$($rootDir)\$($templateName)"

$apiPath = [IO.Path]::GetFullPath("$($rootDir)\$($name)")

# Safety lock - don't do anything if API with selected name already exist
if (Test-Path $apiPath) {
    throw "Directory $($apiPath) already exist!"
}

Write-Host "Using template:`n`t$($templatePath)"
Write-Host "Creating new API in:`n`t$($apiPath)"
Copy-Item -Path $templatePath -Destination $apiPath -Recurse

$items = Get-ChildItem -Path $apiPath -Recurse

# Specify all the changes (text replacements) within the files' contents
$changes = @(
    [pscustomobject]@{origin = $templateName; target = $name},
    [pscustomobject]@{origin = "Wealth Api Template"; target = $friendlyName},
    [pscustomobject]@{origin = "wealth-api-template"; target = $serviceName}
)

Write-Host "Changes:"
foreach ($change in $changes) {
    Write-Host "`t$($change.origin) -> $($change.target)"
}


Write-Host "Applying changes in:"

# Replace text in all of the files
foreach ($item in $items) {
    if (-not $item.PSIsContainer) {
        Write-Host "`t$($item.FullName)"
        foreach ($change in $changes) {
            [System.IO.File]::WriteAllText(
                $item.FullName,
                ([System.IO.File]::ReadAllText($item.FullName).Replace($change.origin, $change.target))
            )
        }
    }    
}

Write-Host "Renaming:"
$done = $false

# Keep renaming files until all done
while (-not $done) {
    $renamed = $false
    $items = Get-ChildItem -Path $apiPath -Recurse

    foreach ($item in $items) {
        if ($item.Name.Contains($templateName)) {
            $newName = $item.Name.Replace($templateName, $name)
            Write-Host "`t$($item.FullName) -> $($newName)"
            Rename-Item -Path $item.FullName -NewName $newName
            $renamed = $true
            break
        }
    }

    if (-not $renamed) {
        $done = $true
    }
}

Write-Host "Activating mbt:`n`t.mbt.yml.bak -> .mbt.yml"
Rename-Item -Path $apiPath\.mbt.yml.bak -NewName .mbt.yml