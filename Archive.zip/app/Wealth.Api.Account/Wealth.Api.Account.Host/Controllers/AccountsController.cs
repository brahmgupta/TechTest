using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.JsonPatch;
using Wealth.Api.Account.Application.Commands.UpdateInsurance;
using Wealth.Api.Account.Application.Commands.UpdatePensionPaymentDetails;
using Wealth.Api.Account.Application.Models;
using Wealth.Api.Account.Application.Queries.GetAccount;
using Wealth.Api.Account.Application.Queries.GetAccounts;
using Wealth.Api.Account.Application.Queries.GetPensionPaymentDetails;
using Wealth.Api.Account.Application.Queries.GetTransactions;
using Wealth.Api.Account.Host.Infrastructure;
using Wealth.Api.Account.Host.Infrastructure.Attributes;
using Wealth.Lib.ReleaseFeatureToggles;
using Wealth.Toolkit.Response.Extensions;
using Wealth.Toolkit.Response.Filters;
using Wealth.Toolkit.Response.Models;

namespace Wealth.Api.Account.Host.Controllers
{
    public class AccountsController : BaseController
    {
        [HttpGet("{accountNumber}")]
        [ValidateModelState]
        [ValidateStringNumber("sessionId", "customerNumber", "accountNumber")]
        [ProducesResponseType(typeof(AccountDto), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<AccountDto>> GetAccount(
            [FromHeader][Optional]string sessionId,
            [FromHeader][Optional]string channel,
            [FromHeader][Required]string companyCode,
            [FromQuery][Required]string customerNumber,
            [FromRoute][Required]string accountNumber,
            CancellationToken cancellation)
        {
            var request = new GetAccountQuery
            {
                AccountNumber = accountNumber,
                OutOfBand = OutOfBandFactory.Create(
                    sessionId,
                    channel,
                    companyCode,
                    customerNumber)
            };

            var response = await Mediator.Send(request, cancellation);

            return response.ToTypedActionResult<AccountDto>();
        }

        [HttpGet]
        [ValidateModelState]
        [ValidateStringNumber("sessionId", "customerNumber")]
        [ProducesResponseType(typeof(IEnumerable<AccountDto>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<IEnumerable<AccountDto>>> GetAccounts(
            [FromHeader][Optional]string sessionId,
            [FromHeader][Optional]string channel,
            [FromHeader][Required]string companyCode,
            [FromQuery][Required]string customerNumber,
            [FromQuery]bool? active,
            [FromQuery]bool? details,
            CancellationToken cancellation)
        {
            var request = new GetAccountsQuery
            {
                IsAccountDetailsNeeded = details.GetValueOrDefault(),
                OutOfBand = OutOfBandFactory.Create(
                    sessionId,
                    channel,
                    companyCode,
                    customerNumber)
            };

            var response = await Mediator.Send(request, cancellation);

            return response.ToTypedActionResult<IEnumerable<AccountDto>>();
        }

        [HttpGet("{accountNumber}/transactions")]
        [ValidateModelState]
        [ValidateStringNumber("sessionId", "companyCode", "customerNumber", "accountNumber")]
        [ProducesResponseType(typeof(AccountTransactionsDto), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<AccountTransactionsDto>> GetTransactions(
            [FromRoute][Required] string accountNumber,
            [FromHeader][Optional] string sessionId,
            [FromHeader][Optional]string channel,
            [FromHeader][Required] string companyCode,
            [FromQuery][Required] string customerNumber,
            CancellationToken cancellation)
        {
            var request = new GetTransactionsQuery
            {
                AccountNumber = accountNumber,
                OutOfBand = OutOfBandFactory.Create(
                    sessionId,
                    channel,
                    companyCode,
                    customerNumber)
            };

            var response = await Mediator.Send(request, cancellation);

            return response.ToTypedActionResult<AccountTransactionsDto>();
        }

        [HttpGet("{accountNumber}/drawdown")]
        [ValidateModelState]
        [ValidateStringNumber("sessionId", "customerNumber", "accountNumber")]
        [ProducesResponseType(typeof(PensionPaymentDetailsDto), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<PensionPaymentDetailsDto>> GetPensionPaymentDetails(
            [FromHeader][Optional]string sessionId,
            [FromHeader][Optional]string channel,
            [FromHeader][Optional]string sourceChannel,
            [FromHeader][Required]string companyCode,
            [FromHeader][Optional]string adviserCode,
            [FromHeader][Optional]string dealerCode,
            [FromHeader][Optional]string staffOin,
            [FromQuery][Required]string customerNumber,
            [FromRoute][Required]string accountNumber,
            CancellationToken cancellation)
        {
            var request = new GetPensionPaymentDetailsQuery()
            {
                AccountNumber = accountNumber,
                OutOfBand = OutOfBandFactory.Create(
                    sessionId,
                    channel,
                    companyCode,
                    customerNumber,
                    adviserCode,
                    dealerCode,
                    staffOin,
                    sourceChannel)
            };

            var response = await Mediator.Send(request, cancellation);

            return response.ToTypedActionResult<PensionPaymentDetailsDto>();
        }

        [HttpPut("{accountNumber}/drawdown")]
        [ValidateModelState]
        [ValidateStringNumber("customerNumber", "accountNumber")]
        [ProducesResponseType(typeof(UpdatePensionPaymentsDto), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<UpdatePensionPaymentsDto>> UpdatePensionPaymentDetails(
            [FromQuery][Required]string customerNumber,
            [FromRoute][Required]string accountNumber,
            [FromBody][Required]PensionPaymentUpdateRequest pensionRequest,
            CancellationToken cancellation)
        {
            var pensionPaymentUpdateRequest = new UpdatePensionPaymentDetailsCommand()
            {
                AccountNumber = accountNumber,
                ConfirmId = pensionRequest.ConfirmId,
                TransactionId = pensionRequest.TransactionId,
                ProcessMode = pensionRequest.ProcessMode,
                AnnualPensionRequested = pensionRequest.AnnualPensionRequested,
                GrossPerPaymentAmount = pensionRequest.GrossPerPaymentAmount,
                IncreasedByCpi = pensionRequest.IncreasedByCpi,
                CpiRate = pensionRequest.CpiRate,
                PaymentFrequency = pensionRequest.PaymentFrequency,
                NextPaymentDate = pensionRequest.NextPaymentDate,
                ProRata = pensionRequest.ProRata,
                IncomeVariationType = pensionRequest.IncomeVariationType,
                IncomeVariationPercent = pensionRequest.IncomeVariationPercent,
                GrossSpecifiedAnnualAmount = pensionRequest.GrossSpecifiedAnnualAmount,
                BankBsbNumber = pensionRequest.BankBsbNumber,
                BankAccountNumber = pensionRequest.BankAccountNumber,
                BankAccountName = pensionRequest.BankAccountName,
                PensionPaymentDetails = pensionRequest.PensionPaymentDetails,
                PrinterId = pensionRequest.PrinterId,
                ManagedAccountPensionDrawdownAutoAlign = pensionRequest.ManagedAccountPensionDrawdownAutoAlign,
                OutOfBand = OutOfBandFactory.Create(
                    pensionRequest.SessionId,
                    pensionRequest.Channel,
                    pensionRequest.CompanyCode,
                    customerNumber,
                    pensionRequest.AdviserCode,
                    pensionRequest.DealerCode,
                    pensionRequest.StaffOin,
                    pensionRequest.SourceChannel)
            };

            var response = await Mediator.Send(pensionPaymentUpdateRequest, cancellation);

            return response.ToTypedActionResult<UpdatePensionPaymentsDto>();
        }

        [HttpPatch("{accountNumber}/insurance")]
        [ValidateModelState]
        [ValidateStringNumber("sessionId", "companyCode", "customerNumber", "accountNumber")]
        [ProducesResponseType(typeof(AccountTransactionsDto), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<UpdateInsuranceResponse>> UpdateInsurance(
            [FromRoute][Required] string accountNumber,
            [FromHeader][Optional] string sessionId,
            [FromHeader][Optional]string channel,
            [FromHeader][Required] string companyCode,
            [FromQuery][Required] string customerNumber,
            JsonPatchDocument<InsuranceDto> insurancePatch,
            CancellationToken cancellation)
        {
            var request = new UpdateInsuranceCommand
            {
                AccountNumber = accountNumber,
                PatchDocument = insurancePatch,
                OutOfBand = OutOfBandFactory.Create(
                    sessionId,
                    channel,
                    companyCode,
                    customerNumber)
            };

            var response = await Mediator.Send(request, cancellation);

            return response.ToTypedActionResult<UpdateInsuranceResponse>();
        }
    }
}
