﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Wealth.Api.Account.Application.Infrastructure;
using Wealth.Api.Account.Infrastructure.Fms.Infrastructure;
using Wealth.Toolkit.Fms;

namespace Wealth.Api.Account.Host.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddDependencies(this IServiceCollection services, IConfiguration configuration)
        {
            return services
                .Configure<FmsGatewayApiSettings>(configuration.GetSection("FmsGatewayApi"))
                .AddHttpClient()
                .AddOptions()
                .AddHttpContextAccessor()
                .AddApplication()
                .AddInfrastructure();
        }
    }
}
