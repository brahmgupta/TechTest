﻿using System.Threading.Tasks;
using FluentResults;

namespace Wealth.Api.Account.Core.Queries
{
    public interface ITransactionQueries
    {
        Task<Result<TransactionsDto>> GetTransactions(GetTransactionsRequest request);
    }
}
