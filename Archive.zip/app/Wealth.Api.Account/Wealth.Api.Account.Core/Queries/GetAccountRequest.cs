﻿namespace Wealth.Api.Account.Core.Queries
{
    public class GetAccountRequest : RequestContext
    {
        public string AccountNumber { get; set; }
    }
}
