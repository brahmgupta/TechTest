﻿using System.Collections.Generic;

namespace Wealth.Api.Account.Core.Queries
{
    public class TransactionsDto
    {
        public string AccountNumber { get; set; }
        public IEnumerable<TransactionDto> Transactions { get; set; }
    }
}
