﻿namespace Wealth.Api.Account.Core.Queries
{
    public class InsuranceDto
    {
        public decimal TotalDeathCoverAmount { get; set; }
        public decimal EmployerSelectedDeathCoverPremium { get; set; }
        public decimal InvestorSelectedDeathCoverPremium { get; set; }
        public decimal TotalTpdCoverAmount { get; set; }
        public decimal EmployerSelectedTpdCoverPremium { get; set; }
        public decimal InvestorSelectedTpdCoverPremium { get; set; }
        public decimal TotalSciCoverAmount { get; set; }
        public decimal TotalSciCoverPremium { get; set; }
        public decimal WaitingPeriod { get; set; }
        public decimal MaximumBenefitPeriod { get; set; }
    }
}
