using System;
using System.Collections.Generic;

namespace Wealth.Api.Account.Core.Queries
{
    public class AccountDto
    {
        public string AccountNumber { get; set; }

        public string ProductName { get; set; }

        public string ProductCode { get; set; }

        public string ProductType { get; set; }

        public bool IsAnnuity { get; set; }

        public decimal AccountBalance { get; set; }

        public DateTime? EffectiveDate { get; set; }

        public IEnumerable<BeneficiaryDto> Beneficiaries { get; set; }

        public IEnumerable<InvestmentOptionDto> InvestmentOptions { get; set; }

        public InsuranceDto Insurance { get; set; }

        public string Status { get; set; }
    }
}
