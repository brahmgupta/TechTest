using System;
using System.Collections.Generic;
using System.Linq;
using Wealth.Api.Account.Core.Domain.Exceptions;
using Wealth.Api.Account.Core.Domain.SeedWork;

namespace Wealth.Api.Account.Core.Queries
{
    public class BeneficiaryType : Enumeration
    {
        public static BeneficiaryType None = new BeneficiaryType(0, nameof(None));
        public static BeneficiaryType Nominated = new BeneficiaryType(1, nameof(Nominated));
        public static BeneficiaryType NonLapsingDeath = new BeneficiaryType(2, "Non-lapsing death");
        public static BeneficiaryType Reversionary = new BeneficiaryType(3, nameof(Reversionary));

        protected BeneficiaryType()
        {
        }

        public BeneficiaryType(int id, string name)
            : base(id, name)
        {
        }

        public static IEnumerable<BeneficiaryType> List() => new[] {None, Nominated, NonLapsingDeath, Reversionary};

        public static BeneficiaryType FromName(string name)
        {
            var type = List()
                .SingleOrDefault(s => string.Equals(s.Name, name, StringComparison.CurrentCultureIgnoreCase));

            if (type == null)
            {
                throw new AccountDomainException($"Possible values for BeneficiaryType: {string.Join(",", List().Select(s => s.Name))}");
            }

            return type;
        }

        public static BeneficiaryType From(int id)
        {
            var type = List().SingleOrDefault(s => s.Id == id);

            if (type == null)
            {
                throw new AccountDomainException($"Possible values for BeneficiaryType: {string.Join(",", List().Select(s => s.Name))}");
            }

            return type;
        }
    }
}
