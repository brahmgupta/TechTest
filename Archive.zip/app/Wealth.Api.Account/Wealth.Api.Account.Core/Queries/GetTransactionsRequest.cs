﻿
namespace Wealth.Api.Account.Core.Queries
{
    public class GetTransactionsRequest : RequestContext
    {
        public string AccountNumber { get; set; }
    }
}
