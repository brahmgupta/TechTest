﻿namespace Wealth.Api.Account.Core
{
    public class Constants
    {
        public class ErrorCodes
        {
            public static string AccountNotFound = "ACCOUNT_NOT_FOUND";
        }
    }
}
