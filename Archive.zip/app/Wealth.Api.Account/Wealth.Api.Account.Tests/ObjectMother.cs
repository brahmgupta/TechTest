﻿using System;
using AutoFixture;
using Wealth.Api.Account.Domain.AccountAggregate;

namespace Wealth.Api.Account.Tests
{
    internal class ObjectMother
    {
        private static readonly IFixture Fixture = new Fixture();
        public static AccountDetails CreateAccountDetails(AccessMode accessMode = AccessMode.Full)
        {
            return new AccountDetails(
                accountNumber: Fixture.Create<int>().ToString(),
                accountType: Fixture.Create<AccountType>(),
                productName: Fixture.Create<string>(),
                productCode: Fixture.Create<string>(),
                accountBalance: Fixture.Create<decimal>(),
                effectiveDate: Fixture.Create<DateTime>(),
                status: Fixture.Create<AccountStatus>(),
                productAbbreviation: Fixture.Create<string>(),
                nextPaymentDate: Fixture.Create<DateTime>(),
                nextPaymentAmount: Fixture.Create<decimal>(),
                accountDesignation: Fixture.Create<string>(),
                ownerName: Fixture.Create<string>(),
                accessMode: accessMode);
        }
    }
}