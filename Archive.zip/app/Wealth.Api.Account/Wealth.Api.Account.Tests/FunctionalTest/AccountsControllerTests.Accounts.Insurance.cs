﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Newtonsoft.Json;
using Wealth.Api.Account.Application.Models;
using Wealth.Api.Account.Infrastructure.Fms.Infrastructure;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Iesf;
using Wealth.Toolkit.Test;
using Xunit;

namespace Wealth.Api.Account.Tests.FunctionalTest
{
    public partial class AccountsControllerTests : BaseTest
    {
        class InsuranceTestData
        {
            public decimal AccountValue { get; set; }
            public int AccountNumber { get; set; }
            public string ProductType { get; set; }
            public decimal IemployerSelectedDeathCoverAmount { get; set; }
            public decimal IinvestorSelectedDeathCoverAmount { get; set; }
            public decimal ItotalDeathCoverAmount { get; set; }
            public decimal IemployerSelectedDeathCoverPremium { get; set; }
            public decimal IinvestorSelectedDeathCoverPremium { get; set; }
            public decimal ItotalDeathCoverPremium { get; set; }
            public decimal IemployerSelectedTpdCoverAmount { get; set; }
            public decimal IinvestorSelectedTpdCoverAmount { get; set; }
            public decimal ItotalTpdCoverAmount { get; set; }
            public decimal IemployerSelectedTpdCoverPremium { get; set; }
            public decimal IinvestorSelectedTpdCoverPremium { get; set; }
            public decimal ItotalTpdCoverPremium { get; set; }
            public decimal IemployerSelectedSciCoverAmount { get; set; }
            public decimal IinvestorSelectedSciCoverAmount { get; set; }
            public decimal ItotalSciCoverAmount { get; set; }
            public decimal IemployerSelectedSciCoverPremium { get; set; }
            public decimal IinvestorSelectedSciCoverPremium { get; set; }
            public decimal ItotalSciCoverPremium { get; set; }
            public decimal IwaitingPeriod { get; set; }
            public decimal ImaximumBenefitPeriod { get; set; }
            public DateTime IinsuranceElectionDate { get; set; }
            public string IoccupationClassification { get; set; }
            public bool? IisSmoker { get; set; }


        }

        class InsuranceExpectedData
        {
            public string EexpProductType { get; set; }
            public decimal EemployerSelectedDeathCoverAmount { get; set; }
            public decimal EinvestorSelectedDeathCoverAmount { get; set; }
            public decimal EtotalDeathCoverAmount { get; set; }
            public decimal EemployerSelectedDeathCoverPremium { get; set; }
            public decimal EinvestorSelectedDeathCoverPremium { get; set; }
            public decimal EtotalDeathCoverPremium { get; set; }
            public decimal EemployerSelectedTpdCoverAmount { get; set; }
            public decimal EinvestorSelectedTpdCoverAmount { get; set; }
            public decimal EtotalTpdCoverAmount { get; set; }
            public decimal EemployerSelectedTpdCoverPremium { get; set; }
            public decimal EinvestorSelectedTpdCoverPremium { get; set; }
            public decimal EtotalTpdCoverPremium { get; set; }
            public decimal EemployerSelectedSciCoverAmount { get; set; }
            public decimal EinvestorSelectedSciCoverAmount { get; set; }
            public decimal EtotalSciCoverAmount { get; set; }
            public decimal EemployerSelectedSciCoverPremium { get; set; }
            public decimal EinvestorSelectedSciCoverPremium { get; set; }
            public decimal EtotalSciCoverPremium { get; set; }
            public decimal EwaitingPeriod { get; set; }
            public decimal EmaximumBenefitPeriod { get; set; }
            public DateTime EinsuranceElectionDate { get; set; }
            public string EoccupationClassification { get; set; }
            public bool? EisSmoker { get; set; }
        }

        Dictionary<string, Action<InsuranceTestData>> callInsuranceMock;
        private void BuildInsuranceMocks()
        {
            callInsuranceMock = new Dictionary<string, Action<InsuranceTestData>>
            {
                { SuperFund, CallSuperAccountForInsuranceMock },
            };
        }

        private void CallSuperAccountForInsuranceMock(InsuranceTestData data)
        {
            MockGetAccountsRplResponse(data.AccountValue, data.AccountNumber, data.ProductType);
            MockGetAccountInsuranceRplResponse(data.IemployerSelectedDeathCoverAmount, data.IemployerSelectedDeathCoverPremium, data.IemployerSelectedSciCoverAmount, data.IemployerSelectedSciCoverPremium,data.IemployerSelectedTpdCoverAmount,
                data.IemployerSelectedTpdCoverPremium, data.IinvestorSelectedDeathCoverAmount, data.IinvestorSelectedDeathCoverPremium, data.IinvestorSelectedSciCoverAmount, data.IinvestorSelectedSciCoverPremium, data.IinvestorSelectedTpdCoverAmount, data.IinvestorSelectedTpdCoverPremium,
                data.ImaximumBenefitPeriod, data.ItotalDeathCoverAmount, data.ItotalDeathCoverPremium, data.ItotalSciCoverAmount, data.ItotalSciCoverPremium, data.ItotalTpdCoverAmount, data.ItotalTpdCoverPremium, data.IwaitingPeriod, data.IinsuranceElectionDate, data.IoccupationClassification, data.IisSmoker);
            MockGetSuperannuationAccountInvestmentsRplResponse();
            MockGetInvestmentAssetAllocationRplResponse();
        }

        Dictionary<string, Action<InsuranceExpectedData>> insuranceValidation;
        private void BuildInsuranceResponse()
        {
            insuranceValidation = new Dictionary<string, Action<InsuranceExpectedData>>
            {
                { SuperFund, ValidateSuperAccountInsuranceResponse }
            };
        }

        private void MockGetAccountInsuranceRplResponse(decimal IemployerSelectedDeathCoverAmount, decimal IemployerSelectedDeathCoverPremium, decimal IemployerSelectedSciCoverAmount, 
            decimal IemployerSelectedSciCoverPremium, decimal IemployerSelectedTpdCoverAmount, decimal IemployerSelectedTpdCoverPremium, decimal IinvestorSelectedDeathCoverAmount, decimal IinvestorSelectedDeathCoverPremium, 
            decimal IinvestorSelectedSciCoverAmount, decimal IinvestorSelectedSciCoverPremium, decimal IinvestorSelectedTpdCoverAmount, decimal IinvestorSelectedTpdCoverPremium, decimal ImaximumBenefitPeriod, decimal ItotalDeathCoverAmount, decimal ItotalDeathCoverPremium, decimal ItotalSciCoverAmount, decimal ItotalSciCoverPremium, decimal ItotalTpdCoverAmount, 
            decimal ItotalTpdCoverPremium, decimal IwaitingPeriod, DateTime IinsuranceElectionDate, string IoccupationClassification, bool? IisSmoker)
        {

            var rplResponse = MyFixture.Build<GetAccountInsuranceRplResponse>()
            .With(p => p.BindingNominationDetailCount, 0)
            .With(p => p.EmployerSelectedDeathAmount, IemployerSelectedDeathCoverAmount)
            .With(p => p.EmployerSelectedDeathPremium, IemployerSelectedDeathCoverPremium)
            .With(p => p.EmployerSelectedSciAmount, IemployerSelectedSciCoverAmount)
            .With(p => p.EmployerSelectedSciPremium, IemployerSelectedSciCoverPremium)
            .With(p => p.EmployerSelectedTpdAmount, IemployerSelectedTpdCoverAmount)
            .With(p => p.EmployerSelectedTpdPremium, IemployerSelectedTpdCoverPremium)
            .With(p => p.InvestorSelectedDeathAmount, IinvestorSelectedDeathCoverAmount)
            .With(p => p.InvestorSelectedDeathPremium, IinvestorSelectedDeathCoverPremium)
            .With(p => p.InvestorSelectedSciAmount, IinvestorSelectedSciCoverAmount)
            .With(p => p.InvestorSelectedSciPremium, IinvestorSelectedSciCoverPremium)
            .With(p => p.InvestorSelectedTpdAmount, IinvestorSelectedTpdCoverAmount)
            .With(p => p.InvestorSelectedTpdPremium, IinvestorSelectedTpdCoverPremium)
            .With(p => p.MaximumBenefitPeriod, ImaximumBenefitPeriod)
            .With(p => p.WaitingPeriod, IwaitingPeriod)
            .With(p => p.TotalDeathCoverAmount, ItotalDeathCoverAmount)
            .With(p => p.TotalSciCoverAmount, ItotalSciCoverAmount)
            .With(p => p.TotalTpdCoverAmount, ItotalTpdCoverAmount)
            .With(p => p.TotalSciPremium, ItotalSciCoverPremium)
            .With(p => p.InsuranceElectionDate, FmsType.ToDecimalDate(IinsuranceElectionDate))
            .With(p => p.OccupationDescription, IoccupationClassification)
            .With(p => p.IsSmoker, FmsType.ToFmsBoolean(IisSmoker))
            .With(p => p.MessageIndicator, 0)
            .Without(p => p.MessageType)
            .Without(p => p.Messages)
            .Create();

            MockRplResponse("FIRIESFJ", rplResponse);
        }

        private void ValidateSuperAccountInsuranceResponse(InsuranceExpectedData expData)
        {
            account.Insurance.EmployerSelectedDeathCoverAmount.Should().Be(expData.EemployerSelectedDeathCoverAmount);
            account.Insurance.EmployerSelectedDeathCoverPremium.Should().Be(expData.EemployerSelectedDeathCoverPremium);
            account.Insurance.EmployerSelectedSciCoverAmount.Should().Be(expData.EemployerSelectedSciCoverAmount);
            account.Insurance.EmployerSelectedSciCoverPremium.Should().Be(expData.EemployerSelectedSciCoverPremium);
            account.Insurance.EmployerSelectedTpdCoverAmount.Should().Be(expData.EemployerSelectedTpdCoverAmount);
            account.Insurance.EmployerSelectedTpdCoverPremium.Should().Be(expData.EemployerSelectedTpdCoverPremium);
            account.Insurance.InvestorSelectedDeathCoverAmount.Should().Be(expData.EinvestorSelectedDeathCoverAmount);
            account.Insurance.InvestorSelectedDeathCoverPremium.Should().Be(expData.EinvestorSelectedDeathCoverPremium);
            account.Insurance.InvestorSelectedSciCoverAmount.Should().Be(expData.EinvestorSelectedSciCoverAmount);
            account.Insurance.InvestorSelectedSciCoverPremium.Should().Be(expData.EinvestorSelectedSciCoverPremium);
            account.Insurance.InvestorSelectedTpdCoverAmount.Should().Be(expData.EinvestorSelectedTpdCoverAmount);
            account.Insurance.InvestorSelectedTpdCoverPremium.Should().Be(expData.EinvestorSelectedTpdCoverPremium);
            account.Insurance.TotalDeathCoverAmount.Should().Be(expData.EtotalDeathCoverAmount);
            account.Insurance.TotalDeathCoverPremium.Should().Be(expData.EtotalDeathCoverPremium);
            account.Insurance.TotalSciCoverAmount.Should().Be(expData.EtotalSciCoverAmount);
            account.Insurance.TotalSciCoverPremium.Should().Be(expData.EtotalSciCoverPremium);
            account.Insurance.TotalTpdCoverAmount.Should().Be(expData.EtotalTpdCoverAmount);
            account.Insurance.TotalTpdCoverPremium.Should().Be(expData.EtotalTpdCoverPremium);
            account.Insurance.MaximumBenefitPeriod.Should().Be(expData.EmaximumBenefitPeriod);
            account.Insurance.WaitingPeriod.Should().Be(expData.EwaitingPeriod);
            account.Insurance.InsuranceElectionDate.Should().Be(expData.EinsuranceElectionDate);
            account.Insurance.OccupationClassification.Should().Be(expData.EoccupationClassification);
            account.Insurance.IsSmoker.Should().Be(expData.EisSmoker);
        }

        [Theory]
        [ExcelData("FunctionalTest\\Account_Get_Insurance_TestData.xlsx")]
        public async Task ShouldSuccessfullyGetInsuranceDetailsForAccountWithAllInsurance(string productType, decimal IemployerSelectedDeathCoverAmount, decimal IemployerSelectedDeathCoverPremium, decimal IemployerSelectedSciCoverAmount,
            decimal IemployerSelectedSciCoverPremium, decimal IemployerSelectedTpdCoverAmount, decimal IemployerSelectedTpdCoverPremium, decimal IinvestorSelectedDeathCoverAmount, decimal IinvestorSelectedDeathCoverPremium,
            decimal IinvestorSelectedSciCoverAmount, decimal IinvestorSelectedSciCoverPremium, decimal IinvestorSelectedTpdCoverAmount, decimal IinvestorSelectedTpdCoverPremium, decimal ItotalDeathCoverAmount, decimal ItotalDeathCoverPremium, decimal ItotalSciCoverAmount, 
            decimal ItotalSciCoverPremium, decimal ItotalTpdCoverAmount, decimal ItotalTpdCoverPremium, decimal ImaximumBenefitPeriod, decimal IwaitingPeriod, DateTime IinsuranceElectionDate, string IoccupationClassification, bool? IisSmoker, string expProductType, decimal EemployerSelectedDeathCoverAmount, decimal EemployerSelectedDeathCoverPremium, decimal EemployerSelectedSciCoverAmount,
            decimal EemployerSelectedSciCoverPremium, decimal EemployerSelectedTpdCoverAmount, decimal EemployerSelectedTpdCoverPremium, decimal EinvestorSelectedDeathCoverAmount, decimal EinvestorSelectedDeathCoverPremium,
            decimal EinvestorSelectedSciCoverAmount, decimal EinvestorSelectedSciCoverPremium, decimal EinvestorSelectedTpdCoverAmount, decimal EinvestorSelectedTpdCoverPremium, decimal EtotalDeathCoverAmount, decimal EtotalDeathCoverPremium, decimal EtotalSciCoverAmount,
            decimal EtotalSciCoverPremium, decimal EtotalTpdCoverAmount, decimal EtotalTpdCoverPremium, decimal EmaximumBenefitPeriod, decimal EwaitingPeriod, DateTime EinsuranceElectionDate, string EoccupationClassification, bool? EisSmoker)
        {
            var accountValue = MyFixture.Create<decimal>();
            var accountNumber = MyFixture.Create<int>();

            // Arrange
            var myTestData = new InsuranceTestData
            {
                AccountNumber = accountNumber,
                ProductType = productType,
                IemployerSelectedDeathCoverAmount = IemployerSelectedDeathCoverAmount,
                IemployerSelectedDeathCoverPremium = IemployerSelectedDeathCoverPremium,
                IemployerSelectedSciCoverAmount = IemployerSelectedSciCoverAmount,
                IemployerSelectedSciCoverPremium = IemployerSelectedSciCoverPremium,
                IemployerSelectedTpdCoverAmount = IemployerSelectedTpdCoverAmount,
                IemployerSelectedTpdCoverPremium = IemployerSelectedTpdCoverPremium,
                IinvestorSelectedDeathCoverAmount = IinvestorSelectedDeathCoverAmount,
                IinvestorSelectedDeathCoverPremium = IinvestorSelectedDeathCoverPremium,
                IinvestorSelectedSciCoverAmount = IinvestorSelectedSciCoverAmount,
                IinvestorSelectedSciCoverPremium = IinvestorSelectedSciCoverPremium,
                IinvestorSelectedTpdCoverAmount = IinvestorSelectedTpdCoverAmount,
                IinvestorSelectedTpdCoverPremium = IinvestorSelectedTpdCoverPremium,
                ItotalDeathCoverAmount = ItotalDeathCoverAmount,
                ItotalDeathCoverPremium = ItotalDeathCoverPremium,
                ItotalSciCoverAmount = ItotalSciCoverAmount,
                ItotalSciCoverPremium = ItotalSciCoverPremium,
                ItotalTpdCoverAmount = ItotalTpdCoverAmount,
                ItotalTpdCoverPremium = ItotalTpdCoverPremium,
                ImaximumBenefitPeriod = ImaximumBenefitPeriod,
                IwaitingPeriod = IwaitingPeriod,
                IinsuranceElectionDate = IinsuranceElectionDate,
                IoccupationClassification = IoccupationClassification,
                IisSmoker = IisSmoker
            };

            var myExpectedTestData = new InsuranceExpectedData
            {
                EexpProductType = expProductType,
                EemployerSelectedDeathCoverAmount = EemployerSelectedDeathCoverAmount,
                EemployerSelectedDeathCoverPremium = EemployerSelectedDeathCoverPremium,
                EemployerSelectedSciCoverAmount = EemployerSelectedSciCoverAmount,
                EemployerSelectedSciCoverPremium = EemployerSelectedSciCoverPremium,
                EemployerSelectedTpdCoverAmount = EemployerSelectedTpdCoverAmount,
                EemployerSelectedTpdCoverPremium = EemployerSelectedTpdCoverPremium,
                EinvestorSelectedDeathCoverAmount = EinvestorSelectedDeathCoverAmount,
                EinvestorSelectedDeathCoverPremium = EinvestorSelectedDeathCoverPremium,
                EinvestorSelectedSciCoverAmount = EinvestorSelectedSciCoverAmount,
                EinvestorSelectedSciCoverPremium = EinvestorSelectedSciCoverPremium,
                EinvestorSelectedTpdCoverAmount = EinvestorSelectedTpdCoverAmount,
                EinvestorSelectedTpdCoverPremium = EinvestorSelectedTpdCoverPremium,
                EtotalDeathCoverAmount = EtotalDeathCoverAmount,
                EtotalDeathCoverPremium = EtotalDeathCoverPremium,
                EtotalSciCoverAmount = EtotalSciCoverAmount,
                EtotalSciCoverPremium = EtotalSciCoverPremium,
                EtotalTpdCoverAmount = EtotalTpdCoverAmount,
                EtotalTpdCoverPremium = EtotalTpdCoverPremium,
                EmaximumBenefitPeriod = EmaximumBenefitPeriod,
                EwaitingPeriod = EwaitingPeriod,
                EinsuranceElectionDate = EinsuranceElectionDate,
                EoccupationClassification = EoccupationClassification,
                EisSmoker = EisSmoker
            };

            //Calling product type
            callInsuranceMock[productType](myTestData);

            // Act
            var response = await CreateRequestBuilder($"/api/accounts/{accountNumber}?customerNumber=12345").GetAsync();

            // Assert
            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            account = JsonConvert.DeserializeObject<AccountDto>(jsonResponse);

            //Test Validation
            insuranceValidation[productType](myExpectedTestData);
        }
    }
}
