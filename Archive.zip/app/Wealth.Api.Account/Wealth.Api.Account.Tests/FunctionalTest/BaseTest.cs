﻿using System.IO;
using AutoFixture;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using RichardSzalay.MockHttp;

namespace Wealth.Api.Account.Tests.FunctionalTest
{
    public abstract class BaseTest
    {
        protected TestServer Server { get; }
        protected MockHttpMessageHandler MockHttp { get; }
        public AppSettings AppSettings { get; }

        protected Fixture MyFixture;
        protected BaseTest()
        {
            MyFixture = new Fixture();
            var config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", true, true)
                .Build();

            Server = new TestServer(new WebHostBuilder()
                .UseConfiguration(config)
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseStartup<TestStartup>());

            MockHttp = Server.Host.Services.GetService<TestHttpMessageHandler>().Instance;
            AppSettings = Server.Host.Services.GetService<IOptions<AppSettings>>().Value;
        }

        protected void CleanRoutes()
        {
            MockHttp.Clear();
        }

        protected bool? StringToNullableBool(string str)
        {
            if (str.ToLower().Equals("true")) return true;
            if (str.ToLower().Equals("false")) return false;
            return null;
        }
    }
}
