﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AutoFixture;
using FluentAssertions;
using Newtonsoft.Json;
using Wealth.Api.Account.Application.Models;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Aapp;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Aasf;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Aaut;
using Wealth.Api.Account.Infrastructure.Fms.Rpls.Ewaa;
using Wealth.Toolkit.Test;
using Xunit;

namespace Wealth.Api.Account.Tests.FunctionalTest
{
    public partial class AccountsControllerTests
    {
        private static readonly List<string> AssetClasses = new List<string>
        {
            "Cash",
            "Australian Fixed Interest",
            "Global Fixed Interest",
            "Australian Shares",
            "Global Shares",
            "Property"
        };

        private class InvestmentsTestData
        {
            public decimal AccountValue { get; set; }
            public int AccountNumber { get; set; }
            public string ProductType { get; set; }
            public int IoptionCount { get; set; }
            public List<string> IoptionName { get; set; }
            public List<decimal> IoptionUnits { get; set; }
            public List<decimal> IoptionUnitPrice { get; set; }
            public List<decimal> IoptionAmount { get; set; }
            public List<string> IoptionAssetType { get; set; }
            public List<decimal> IoptionCurrentInterestRate { get; set; }
            public List<string> IoptionProductGroup { get; set; }
            public List<decimal> IassetAmounts { get; set; }
            public List<decimal> IassetPercentage { get; set; }
            public List<decimal> IassetEffectiveDate { get; set; }
        }

        private class InvestmentsExpectedData
        {
            public int EoptionCount { get; set; }
            public List<string> EoptionName { get; set; }
            public List<decimal> EoptionUnits { get; set; }
            public List<decimal> EoptionUnitPrice { get; set; }
            public List<decimal> EoptionAmount { get; set; }
            public List<string> EoptionAssetType { get; set; }
            public List<decimal> EoptionCurrentInterestRate { get; set; }
            public List<string> EoptionProductGroup { get; set; }
            public List<decimal> EoptionPercentage { get; set; }
            public List<string> EoptionAssetEffectiveDate { get; set; }
            public List<decimal> EassetPercentage { get; set; }
            public List<decimal> EassetValue { get; set; }
        }

        private Dictionary<string, Action<InvestmentsTestData>> _callInvestmentsMock;
        private Dictionary<string, Action<int, string>> _callNoInvestmentsMock;

        private void BuildInvestmentsMocks()
        {
            _callInvestmentsMock = new Dictionary<string, Action<InvestmentsTestData>>()
            {
                { SuperFund, CallSuperAccountForInvestmentsMock },
                { PensionFund, CallPensionFundForInvestmentsMock },
                { UnitTrust, CallUnitTrustForInvestmentsMock }
            };
            _callNoInvestmentsMock = new Dictionary<string, Action<int, string>>()
            {
                { SuperFund, CallSuperAccountForNoInvestmentsMock },
                { PensionFund, CallPensionFundForNoInvestmentsMock },
                { UnitTrust, CallUnitTrustForNoInvestmentsMock }
            };
        }

        Dictionary<string, Action<InvestmentsExpectedData>> _investmentsValidation;
        private void BuildInvestmentsResponse()
        {
            _investmentsValidation = new Dictionary<string, Action<InvestmentsExpectedData>>
            {
                { SuperFund, ValidateInvestmentsData },
                { PensionFund, ValidateInvestmentsData },
                { UnitTrust, ValidateInvestmentsData }
            };
        }

        private void CallSuperAccountForNoInvestmentsMock(int accountNumber, string productType)
        {
            var accountValue = MyFixture.Create<decimal>();

            MockGetAccountsRplResponse(accountValue, accountNumber, productType);

            MockGetAccountBeneficiaryRplResponse(
                new List<decimal>(),
                "", new List<string>(),
                new List<decimal>(),
                new List<string>(),
                new List<string>(),
                new decimal());

            MockGetSuperannuationAccountInvestmentsRplResponse();

            MockGetInvestmentAssetAllocationRplResponse();
        }

        private void CallPensionFundForNoInvestmentsMock(int accountNumber, string productType)
        {
            var accountValue = MyFixture.Create<decimal>();

            MockGetAccountsRplResponse(accountValue, accountNumber, productType);

            MockGetPensionInvestmentsRplResponse(
                investmentOptionDetailCount: 0,
                investmentOptionName: new List<string>(),
                investmentOptionUnits: new List<decimal>(),
                investmentOptionUnitPrice: new List<decimal>(),
                investmentOptionAmount: new List<decimal>(),
                investmentOptionProductGroup: new List<string>());
            
            MockGetInvestmentAssetAllocationRplResponse();
        }

        private void CallUnitTrustForNoInvestmentsMock(int accountNumber, string productType)
        {
            var accountValue = MyFixture.Create<decimal>();

            MockGetAccountsRplResponse(accountValue, accountNumber, productType);

            MockGetAccountBeneficiaryRplResponse(
                new List<decimal>(),
                "", new List<string>(),
                new List<decimal>(),
                new List<string>(),
                new List<string>(),
                new decimal());

            MockGetUnitTrustInvestmentsRplResponse(
                investmentOptionDetailCount: 0,
                investmentOptionName: new List<string>(),
                investmentOptionUnits: new List<decimal>(),
                investmentOptionUnitPrice: new List<decimal>(),
                investmentOptionAmount: new List<decimal>(),
                investmentOptionProductGroup: new List<string>(),
                investmentCurrentInterestRate: new List<decimal>());
                
            MockGetInvestmentAssetAllocationRplResponse();
        }

        private void CallSuperAccountForInvestmentsMock(InvestmentsTestData data)
        {
            MockGetAccountsRplResponse(data.AccountValue, data.AccountNumber, data.ProductType);

            MockGetAccountBeneficiaryRplResponse(
                new List<decimal>(),
                "", new List<string>(),
                new List<decimal>(),
                new List<string>(),
                new List<string>(),
                new decimal());

            MockGetSuperannuationAccountInvestmentsRplResponse(
                investmentOptionDetailCount: data.IoptionCount,
                investmentOptionName: data.IoptionName,
                investmentOptionUnits: data.IoptionUnits,
                investmentOptionUnitPrice: data.IoptionUnitPrice,
                investmentOptionAmount: data.IoptionAmount,
                investmentOptionProductGroup: data.IoptionProductGroup);

            MockGetInvestmentAssetAllocationRplResponse(
                investmentsCount: data.IoptionCount,
                investmentAmounts: data.IassetAmounts,
                investmentAllocations: data.IassetPercentage,
                investmentEffectiveDates: data.IassetEffectiveDate);
        }

        private void CallPensionFundForInvestmentsMock(InvestmentsTestData data)
        {
            MockGetAccountsRplResponse(data.AccountValue, data.AccountNumber, data.ProductType);

            MockGetPensionInvestmentsRplResponse(
                investmentOptionDetailCount: data.IoptionCount,
                investmentOptionName: data.IoptionName,
                investmentOptionUnits: data.IoptionUnits,
                investmentOptionUnitPrice: data.IoptionUnitPrice,
                investmentOptionAmount: data.IoptionAmount,
                investmentOptionProductGroup: data.IoptionProductGroup);

            MockGetInvestmentAssetAllocationRplResponse(
                investmentsCount: data.IoptionCount,
                investmentAmounts: data.IassetAmounts,
                investmentAllocations: data.IassetPercentage,
                investmentEffectiveDates: data.IassetEffectiveDate);
        }

        private void CallUnitTrustForInvestmentsMock(InvestmentsTestData data)
        {
            MockGetAccountsRplResponse(data.AccountValue, data.AccountNumber, data.ProductType);

            MockGetAccountBeneficiaryRplResponse(
                new List<decimal>(),
                "", new List<string>(),
                new List<decimal>(),
                new List<string>(),
                new List<string>(),
                new decimal());

            MockGetUnitTrustInvestmentsRplResponse(
                investmentOptionDetailCount: data.IoptionCount,
                investmentOptionName: data.IoptionName,
                investmentOptionUnits: data.IoptionUnits,
                investmentOptionUnitPrice: data.IoptionUnitPrice,
                investmentOptionAmount: data.IoptionAmount,
                investmentOptionProductGroup: data.IoptionProductGroup,
                investmentCurrentInterestRate: data.IoptionCurrentInterestRate);

            MockGetInvestmentAssetAllocationRplResponse(
                investmentsCount: data.IoptionCount,
                investmentAmounts: data.IassetAmounts,
                investmentAllocations: data.IassetPercentage,
                investmentEffectiveDates: data.IassetEffectiveDate);
        }

        private void MockGetSuperannuationAccountInvestmentsRplResponse(
            decimal investmentOptionDetailCount,
            List<string> investmentOptionName,
            List<decimal> investmentOptionUnits,
            List<decimal> investmentOptionUnitPrice,
            List<decimal> investmentOptionAmount,
            List<string> investmentOptionProductGroup)
        {
            var rplResponse = MyFixture.Build<SuperannuationAccountInvestmentsRplResponse>()
                .With(p => p.InvestmentOptionDetailCount, 1)
                .With(p => p.MessageIndicator, 0)
                .With(p => p.InvestmentOptionAmount, investmentOptionAmount)
                .With(p => p.InvestmentOptionDetailCount, investmentOptionDetailCount)
                .With(p => p.InvestmentOptionName, investmentOptionName)
                .With(p => p.InvestmentOptionProductGroup, investmentOptionProductGroup)
                .With(p => p.InvestmentOptionUnitPrice, investmentOptionUnitPrice)
                .With(p => p.InvestmentOptionUnits, investmentOptionUnits)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRAASFH", rplResponse);
        }

        private void MockGetPensionInvestmentsRplResponse(
            decimal investmentOptionDetailCount,
            List<string> investmentOptionName,
            List<decimal> investmentOptionUnits,
            List<decimal> investmentOptionUnitPrice,
            List<decimal> investmentOptionAmount,
            List<string> investmentOptionProductGroup)
        {
            var rplResponse = MyFixture.Build<GetPensionAccountDetailsRplResponse>()
                .With(p => p.InvestmentOptionDetailCount, investmentOptionDetailCount)
                .With(p => p.InvestmentOptionName, investmentOptionName)
                .With(p => p.InvestmentOptionUnits, investmentOptionUnits)
                .With(p => p.InvestmentOptionUnitPrice, investmentOptionUnitPrice)
                .With(p => p.InvestmentOptionAmount, investmentOptionAmount)
                .With(p => p.InvestmentOptionProductGroup, investmentOptionProductGroup)
                .With(p => p.BindingNominationDetailCount, 0)
                .With(p => p.BeneficiaryDateOfBirth, new List<decimal>())
                .With(p => p.BeneficiaryType, "")
                .With(p => p.BeneficiaryName, new List<string>())
                .With(p => p.BeneficiaryPercent, new List<decimal>())
                .With(p => p.BeneficiaryDescription, new List<string>())
                .With(p => p.BeneficiaryRelationshipDescription, new List<string>())
                .With(p => p.MessageIndicator, 0)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRAAPPJ", rplResponse);
        }

        private void MockGetUnitTrustInvestmentsRplResponse(
            decimal investmentOptionDetailCount,
            List<string> investmentOptionName,
            List<decimal> investmentOptionUnits,
            List<decimal> investmentOptionUnitPrice,
            List<decimal> investmentOptionAmount,
            List<string> investmentOptionProductGroup,
            List<decimal> investmentCurrentInterestRate)
        {
            var rplResponse = MyFixture.Build<UnitTrustAccountInvestmentsRplResponse>()
                .With(p => p.InvestmentOptionDetailCount, investmentOptionDetailCount)
                .With(p => p.InvestmentOptionName, investmentOptionName)
                .With(p => p.InvestmentOptionUnits, investmentOptionUnits)
                .With(p => p.InvestmentOptionUnitPrice, investmentOptionUnitPrice)
                .With(p => p.InvestmentOptionAmount, investmentOptionAmount)
                .With(p => p.InvestmentOptionProductGroup, investmentOptionProductGroup)
                .With(p => p.CurrentInterestRate, investmentCurrentInterestRate)
                .With(p => p.MessageIndicator, 0)
                .Without(p => p.MessageType)
                .Without(p => p.Messages)
                .Create();

            MockRplResponse("FIRAAUTH", rplResponse);
        }

        private void MockGetInvestmentAssetAllocationRplResponse(
            int investmentsCount,
            List<decimal> investmentAmounts,
            List<decimal> investmentAllocations,
            List<decimal> investmentEffectiveDates)
        {
            var rplResponse = MyFixture.Build<GetInvestmentAssetAllocationsRplResponse>()
                .With(i => i.InvestmentOptionDetailCount, investmentsCount)
                .With(i => i.InvestmentOptionAmount, investmentAmounts)
                .With(i => i.InvestmentTotalAllocationPercentages, investmentAllocations)
                .With(i => i.InvestmentOptionEffectiveDate, investmentEffectiveDates)
                .Without(i => i.MessageType)
                .Without(i => i.Messages)
                .Without(i => i.MessageCount)
                .Without(i => i.MessageIndicator)
                .Create();

            MockRplResponse("FIREWAAA", rplResponse);
        }

        private void ValidateInvestmentsData(InvestmentsExpectedData expData)
        {
            var investmentOptions = account.InvestmentOptions.ToArray();
            var investmentAssetAllocations = account.InvestmentAssetAllocations.ToArray();
            investmentOptions.Length.Should().Be(expData.EoptionCount);

            for (int i = 0; i < investmentOptions.Length; i++)
            {
                investmentOptions[i].Amount.Should().Be(expData.EoptionAmount[i]);
                investmentOptions[i].CurrentInterestRate.Should().Be(expData.EoptionCurrentInterestRate[i]);
                investmentOptions[i].Name.Should().Be(expData.EoptionName[i]);
                investmentOptions[i].ProductGroup.Should().Be(expData.EoptionProductGroup[i]);
                investmentOptions[i].UnitPrice.Should().Be(expData.EoptionUnitPrice[i]);
                investmentOptions[i].Units.Should().Be(expData.EoptionUnits[i]);
                if(expData.EoptionAssetEffectiveDate[i].Equals("null"))
                {
                    investmentOptions[i].AssetAllocationEffectiveDate.Should().BeNull();
                } 
                else
                {
                    investmentOptions[i].AssetAllocationEffectiveDate?.ToString("s")
                        .Should().Be(expData.EoptionAssetEffectiveDate[i]);
                }
                investmentOptions[i].Percentage.Should().Be(expData.EoptionPercentage[i]);
            }

            for (int i = 0; i < AssetClasses.Count; i++)
            {
                investmentAssetAllocations[i].ClassName.Should().Be(AssetClasses[i]);
                investmentAssetAllocations[i].Percentage.Should().Be(expData.EassetPercentage[i]);
                investmentAssetAllocations[i].Value.Should().Be(expData.EassetValue[i]);
            }
        }

        [Theory]
        [ExcelData("FunctionalTest\\Account_Get_Investments_TestData.xlsx")]
        public async Task ShouldSuccessfullyGetInvestments(
            string productType,
            int iOptionCount,
            string iOptionAmount,
            string iOptionCurrentInterestRate,
            string iOptionName,
            string iOptionProductGroup,
            string iOptionUnitPrice,
            string iOptionUnits,
            string iAssetPercentage,
            string iAssetAmounts,
            string IassetEffectiveDate,
            int eOptionCount,
            string eOptionName,
            string eOptionUnits,
            string eOptionUnitPrice,
            string eOptionAmount,
            string eOptionCurrentInterestRate,
            string eOptionProductGroup,
            string eOptionPercentage,
            string eOptionAssetEffectiveDate,
            string eAssetPercentage,
            string eAssetValue)
        {
            // Arrange
            var accountValue = MyFixture.Create<decimal>();
            var accountNumber = MyFixture.Create<int>();
            var testData = new InvestmentsTestData()
            {
                AccountValue = accountValue,
                AccountNumber = accountNumber,
                ProductType = productType,
                IoptionCount = iOptionCount,
                IoptionCurrentInterestRate = iOptionCurrentInterestRate.Split(",").Select(decimal.Parse).ToList(),
                IoptionAmount = iOptionAmount.Split(",").Select(decimal.Parse).ToList(),
                IoptionAssetType = new List<string>(),
                IoptionName = iOptionName.Split(",").ToList(),
                IoptionProductGroup = iOptionProductGroup.Split(",").ToList(),
                IoptionUnitPrice = iOptionUnitPrice.Split(",").Select(decimal.Parse).ToList(),
                IoptionUnits = iOptionUnits.Split(",").Select(decimal.Parse).ToList(),
                IassetAmounts = iAssetAmounts.Split(",").Select(decimal.Parse).ToList(),
                IassetPercentage = iAssetPercentage.Split(",").Select(decimal.Parse).ToList(),
                IassetEffectiveDate = IassetEffectiveDate.Split(",").Select(decimal.Parse).ToList(),
            };

            var expectedTestData = new InvestmentsExpectedData()
            {
                EoptionCount = eOptionCount,
                EoptionUnitPrice = eOptionUnitPrice.Split(",").Select(decimal.Parse).ToList(),
                EoptionAmount = eOptionAmount.Split(",").Select(decimal.Parse).ToList(),
                EoptionUnits = eOptionUnits.Split(",").Select(decimal.Parse).ToList(),
                EoptionCurrentInterestRate = eOptionCurrentInterestRate.Split(",").Select(decimal.Parse).ToList(),
                EoptionName = eOptionName.Split(',').ToList(),
                EoptionProductGroup = eOptionProductGroup.Split(",").ToList(),
                EassetValue = eAssetValue.Split(",").Select(decimal.Parse).ToList(),
                EassetPercentage = eAssetPercentage.Split(",").Select(decimal.Parse).ToList(),
                EoptionAssetEffectiveDate = eOptionAssetEffectiveDate.Split(",").ToList(),
                EoptionPercentage = eOptionPercentage.Split(",").Select(decimal.Parse).ToList()
            };
            
            //Calling product type
            _callInvestmentsMock[productType](testData);

            // Act
            var response = await CreateRequestBuilder($"/api/accounts/{accountNumber}?customerNumber=12345").GetAsync();

            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            account = JsonConvert.DeserializeObject<AccountDto>(jsonResponse);

            //Test Validation
            _investmentsValidation[productType](expectedTestData);
        }

        [Theory]
        [InlineData(SuperFund)]
        [InlineData(PensionFund)]
        [InlineData(UnitTrust)]
        public async Task ShouldHandleNoInvestmentsProperly(string productType)
        {
            var accountNumber = MyFixture.Create<int>();
            //Calling product type
            _callNoInvestmentsMock[productType](accountNumber, productType);

            // Act
            var response = await CreateRequestBuilder($"/api/accounts/{accountNumber}?customerNumber=12345").GetAsync();

            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            account = JsonConvert.DeserializeObject<AccountDto>(jsonResponse);

            account.InvestmentOptions.Should().BeNullOrEmpty();
            account.InvestmentAssetAllocations.Count().Should().Be(AssetClasses.Count);
        }
    }

}
