﻿namespace Wealth.Api.Account.Domain.PensionPayment
{
    public class PensionPaymentDetail
    {
        public PensionPaymentDetail(int pensionPaymentOptionId, string pensionPaymentOptionName, decimal pensionPaymentPercentage, decimal pensionPaymentSequence)
        {
            PensionPaymentOptionId = pensionPaymentOptionId;
            PensionPaymentOptionName = pensionPaymentOptionName;
            PensionPaymentPercentage = pensionPaymentPercentage;
            PensionPaymentSequence = pensionPaymentSequence;
        }

        public int PensionPaymentOptionId { get; }

        public string PensionPaymentOptionName { get; }

        public decimal PensionPaymentPercentage { get; }

        public decimal PensionPaymentSequence { get; }

    }
}