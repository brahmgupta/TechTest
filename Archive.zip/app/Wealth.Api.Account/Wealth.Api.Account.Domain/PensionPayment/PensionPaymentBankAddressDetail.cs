﻿namespace Wealth.Api.Account.Domain.PensionPayment
{
    public class PensionPaymentBankAddressDetail
    {
        public PensionPaymentBankAddressDetail(string pensionPaymentBankAddress)
        {
            PensionPaymentBankAddress = pensionPaymentBankAddress;
        }

        public string PensionPaymentBankAddress { get; }

    }
}
