﻿using System;

namespace Wealth.Api.Account.Domain.PensionPayment
{
    public class PensionScheduleDetail
    {
        public PensionScheduleDetail(DateTime? pensionScheduleDate, decimal pensionScheduleGrossAmount, decimal pensionScheduleTaxFree, decimal pensionScheduleDedudctible,
            decimal pensionScheduleTaxOffset, decimal pensionSchedulePayeeTax, decimal pensionScheduleNetPayment, decimal pensionScheduleNetTax)
        {
            PensionScheduleDate = pensionScheduleDate;
            PensionScheduleGrossAmount = pensionScheduleGrossAmount;
            PensionScheduleTaxFree = pensionScheduleTaxFree;
            PensionScheduleDedudctible = pensionScheduleDedudctible;
            PensionScheduleTaxOffset = pensionScheduleTaxOffset;
            PensionSchedulePayeeTax = pensionSchedulePayeeTax;
            PensionScheduleNetPayment = pensionScheduleNetPayment;
            PensionScheduleNetTax = pensionScheduleNetTax;
        }

        public DateTime? PensionScheduleDate { get; }

        public decimal PensionScheduleGrossAmount { get; }

        public decimal PensionScheduleTaxFree { get; }

        public decimal PensionScheduleDedudctible { get; }

        public decimal PensionScheduleTaxOffset { get; }

        public decimal PensionSchedulePayeeTax { get; }

        public decimal PensionScheduleNetPayment { get; }

        public decimal PensionScheduleNetTax { get; }

    }
}
