﻿using System;
using System.Collections.Generic;
using Wealth.Api.Account.Domain.SeedWork;

namespace Wealth.Api.Account.Domain.PensionPayment
{
    public class PensionPaymentUpdate : Entity<string>
    {
        public PensionPaymentUpdate(DateTime? executionDate, DateTime? executionTime, DateTime? nextPaymentDate, decimal nextPaymentAmount, decimal grossAnnualAmount, 
        string annualPaymentFinancialYear, decimal paymentRequired, decimal remainingPayment, decimal nextFinancialYearGrossAmount, decimal grossPerPaymentAmount, 
        string paymentFrequency, string increasedByCPI, decimal cpiRate, int pensionScheduleCount, IEnumerable<PensionScheduleDetail> pensionScheduleDetails, 
        string bankName, IEnumerable<PensionPaymentBankAddressDetail> bankAddressDetails, IEnumerable<string> messages, IEnumerable<string> messageTypes)
        {
            ExecutionDate = executionDate;
            ExecutionTime = executionTime;
            NextPaymentDate = nextPaymentDate;
            NextPaymentAmount = nextPaymentAmount;
            GrossAnnualAmount = grossAnnualAmount;
            AnnualPaymentFinancialYear = annualPaymentFinancialYear;
            PaymentRequired = paymentRequired;
            RemainingPayment = remainingPayment;
            NextFinancialYearGrossAmount = nextFinancialYearGrossAmount;
            GrossPerPaymentAmount = grossPerPaymentAmount;
            PaymentFrequency = paymentFrequency;
            IncreasedByCPI = increasedByCPI;
            CPIRate = cpiRate;
            PensionScheduleCount = pensionScheduleCount;
            PensionScheduleDetails = pensionScheduleDetails;
            BankName = bankName;
            BankAddressDetails = bankAddressDetails;
            Messages = messages;
            MessageTypes = messageTypes;
        }

        public DateTime? ExecutionDate { get; }
        public DateTime? ExecutionTime { get; }
        public DateTime? NextPaymentDate { get; }
        public decimal NextPaymentAmount { get; }
        public decimal GrossAnnualAmount { get; }
        public string AnnualPaymentFinancialYear { get; }
        public decimal PaymentRequired { get; }
        public decimal RemainingPayment { get; }
        public decimal NextFinancialYearGrossAmount { get; }
        public decimal GrossPerPaymentAmount { get; }
        public string PaymentFrequency { get; }
        public string IncreasedByCPI { get; }
        public decimal CPIRate { get; }
        public int PensionScheduleCount { get; }
        public IEnumerable<PensionScheduleDetail> PensionScheduleDetails { get; }
        public string BankName { get; }
        public IEnumerable<PensionPaymentBankAddressDetail> BankAddressDetails { get; }
        public IEnumerable<string> Messages { get; }
        public IEnumerable<string> MessageTypes { get; }
        public bool HasError { get; }
    }
}