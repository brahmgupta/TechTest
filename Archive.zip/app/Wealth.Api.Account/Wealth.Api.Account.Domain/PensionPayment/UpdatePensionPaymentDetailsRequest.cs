﻿using System;
using System.Collections.Generic;
using Wealth.Api.Account.Domain.AccountAggregate;

namespace Wealth.Api.Account.Domain.PensionPayment
{
    public class UpdatePensionPaymentDetailsRequest : RequestContext
    {
        public string AccountNumber { get; set; }

        public string ConfirmId { get; set; }

        public string TransactionId { get; set; }

        public string ProcessMode { get; set; }

        public string AnnualPensionRequested { get; set; }

        public decimal GrossPerPaymentAmount { get; set; }

        public string IncreasedByCpi { get; set; }

        public decimal CpiRate { get; set; }

        public string PaymentFrequency { get; set; }

        public DateTime NextPaymentDate { get; set; }

        public string ProRata { get; set; }

        public string IncomeVariationType { get; set; }

        public decimal IncomeVariationPercent { get; set; }

        public decimal GrossSpecifiedAnnualAmount { get; set; }

        public string BankBsbNumber { get; set; }

        public string BankAccountNumber { get; set; }

        public string BankAccountName { get; set; }

        public IEnumerable<PensionPaymentDetail> PensionPaymentDetails { get; set; }

        public string PrinterId { get; set; }

        public string ManagedAccountPensionDrawdownAutoAlign { get; set; }
    }
}
