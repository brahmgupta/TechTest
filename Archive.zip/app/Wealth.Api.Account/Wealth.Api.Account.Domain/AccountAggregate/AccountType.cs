﻿namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public enum AccountType
    {
        Annuity,
        Cash,
        Pension,
        Superannuation,
        UnitTrust,
        Other
    }
}
