﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using FluentResults;

namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public interface IAccountRepository
    {
        Task<Result<IEnumerable<AccountDetails>>> GetAccounts(GetAccountsRequest request, CancellationToken cancellationToken = default(CancellationToken));
        Task<Result<AccountDetails>> GetAccount(GetAccountRequest request, CancellationToken cancellationToken = default(CancellationToken));
        Task<Result<AccountTransactions>> GetTransactions(GetTransactionsRequest request, CancellationToken cancellationToken = default(CancellationToken));
        Task<Result<string>> UpdateInsurance(UpdateInsuranceRequest updateInsuranceRequest, CancellationToken cancellationToken);
    }
}
