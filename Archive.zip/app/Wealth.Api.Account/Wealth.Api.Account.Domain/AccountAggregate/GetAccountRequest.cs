﻿namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class GetAccountRequest : RequestContext
    {
        public string AccountNumber { get; set; }
    }
}
