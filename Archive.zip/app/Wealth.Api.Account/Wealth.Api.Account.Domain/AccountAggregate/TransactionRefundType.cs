﻿
namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public enum TransactionRefundType
    {
        Redemption,
        Application,
        Others
    }
}
