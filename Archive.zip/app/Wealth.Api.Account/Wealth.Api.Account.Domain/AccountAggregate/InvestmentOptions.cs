﻿using System.Collections.Generic;
using Wealth.Api.Account.Domain.SeedWork;

namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class InvestmentOptions : DomainCollection<InvestmentOption>
    {
        public InvestmentOptions()
        {
        }

        public InvestmentOptions(IEnumerable<InvestmentOption> investmentOptions) : base(investmentOptions)
        {
        }

        internal override bool SetItem(InvestmentOption investmentOption)
        {
            if (investmentOption == null)
            {
                return false;
            }

            Items.AddOrReplace(item => item.Equals(investmentOption), investmentOption);

            return true;
        }
    }
}
