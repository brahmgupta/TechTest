using System;
using System.Collections.Generic;
using System.Linq;
using Wealth.Api.Account.Domain.SeedWork;

namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class AccountDetails : Entity<string>, IAggregateRoot
    {
        public AccountDetails(string accountNumber, AccountType accountType, string productName, string productCode,
            decimal accountBalance, DateTime? effectiveDate, AccountStatus status, string productAbbreviation,
            DateTime? nextPaymentDate, decimal nextPaymentAmount, string accountDesignation, string ownerName,
            AccessMode accessMode = AccessMode.None)
        {
            Id = accountNumber;
            AccountType = accountType;
            ProductName = productName;
            ProductCode = productCode;
            AccountBalance = accountBalance;
            EffectiveDate = effectiveDate;
            Status = status;
            Transactions = new Transactions(Enumerable.Empty<Transaction>());
            Beneficiaries = new Beneficiaries(Enumerable.Empty<Beneficiary>());
            InvestmentOptions = new InvestmentOptions(Enumerable.Empty<InvestmentOption>());
            ProductAbbreviation = productAbbreviation;
            NextPaymentDate = nextPaymentDate;
            NextPaymentAmount = nextPaymentAmount;
            AccountDesignation = accountDesignation;
            OwnerName = ownerName;
            AccessMode = accessMode;
        }

        public void SetBeneficiaries(IEnumerable<Beneficiary> beneficiaries)
        {
            Beneficiaries = new Beneficiaries(beneficiaries);
        }

        public void SetInvestmentOptions(IEnumerable<InvestmentOption> investmentOptions)
        {
            InvestmentOptions = new InvestmentOptions(investmentOptions);
        }

        public void SetInvestmentAssetAllocations(IEnumerable<InvestmentAssetAllocation> investmentAssetAllocations)
        {
            InvestmentAssetAllocations = new InvestmentAssetAllocations(investmentAssetAllocations);
        }

        public void SetTransactions(IEnumerable<Transaction> transactions)
        {
            Transactions = new Transactions(transactions);
        }

        public bool UpdateInsurance(Insurance insurance)
        {
            if (Insurance == null || Insurance.Equals(insurance))
            {
                return false;
            }

            insurance.IsInsuranceElectionModified =
                !Insurance.InsuranceElectionDate.HasValue && insurance.InsuranceElectionDate.HasValue;

            insurance.IsSmokerStatusModified = Insurance.IsSmoker != insurance.IsSmoker;

            Insurance = insurance;
            OnModified();
            return true;
        }

        public void SetInsurance(Insurance insurance)
        {
            Insurance = insurance;
        }

        public void SetDealerType(DealerType dealerType)
        {
            DealerType = dealerType;
        }

        public void SetOpenAccountsCount(int openAccountsCount)
        {
            OpenAccountsCount = openAccountsCount;
        }

        public void SetEmployerName(string employerName)
        {
            EmployerName = employerName;
        }

        public void SetPlanName(string planName)
        {
            PlanName = planName;
        }

        public void SetCategoryName(string categoryName)
        {
            CategoryName = categoryName;
        }

        public int OpenAccountsCount { get; private set; }

        public string AccountNumber => Id;

        public string ProductName { get; }

        public AccountType AccountType { get; }

        public string ProductCode { get; }

        public decimal AccountBalance { get; }

        public DateTime? EffectiveDate { get; }

        public Beneficiaries Beneficiaries { get; private set; }

        public InvestmentOptions InvestmentOptions { get; private set; }

        public InvestmentAssetAllocations InvestmentAssetAllocations { get; private set; }

        public Transactions Transactions { get; private set; }

        public Insurance Insurance { get; private set; }

        public DealerType DealerType { get; private set; }

        public AccountStatus Status { get; }

        public string ProductAbbreviation { get; }

        public DateTime? NextPaymentDate { get; }

        public decimal NextPaymentAmount { get; }

        public string AccountDesignation { get; }

        public string OwnerName { get; }

        public string EmployerName { get; private set; }

        public string PlanName { get; private set; }

        public string CategoryName { get; private set; }

        public AccessMode AccessMode { get; }
    }
}
