﻿namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public enum TransactionStatus
    {
        Pending,
        Unfunded,
        Completed
    }
}
