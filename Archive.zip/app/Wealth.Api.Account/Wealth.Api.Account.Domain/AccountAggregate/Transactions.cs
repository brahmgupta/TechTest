﻿using System.Collections.Generic;
using Wealth.Api.Account.Domain.SeedWork;

namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class Transactions : DomainCollection<Transaction>
    {
        public Transactions()
        {
        }

        public Transactions(IEnumerable<Transaction> transactions) : base(transactions)
        {
        }

        internal override bool SetItem(Transaction transaction)
        {
            if (transaction == null)
            {
                return false;
            }

            Items.AddOrReplace(item => item.Equals(transaction), transaction);

            return true;
        }
    }
}
