﻿using System;
using System.Collections.Generic;
using Wealth.Api.Account.Domain.SeedWork;

namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class InvestmentOption : ValueObject
    {
        public InvestmentOption(
            string name,
            string productGroup,
            decimal units,
            decimal unitPrice,
            decimal amount,
            decimal percentage,
            DateTime? assetAllocationEffectiveDate,
            string assetType = "",
            decimal currentInterestRate = 0)
        {
            Name = name;
            Units = units;
            UnitPrice = unitPrice;
            Amount = amount;
            Percentage = percentage;
            AssetAllocationEffectiveDate = assetAllocationEffectiveDate;
            AssetType = assetType;
            CurrentInterestRate = currentInterestRate;
            ProductGroup = productGroup;
        }

        public string Name { get; }

        public decimal Units { get; }

        public decimal UnitPrice { get; }

        public decimal Amount { get; }

        public string AssetType { get; }

        public decimal CurrentInterestRate { get; }

        public string ProductGroup { get; }

        public decimal Percentage { get; }

        public DateTime? AssetAllocationEffectiveDate { get; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return Name;
            yield return Units;
            yield return UnitPrice;
            yield return Amount;
            yield return AssetType;
            yield return CurrentInterestRate;
            yield return ProductGroup;
            yield return Percentage;
            yield return AssetAllocationEffectiveDate;
        }
    }
}
