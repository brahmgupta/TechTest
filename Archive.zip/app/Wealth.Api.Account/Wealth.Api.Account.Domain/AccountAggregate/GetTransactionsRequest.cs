﻿
namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class GetTransactionsRequest : GetAccountRequest
    {
    }
}
