﻿using System.Collections.Generic;
using Wealth.Api.Account.Domain.SeedWork;

namespace Wealth.Api.Account.Domain.AccountAggregate
{
    public class Beneficiaries : DomainCollection<Beneficiary>
    {
        public Beneficiaries()
        {
        }

        public Beneficiaries(IEnumerable<Beneficiary> beneficiaries) : base(beneficiaries)
        {
        }

        internal override bool SetItem(Beneficiary beneficiary)
        {
            if (beneficiary == null)
            {
                return false;
            }

            Items.AddOrReplace(item => item.Equals(beneficiary), beneficiary);

            return true;
        }
    }
}
