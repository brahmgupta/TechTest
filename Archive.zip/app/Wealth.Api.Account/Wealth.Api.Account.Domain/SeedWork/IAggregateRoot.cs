﻿namespace Wealth.Api.Account.Domain.SeedWork
{
    public interface IAggregateRoot { }
}
