﻿using System;

namespace Wealth.Api.Account.Application.Models
{
    public class PensionScheduleDetail
    {
        public DateTime PensionScheduleDate { get; set; }

        public decimal PensionScheduleGrossAmount { get; set; }

        public decimal PensionScheduleTaxFree { get; set; }

        public decimal PensionScheduleDedudctible { get; set; }

        public decimal PensionScheduleTaxOffset { get; set; }

        public decimal PensionSchedulePayeeTax { get; set; }

        public decimal PensionScheduleNetPayment { get; set; }

        public decimal PensionScheduleNetTax { get; set; }

    }
}
