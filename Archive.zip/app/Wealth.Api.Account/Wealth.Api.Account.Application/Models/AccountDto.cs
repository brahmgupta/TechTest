using System;
using System.Collections.Generic;
using Wealth.Api.Account.Domain.AccountAggregate;

namespace Wealth.Api.Account.Application.Models
{
    public class AccountDto
    {
        public string AccountNumber { get; set; }

        public string AccountType { get; set; }

        public string ProductName { get; set; }

        public string ProductCode { get; set; }

        public decimal AccountBalance { get; set; }

        public DateTime? EffectiveDate { get; set; }

        public IEnumerable<BeneficiaryDto> Beneficiaries { get; set; }

        public IEnumerable<InvestmentOptionDto> InvestmentOptions { get; set; }

        public IEnumerable<InvestmentAssetAllocationDto> InvestmentAssetAllocations { get; set; }

        public IEnumerable<TransactionDto> Transactions { get; set; }

        public InsuranceDto Insurance { get; set; }

        public string Status { get; set; }

        public string ProductAbbreviation { get; set; }

        public DateTime? NextPaymentDate { get; set; }

        public decimal NextPaymentAmount { get; set; }

        public string AccountDesignation { get; set; }

        public string OwnerName { get; set; }

        public string DealerType { get; set; }

        public string EmployerName { get; set; }

        public string PlanName { get; set; }

        public string CategoryName { get; set; }

        public int OpenAccountsCount { get; set; }

        public AccessMode AccessMode { get; set; }
    }
}
