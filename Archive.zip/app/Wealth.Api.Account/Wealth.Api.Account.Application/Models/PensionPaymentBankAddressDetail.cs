﻿namespace Wealth.Api.Account.Application.Models
{
    public class PensionPaymentBankAddressDetail
    {
        public string PensionPaymentBankAddress { get; set; }
    }
}
