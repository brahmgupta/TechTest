﻿using System.Collections.Generic;

namespace Wealth.Api.Account.Application.Models
{
    public class AccountTransactionsDto
    {
        public string AccountNumber { get; set; }

        public string AccountType { get; set; }

        public bool TransactionLimitReached { get; set; }

        public IEnumerable<TransactionDto> Transactions { get; set; }
    }
}
