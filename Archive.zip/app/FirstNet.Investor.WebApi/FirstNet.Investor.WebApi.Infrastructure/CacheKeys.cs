﻿namespace FirstNet.Investor.WebApi.Infrastructure
{
    public static class CacheKeys
    {
        public static string Countries = "_Countries";
        public static string AccountMenuConfig = "_AccountMenuConfig";
        public static string Contents = "_Contents";
    }
}