﻿using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FirstNet.Investor.WebApi.Infrastructure
{
    public class File
    {
        public static async Task<string> ReadTextAsync(string filePath, CancellationToken cancellationToken = default(CancellationToken))
        {
            using (var sourceStream = new FileStream(filePath,
                FileMode.Open, FileAccess.Read, FileShare.Read,
                bufferSize: 4096, useAsync: true))
            {
                var sb = new StringBuilder();

                var buffer = new byte[0x1000];
                int numRead;
                while ((numRead = await sourceStream.ReadAsync(buffer, 0, buffer.Length, cancellationToken)) != 0)
                {
                    var text = Encoding.UTF8.GetString(buffer, 0, numRead);
                    sb.Append(text);
                }

                return sb.ToString();
            }
        }
    }
}
