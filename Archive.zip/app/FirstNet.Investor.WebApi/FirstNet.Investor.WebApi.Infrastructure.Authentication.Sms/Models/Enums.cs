﻿namespace FirstNet.Investor.WebApi.Infrastructure.Authentication.Sms.Models
{
    public enum CallerUserTypesEnum
    {
        BankUser,// for CommSee
        BatchUser,//for Batch process
        ExternalUser//for Online Channels
    }

    public enum IdentityUserTypesEnum
    {
        LoginId,
        CaasId,
        FoId,
        Email
    }

    public enum SmsAuthenticationCodeServiceHeadersEnum
    {
        BranchCode,
        SectionNumber,
        // ReSharper disable once InconsistentNaming
        IPAddress,
        TraceId,
        ChannelId,
        RequestingApplication,
        CallerUserId,
        CallerUserType,
        IdentityUserType,
        // ReSharper disable once InconsistentNaming
        CBA_SecApi_Token,
        // ReSharper disable once InconsistentNaming
        CBA_SecApi_Referer,
        Authorization,
        // ReSharper disable once InconsistentNaming
        Channel_Authorization,
        // ReSharper disable once InconsistentNaming
        CBA_Api_Key
    }
}