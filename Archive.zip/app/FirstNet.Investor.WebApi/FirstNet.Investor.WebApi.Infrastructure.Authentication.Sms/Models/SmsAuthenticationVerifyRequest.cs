﻿namespace FirstNet.Investor.WebApi.Infrastructure.Authentication.Sms.Models
{
    public class SmsAuthenticationVerifyRequest
    {
        public string MobileNumber { get; set; }
        public string Challenge { get; set; }
        public string Context { get; set; }
    }
}
