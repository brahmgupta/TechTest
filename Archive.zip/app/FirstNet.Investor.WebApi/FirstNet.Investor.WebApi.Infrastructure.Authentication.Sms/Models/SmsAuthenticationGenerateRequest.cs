﻿namespace FirstNet.Investor.WebApi.Infrastructure.Authentication.Sms.Models
{
    public class SmsAuthenticationGenerateRequest
    {
        public string MobileNumber { get; set; }
        public string Message { get; set; }
        public string Context { get; set; }
        public string SenderLabel { get; set; }
    }
}
