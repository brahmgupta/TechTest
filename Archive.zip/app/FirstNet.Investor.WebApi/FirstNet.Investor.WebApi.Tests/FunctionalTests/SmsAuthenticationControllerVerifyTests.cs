﻿using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AutoFixture;
using FirstNet.Investor.WebApi.Application.SmsAuthentication.Models;
using FirstNet.Investor.WebApi.Domain.Customers;
using FirstNet.Investor.WebApi.Domain.TwoFactorAuthentication;
using FirstNet.Investor.WebApi.Infrastructure.Services.Customer;
using FirstNet.Investor.WebApi.Infrastructure.Services.SmsAuthentication;
using FirstNet.Investor.WebApi.Tests.Helpers;
using FluentAssertions;
using Newtonsoft.Json;
using RichardSzalay.MockHttp;
using Wealth.Toolkit.HttpService.HttpService;
using Wealth.Toolkit.Response.Models;
using Xunit;
using Constants = FirstNet.Investor.WebApi.Host.Constants;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public partial class SmsAuthenticationControllerTests
    {
        private const string VERIFY_URL = "api/SmsAuthentication/verify";

        [Fact]
        private async void VerifySms_ShouldReturnErrorWhenNotRegistered()
        {
            var mockMobileNumber = "";
            // Status
            var statusResponse = new SmsStatusResponse
            {
                IsRegistered = false,
                Mobile = _fixture.Create<string>()
            };
            var statusJson = JsonConvert.SerializeObject(statusResponse);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(statusJson));

            // Customer
            var customerResponse = _fixture.Create<Customer>();
            customerResponse.ContactDetails.Mobile = mockMobileNumber;

            MockHttp
                .When(HttpMethod.Get, CustomerApi.CreateGetCustomerUri(_customerServiceBaseUrl, "13579", "001"))
                .Respond(HttpStatusCode.OK, new StringContent(JsonConvert.SerializeObject(customerResponse)));

            // Verify
            var verifyResponse = _fixture.Create<SmsVerifyResponse>();
            var verifyJson = JsonConvert.SerializeObject(verifyResponse);
            MockHttp
                .When(HttpMethod.Post, SmsAuthenticationApi.CreateVerifySmsUri(_baseUrl))
                .Respond(HttpStatusCode.BadRequest, new StringContent(verifyJson));

            var smsAuthentication = new SmsAuthentication { Code = "1234" };

            var response = await CreateRequest(VERIFY_URL)
                .AddHeader(Constants.Headers.FirstNetCodePurposeHeader, "update")
                .And(r => r.Content = JsonFormatter.CreateStringContent(smsAuthentication))
                .PostAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsStatusViewModel>(response, false);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.NotRegistered.Should().BeTrue();
            responseBody.Status.Should().Be(Application.TwoFactorAuthentication.Models.Constants.SmsAuthenticationCodes.NotRegistered);
        }

        [Fact]
        private async void VerifySms_ShouldReturnErrorWhenLocked()
        {
            // Status
            var statusResponse = new SmsStatusResponse
            {
                IsRegistered = true,
                IsLocked = true,
                Mobile = _fixture.Create<string>()
            };
            var statusJson = JsonConvert.SerializeObject(statusResponse);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(statusJson));

            // Verify
            var verifyResponse = _fixture.Create<SmsVerifyResponse>();
            var verifyJson = JsonConvert.SerializeObject(verifyResponse);
            MockHttp
                .When(HttpMethod.Post, SmsAuthenticationApi.CreateVerifySmsUri(_baseUrl))
                .Respond(HttpStatusCode.BadRequest, new StringContent(verifyJson));

            var smsAuthentication = new SmsAuthentication { Code = "1234" };

            var response = await CreateRequest(VERIFY_URL)
                .AddHeader(Constants.Headers.FirstNetCodePurposeHeader, "update")
                .And(r => r.Content = JsonFormatter.CreateStringContent(smsAuthentication))
                .PostAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsStatusViewModel>(response, false);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.Locked.Should().BeTrue();
            responseBody.Status.Should().Be(Application.TwoFactorAuthentication.Models.Constants.SmsAuthenticationCodes.Locked);
        }

        [Fact]
        private async void VerifySms_ShouldReturnErrorWhenErrorMessage()
        {
            // Status
            var statusResponse = new SmsStatusResponse
            {
                IsRegistered = true,
                IsLocked = false,
                Message = _fixture.Create<string>(),
                Mobile = _fixture.Create<string>()
            };
            var statusJson = JsonConvert.SerializeObject(statusResponse);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(statusJson));

            // Verify
            var verifyResponse = new SmsVerifyResponse
            {
                Message = _fixture.Create<string>()
            };
            var verifyJson = JsonConvert.SerializeObject(verifyResponse);
            MockHttp
                .When(HttpMethod.Post, SmsAuthenticationApi.CreateVerifySmsUri(_baseUrl))
                .Respond(HttpStatusCode.BadRequest, new StringContent(verifyJson));

            var smsAuthentication = new SmsAuthentication { Code = "1234" };

            var response = await CreateRequest(VERIFY_URL)
                .AddHeader(Constants.Headers.FirstNetCodePurposeHeader, "update")
                .And(r => r.Content = JsonFormatter.CreateStringContent(smsAuthentication))
                .PostAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsVerifyViewModel>(response, false);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.Message.Should().Be(statusResponse.Message);
            responseBody.Status.Should().Be(Application.TwoFactorAuthentication.Models.Constants.SmsAuthenticationCodes.Error);
        }

        [Fact]
        private async void VerifySms_ShouldReturnErrorWhenCantGetSmsStatus()
        {
            // Status
            var statusResponse = new SmsStatusResponse
            {
                IsRegistered = true,
                Mobile = _fixture.Create<string>()
            };
            var statusJson = JsonConvert.SerializeObject(statusResponse);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.BadRequest, new StringContent(statusJson));

            // Verify
            var verifyResponse = _fixture.Create<SmsVerifyResponse>();
            var verifyJson = JsonConvert.SerializeObject(verifyResponse);
            MockHttp
                .When(HttpMethod.Post, SmsAuthenticationApi.CreateVerifySmsUri(_baseUrl))
                .Respond(HttpStatusCode.BadRequest, new StringContent(verifyJson));

            var smsAuthentication = new SmsAuthentication {  Code = "1234" };

            var response = await CreateRequest(VERIFY_URL)
                .AddHeader(Constants.Headers.FirstNetCodePurposeHeader, "update")
                .And(r => r.Content = JsonFormatter.CreateStringContent(smsAuthentication))
                .PostAsync();
            var responseBody = await HttpHelper.HandleResponse<Error>(response, false);

            response.StatusCode.Should().Be(HttpStatusCode.InternalServerError);
            responseBody.Code.Should().Be(Common.Constants.ErrorCodes.TwoFactorAuthenticationApiError);
        }

        [Fact]
        private async void VerifySms_ShouldReturnSuccess()
        {
            // Status
            var statusResponse = new SmsStatusResponse
            {
                IsRegistered = true,
                Mobile = _fixture.Create<string>()
            };
            var statusJson = JsonConvert.SerializeObject(statusResponse);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(statusJson));

            // Verify
            var verifyResponse = new SmsVerifyResponse
            {
                AuthenticationResult = _fixture.Create<string>()
            };
            var verifyJson = JsonConvert.SerializeObject(verifyResponse);
            MockHttp
                .When(HttpMethod.Post, SmsAuthenticationApi.CreateVerifySmsUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(verifyJson));

            var smsAuthentication = new SmsAuthentication { Code = "1234" };

            var response = await CreateRequest(VERIFY_URL)
                .AddHeader(Constants.Headers.FirstNetCodePurposeHeader, "update")
                .And(r => r.Content = JsonFormatter.CreateStringContent(smsAuthentication))
                .PostAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsVerifyViewModel>(response);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.Success.Should().BeTrue();
            responseBody.Status.Should().Be(Application.TwoFactorAuthentication.Models.Constants.SmsAuthenticationCodes.Verified);
        }

        [Fact]
        public async void VerifySms_ShouldReturnForbiddenWhenIsEmulation()
        {
            var smsAuthentication = new SmsAuthentication { Code = "1234" };

            var response = await CreateRequest(VERIFY_URL, StaffClaims)
                .AddHeader(Constants.Headers.FirstNetCodePurposeHeader, "update")
                .And(r => r.Content = JsonFormatter.CreateStringContent(smsAuthentication))
                .PostAsync();

            response.StatusCode.Should().Be(HttpStatusCode.Forbidden);
        }

        [Fact]
        public async Task VerifySms_ShouldReturnForbiddenWhenAntiForgeryMissing()
        {
            var response = await CreateRequest(VERIFY_URL, withAntiForgeryHeader: false).GetAsync();

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }
    }
}
