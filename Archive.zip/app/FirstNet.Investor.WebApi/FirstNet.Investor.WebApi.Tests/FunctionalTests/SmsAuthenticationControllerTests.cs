﻿using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AutoFixture;
using FirstNet.Investor.WebApi.Application.SmsAuthentication.Models;
using FirstNet.Investor.WebApi.Domain.Customers;
using FirstNet.Investor.WebApi.Domain.TwoFactorAuthentication;
using FirstNet.Investor.WebApi.Infrastructure.Services.Customer;
using FirstNet.Investor.WebApi.Infrastructure.Services.SmsAuthentication;
using FluentAssertions;
using Newtonsoft.Json;
using RichardSzalay.MockHttp;
using Wealth.Toolkit.HttpService.HttpService;
using Wealth.Toolkit.Response.Models;
using Xunit;
using Constants = FirstNet.Investor.WebApi.Host.Constants;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public partial class SmsAuthenticationControllerTests
    {
        private const string GENERATE_URL = "api/SmsAuthentication/generate";

        [Fact]
        private async void GenerateSms_ShouldReturnNotRegistered()
        {
            var mockMobileNumber = "";

            // Status
            var statusResponse = new SmsStatusResponse
            {
                IsRegistered = false,
                Mobile = _fixture.Create<string>()
            };
            var statusJson = JsonConvert.SerializeObject(statusResponse);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(statusJson));

            // Customer
            var customerResponse = _fixture.Create<Customer>();
            customerResponse.ContactDetails.Mobile = mockMobileNumber;

            MockHttp
                .When(HttpMethod.Get, CustomerApi.CreateGetCustomerUri(_customerServiceBaseUrl, "13579", "001"))
                .Respond(HttpStatusCode.OK, new StringContent(JsonConvert.SerializeObject(customerResponse)));

            // Generate
            var generateResponse = new SmsGenerateResponse
            {
                Status = false
            };
            var generateJson = JsonConvert.SerializeObject(generateResponse);
            MockHttp
                .When(HttpMethod.Post, SmsAuthenticationApi.CreateGenerateSmsUri(_baseUrl))
                .Respond(HttpStatusCode.BadRequest, new StringContent(generateJson));

            var response = await CreateRequest(GENERATE_URL)
                .AddHeader(Constants.Headers.FirstNetCodePurposeHeader, "update")
                .PostAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsGenerateViewModel>(response, false);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.NotRegistered.Should().BeTrue();
        }

        [Fact]
        private async void GenerateSms_ShouldReturnErrorWhenLocked()
        {
            // Status
            var statusResponse = new SmsStatusResponse
            {
                IsRegistered = true,
                IsLocked = true,
                Mobile = _fixture.Create<string>()
            };
            var statusJson = JsonConvert.SerializeObject(statusResponse);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(statusJson));

            // Generate
            var generateResponse = new SmsGenerateResponse
            {
                Status = false
            };
            var generateJson = JsonConvert.SerializeObject(generateResponse);
            MockHttp
                .When(HttpMethod.Post, SmsAuthenticationApi.CreateGenerateSmsUri(_baseUrl))
                .Respond(HttpStatusCode.BadRequest, new StringContent(generateJson));

            var response = await CreateRequest(GENERATE_URL)
                .AddHeader(Constants.Headers.FirstNetCodePurposeHeader, "update")
                .PostAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsGenerateViewModel>(response, false);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.Locked.Should().BeTrue();
        }

        [Fact]
        private async void GenerateSms_ShouldReturnErrorWhenErrorMessage()
        {
            // Status
            var statusResponse = new SmsStatusResponse
            {
                IsRegistered = true,
                IsLocked = false,
                Message = _fixture.Create<string>(),
                Mobile = _fixture.Create<string>()
            };
            var statusJson = JsonConvert.SerializeObject(statusResponse);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(statusJson));

            // Generate
            var generateResponse = new SmsGenerateResponse
            {
                Status = false
            };
            var generateJson = JsonConvert.SerializeObject(generateResponse);
            MockHttp
                .When(HttpMethod.Post, SmsAuthenticationApi.CreateGenerateSmsUri(_baseUrl))
                .Respond(HttpStatusCode.BadRequest, new StringContent(generateJson));

            var response = await CreateRequest(GENERATE_URL)
                .AddHeader(Constants.Headers.FirstNetCodePurposeHeader, "update")
                .PostAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsGenerateViewModel>(response, false);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.Message.Should().Be(statusResponse.Message);
        }

        [Fact]
        private async void GenerateSms_ShouldReturnErrorWhenCantGetSmsStatus()
        {
            // Status
            var statusResponse = new Error("error", "some error");

            var statusJson = JsonConvert.SerializeObject(statusResponse);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.BadRequest, new StringContent(statusJson));

            // Generate
            var generateResponse = new SmsGenerateResponse
            {
                Status = false
            };
            var generateJson = JsonConvert.SerializeObject(generateResponse);
            MockHttp
                .When(HttpMethod.Post, SmsAuthenticationApi.CreateGenerateSmsUri(_baseUrl))
                .Respond(HttpStatusCode.BadRequest, new StringContent(generateJson));

            var response = await CreateRequest(GENERATE_URL)
                .AddHeader(Constants.Headers.FirstNetCodePurposeHeader, "update")
                .PostAsync();
            var responseBody = await HttpHelper.HandleResponse<Error>(response, false);

            response.StatusCode.Should().Be(HttpStatusCode.InternalServerError);
            responseBody.Code.Should()
                .Be(Common.Constants.ErrorCodes.TwoFactorAuthenticationApiError);
        }

        [Theory]
        [InlineData(null)]
        [InlineData("12345678")]
        private async void GenerateSms_ShouldReturnSuccess(string challenge)
        {
            // Status
            var statusResponse = new SmsStatusResponse
            {
                IsRegistered = true,
                Mobile = _fixture.Create<string>()
            };
            var statusJson = JsonConvert.SerializeObject(statusResponse);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(statusJson));

            // Generate
            var generateResponse = new SmsGenerateResponse
            {
                Status = true,
                Challenge = challenge,
            };
            var generateJson = JsonConvert.SerializeObject(generateResponse);
            MockHttp
                .When(HttpMethod.Post, SmsAuthenticationApi.CreateGenerateSmsUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(generateJson));

            var response = await CreateRequest(GENERATE_URL)
                .AddHeader(Constants.Headers.FirstNetCodePurposeHeader, "update")
                .PostAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsGenerateViewModel>(response);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.Status.Should().Be(Application.TwoFactorAuthentication.Models.Constants.SmsAuthenticationCodes.Generated);
        }

        [Fact]
        public async void GenerateSms_ShouldReturnForbiddenWhenIsEmulation()
        {
            var response = await CreateRequest(GENERATE_URL, StaffClaims)
                .AddHeader(Constants.Headers.FirstNetCodePurposeHeader, "update")
                .PostAsync();

            response.StatusCode.Should().Be(HttpStatusCode.Forbidden);
        }

        [Fact]
        public async Task GenerateSms_ShouldReturnForbiddenWhenAntiForgeryMissing()
        {
            var response = await CreateRequest(GENERATE_URL, withAntiForgeryHeader: false).GetAsync();

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }
    }
}