﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using AutoFixture;
using FirstNet.Investor.WebApi.Application.Accounts.Models;
using FirstNet.Investor.WebApi.Domain.Accounts;
using FirstNet.Investor.WebApi.Infrastructure.Services.Accounts;
using FirstNet.Investor.WebApi.Tests.FunctionalTests.Setup;
using FirstNet.Investor.WebApi.Tests.Helpers;
using FluentAssertions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RichardSzalay.MockHttp;
using Wealth.Toolkit.Test;
using Xunit;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public partial class AccountsControllerTests : BaseTests
    {
        public AccountsControllerTests()
        {
            _fixture = new Fixture();
            _openAccountsCount = _fixture.Create<int>();
        }

        private readonly Fixture _fixture;
        private const string GET_ACCOUNT_URL = "api/accounts";

        private class TestData
        {
            public string AccAccountType { get; set; }
            public List<string> AccBenType { get; set; }
            public List<string> AccBenDescription { get; set; }
            public List<string> AccBenName { get; set; }
            public List<string> AccBenDob { get; set; }
            public List<string> AccBenRelationship { get; set; }
            public List<decimal> AccBenPercentage { get; set; }
        }

        private class ExpectedData
        {
            public string ExpAccountType { get; set; }
            public List<string> ExpBenType { get; set; }
            public List<string> ExpBenDescription { get; set; }
            public List<string> ExpBenName { get; set; }
            public List<string> ExpBenDob { get; set; }
            public List<string> ExpBenRelationship { get; set; }
            public List<string> ExpBenPercentage { get; set; }
            public string ExpBenGuideType { get; set; }
        }

        private MockedRequest GetMockHttpForAccountsApi(HttpMethod method, string accountNumber)
        {
            return MockHttp
                .When(method, $"{AppSettings.DownstreamSettings.WealthApiAccountBaseUrl}/api/accounts/{accountNumber}")
                .WithHeaders(AccountsConstants.SessionIdHeaderName, DefaultSessionId)
                .WithHeaders(AccountsConstants.CompanyCodeHeaderName, DefaultCompanyCode)
                .WithQueryString(AccountsConstants.CustomerNumberQueryName, DefaultCustomerNumber);
        }

        private void BuildMockForAccountsApiWithData(TestData data, string accountNumber)
        {
            var enUs = new CultureInfo("en-US");
            Enum.TryParse<AccountType>(data.AccAccountType, out var accountType);

            var beneficiaries = _fixture.Build<Beneficiary>().CreateMany(data.AccBenName.Count).ToList();
            for (var i = 0; i < data.AccBenName.Count; i++)
            {
                beneficiaries[i].Type = NullToString(data.AccBenType[i]);
                beneficiaries[i].Description = NullToString(data.AccBenDescription[i]);
                beneficiaries[i].Name = data.AccBenName[i];
                beneficiaries[i].Relationship = NullToString(data.AccBenRelationship[i]);
                beneficiaries[i].Percentage = data.AccBenPercentage[i];
                if (data.AccBenDob[i] != "0")
                {
                    beneficiaries[i].Dob = DateTime.ParseExact(data.AccBenDob[i], "yyyyMMdd", enUs);
                }
            }

            var account = _fixture.Build<Account>()
                .With(b => b.AccountType, accountType)
                .With(b => b.Beneficiaries, beneficiaries)
                .With(b => b.OpenAccountsCount, _openAccountsCount)
                .Create();
            var json = JsonConvert.SerializeObject(account);
            GetMockHttpForAccountsApi(HttpMethod.Get, accountNumber)
                .Respond(HttpStatusCode.OK, new StringContent(json));
        }

        private void ValidateBeneficiaryDetails(JObject expJson, ExpectedData expData)
        {
            var account = expJson["account"];
            var beneficiary = account["beneficiaries"].ToArray();
            var typeOfBeneficiary = beneficiary.GetType();

            account["accountType"].ToString().Should().Be(expData.ExpAccountType);
            account["beneficiaryGuideType"].ToString().Should().Be(expData.ExpBenGuideType);

            int beneficiariesCount = expData.ExpBenName.Where(x => !string.IsNullOrEmpty(x)).Count();
            account["beneficiaries"].Count().Should().Be(beneficiariesCount);

            if (beneficiariesCount > 0)
            {
                for (var i = 0; i < expData.ExpBenName.Count; i++)
                {
                    if (expData.ExpBenDob[i] == "0")
                    {
                        typeOfBeneficiary.GetProperty("dob").Should().BeNull();
                    }
                    else
                    {
                        account["beneficiaries"][i]["dob"].ToString().Should().Be(expData.ExpBenDob[i]);
                    }

                    account["beneficiaries"][i]["type"].ToString().Should().Be(NullToString(expData.ExpBenType[i]));
                    account["beneficiaries"][i]["description"].ToString().Should()
                        .Be(NullToString(expData.ExpBenDescription[i]));
                    account["beneficiaries"][i]["name"].ToString().Should().Be(expData.ExpBenName[i]);
                    account["beneficiaries"][i]["percentage"].ToString().Should().Be(expData.ExpBenPercentage[i]);
                    account["beneficiaries"][i]["relationship"].ToString().Should()
                        .Be(NullToString(expData.ExpBenRelationship[i]));
                }
            }
        }

        public string NullToString(string value)
        {
            switch (value)
            {
                case "NULL":
                    return "";
                case " ":
                    return "";
                default:
                    return value;
            }
        }

        [Theory]
        [ExcelData("FunctionalTests\\TestData\\Beneficiaries_TestData.xlsx")]
        public async void ShouldEvaluateBeneficiaryDetailsWithTestData(string scNo, string accAccountType, string accBenType,
            string accBenDescription,
            string accBenName, string accBenDob, string accBenRelationship, string accBenPercentage,
            string expAccountType, string expBenType, string expBenDescription, string expBenName,
            string expBenDob, string expBenRelationship, string expBenPercentage, string expBenGuideType)
        {
            var accountNumber = _fixture.Create<int>();
            var testData = new TestData
            {
                AccAccountType = accAccountType,
                AccBenType = accBenType.Split(",").ToList(),
                AccBenDescription = accBenDescription.Split(",").ToList(),
                AccBenName = accBenName.Split(',').ToList(),
                AccBenDob = accBenDob.Split(",").ToList(),
                AccBenRelationship = accBenRelationship.Split(',').ToList(),
                AccBenPercentage = accBenPercentage.Split(",").Select(decimal.Parse).ToList()
            };

            var expectedTestData = new ExpectedData
            {
                ExpAccountType = expAccountType,
                ExpBenType = expBenType.Split(",").ToList(),
                ExpBenDescription = expBenDescription.Split(",").ToList(),
                ExpBenName = expBenName.Split(',').ToList(),
                ExpBenDob = expBenDob.Split(",").ToList(),
                ExpBenRelationship = expBenRelationship.Split(',').ToList(),
                ExpBenPercentage = expBenPercentage.Split(",").ToList(),
                ExpBenGuideType = expBenGuideType
            };

            BuildMockForAccountsApiWithData(testData, accountNumber.ToString());

            var response = await CreateRequest($"{GET_ACCOUNT_URL}/{accountNumber}").GetAsync();
            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var expectedJson = JObject.Parse(jsonResponse);

            ValidateBeneficiaryDetails(expectedJson, expectedTestData);
        }

        [Fact]
        public async void Get_ShouldReturnErrorWhenUnableToGetAccount()
        {
            const string accountNumber = "123456789";
            GetMockHttpForAccountsApi(HttpMethod.Get, accountNumber)
                .Respond(HttpStatusCode.NotFound, new StringContent("test"));

            var response = await CreateRequest($"{GET_ACCOUNT_URL}/{accountNumber}").GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.InternalServerError);
        }

        [Fact]
        public async void Get_ShouldReturnFormattedBeneficiaryWhenAbleToGetAccount()
        {
            const string accountNumber = "123456789";
            var beneficiary = _fixture.Build<Beneficiary>()
                .With(b => b.Dob, new DateTime(2019, 4, 2))
                .With(b => b.Type, "type")
                .With(b => b.Description, "description")
                .With(b => b.Relationship, "child")
                .With(b => b.Name, "john smith")
                .With(b => b.Percentage, 50.515m)
                .Create();
            var account = _fixture.Build<Account>()
                .With(a => a.Beneficiaries, new[] {beneficiary})
                .Create();
            var json = JsonConvert.SerializeObject(account);
            GetMockHttpForAccountsApi(HttpMethod.Get, accountNumber)
                .Respond(HttpStatusCode.OK, new StringContent(json));

            var response = await CreateRequest($"{GET_ACCOUNT_URL}/{accountNumber}").GetAsync();
            var content = await response.Content.ReadAsStringAsync();
            var actual = JObject.Parse(content)["account"]["beneficiaries"][0];
            actual["type"].ToString().Should().Be("type");
            actual["description"].ToString().Should().Be("Description");
            actual["name"].ToString().Should().Be("John Smith");
            actual["dob"].ToString().Should().Be("02/04/2019");
            actual["relationship"].ToString().Should().Be("Child");
            actual["percentage"].ToString().Should().Be("50.52");
        }

        [Fact]
        public async void Get_ShouldReturnSuccessWhenAbleToGetAccountContext()
        {
            const string accountNumber = "123456789";
            var account = _fixture.Create<Account>();
            var json = JsonConvert.SerializeObject(account);
            GetMockHttpForAccountsApi(HttpMethod.Get, accountNumber)
                .Respond(HttpStatusCode.OK, new StringContent(json));

            var response = await CreateRequest($"{GET_ACCOUNT_URL}/{accountNumber}").GetAsync();
            var content = await response.Content.ReadAsStringAsync();
            var accountVieModel = JsonConvert.DeserializeObject<AccountViewModel>(content);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            accountVieModel.Account.AccountNumber.Should().Be(account.AccountNumber);
            accountVieModel.AccountMenu.NumberOfOpenAccounts.Should().Be(account.OpenAccountsCount);
            accountVieModel.AccountMenu.MenuItems.Should().NotBeNullOrEmpty();
        }

        [Fact]
        public async void Get_ShouldReturnUnAuthenticatedWhenAccessTokenMissing()
        {
            var response = await Server.CreateRequest(GET_ACCOUNT_URL)
                .AddAntiForgeryHeader()
                .GetAsync();

            Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        }

        [Fact]
        public async void Get_ShouldReturnUnAuthenticatedWhenAntiForgeryMissing()
        {
            var response = await CreateRequest(GET_ACCOUNT_URL, withAntiForgeryHeader: false).GetAsync();

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }
    }
}