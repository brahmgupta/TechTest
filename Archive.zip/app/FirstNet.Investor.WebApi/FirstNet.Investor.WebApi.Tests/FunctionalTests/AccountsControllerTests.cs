﻿using System;
using AutoFixture;
using FirstNet.Investor.WebApi.Domain.Accounts;
using FluentAssertions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RichardSzalay.MockHttp;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public partial class AccountsControllerTests
    {
        private const string TEST_DATA_PATH = "UnitTests\\Infrastructure\\Services\\AccountMenu\\TestData";
        private readonly int _openAccountsCount;

        [Theory]
        [InlineData(AccountType.Annuity, null, null, "", "")]
        [InlineData(AccountType.Cash, null, null, "", "")]
        [InlineData(AccountType.Pension, null, null, "PP", "")]
        [InlineData(AccountType.Superannuation, null, null, "SF", "name1")]
        [InlineData(AccountType.UnitTrust, null, null, "", "")]
        [InlineData(AccountType.Other, null, null, "", "")]
        [InlineData(AccountType.Superannuation, "FCESUP", "None", "SF", "FirstNet 2")]
        [InlineData(AccountType.Superannuation, "FCESUP", "blah", "SF", "FirstNet 3")]
        [InlineData(AccountType.Superannuation, "FCESUP", "OnlineBroker", "SF", "FirstNet 4")]
        [InlineData(AccountType.Superannuation, "FCESUP", "SelfDirected", "SF", "FirstNet 5")]
        [InlineData(AccountType.Superannuation, "", "SelfDirected", "SF", "FirstNet 6")]
        [InlineData(AccountType.Superannuation, "blah", "SelfDirected", "SF", "FirstNet 7")]
        [InlineData(AccountType.Superannuation, "", "OnlineBroker", "SF", "FirstNet 8")]
        [InlineData(AccountType.Superannuation, "blah", "OnlineBroker", "SF", "FirstNet 9")]
        [InlineData(AccountType.Superannuation, "SUPER", "blah", "SF", "FirstNet 10")]
        [InlineData(AccountType.Cash, "CLREMP", "blah", "CF", "FirstNet 11")]
        [InlineData(AccountType.Cash, "blah", "blah", "CF", "FirstNet 12")]
        public async void ShouldGetAccountMenuItems(AccountType accountType, string productAbbreviation, string dealerType, string productCode, string productName)
        {
            const string accountNumber = "1234567890";
            var account = _fixture.Build<Account>()
                .With(a => a.AccountNumber, accountNumber)
                .With(a => a.AccountType, accountType)
                .With(a => a.ProductCode, productCode)
                .With(a => a.ProductName, productName)
                .With(a => a.ProductAbbreviation, productAbbreviation)
                .With(a => a.DealerType, dealerType)
                .With(a => a.OpenAccountsCount, _openAccountsCount)
                .Create();

            BuildMockForAccountMenu(account);

            var response = await CreateRequest($"{GET_ACCOUNT_URL}/{accountNumber}").GetAsync();
            var jsonResponse = await response.Content.ReadAsStringAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);
            var expectedJson = JObject.Parse(jsonResponse);

            await ValidateAccountMenu(expectedJson, accountType.ToString(), productAbbreviation, dealerType);
        }

        private void BuildMockForAccountMenu(Account account)
        {
            var json = JsonConvert.SerializeObject(account);
            GetMockHttpForAccountsApi(HttpMethod.Get, account.AccountNumber).Respond(HttpStatusCode.OK, new StringContent(json));
        }

        private async Task ValidateAccountMenu(JObject expJson, string accountType, string productAbbreviation, string dealerType)
        {
            var accountMenu = expJson["accountMenu"];
            var menuItems = accountMenu["menuItems"];
            string expectedFilename;
            if (string.IsNullOrWhiteSpace(productAbbreviation) && string.IsNullOrWhiteSpace(dealerType))
            {
                expectedFilename = $"ShouldGetMenuItems_{accountType.ToLower()}.json";
            }
            else if (accountType == "Cash")
            {
               expectedFilename = $"ShouldGetCashAccount_{productAbbreviation.ToLower()}.json";
            }
            else
            {
                expectedFilename = $"ShouldGetSuperannuationMenuItems_{productAbbreviation.ToLower()}_{dealerType.ToLower()}.json";
            }

            var expectedPath = Path.Combine(Directory.GetCurrentDirectory(), TEST_DATA_PATH, expectedFilename);
            var expected = await File.ReadAllTextAsync(expectedPath);
            JToken.DeepEquals(JToken.Parse(expected), JToken.FromObject(menuItems)).Should().BeTrue();
            var numberOfOpenAccounts = Convert.ToInt32(accountMenu["numberOfOpenAccounts"]);
            numberOfOpenAccounts.Should().Be(_openAccountsCount);
        }
    }
}
