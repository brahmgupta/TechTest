﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using AutoFixture;
using FirstNet.Investor.WebApi.Application.CustomerProfile.Models;
using FirstNet.Investor.WebApi.Domain.Customers;
using FirstNet.Investor.WebApi.Domain.Product;
using FirstNet.Investor.WebApi.Infrastructure.Services.Product;
using FirstNet.Investor.WebApi.Tests.FunctionalTests.Setup;
using FirstNet.Investor.WebApi.Tests.Helpers;
using FluentAssertions;
using Newtonsoft.Json;
using RichardSzalay.MockHttp;
using Wealth.Toolkit.Test;
using Xunit;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public class CustomerProfileControllerTests : BaseTests
    {
        private readonly Fixture _fixture;
        private const string GET_CUSTOMER_PROFILE_URL = "api/customerprofile";
        private const string UPDATE_CUSTOMER_PROFILE_URL = "api/customerprofile";

        public CustomerProfileControllerTests()
        {
            _fixture = new Fixture();
            MockCountryApi();
        }

        [Fact]
        public async void Get_ShouldReturnErrorWhenUnableToGetCustomerProfile()
        {
            MockHttp
                .When(HttpMethod.Get, $"{AppSettings.DownstreamSettings.WealthApiCustomerBaseUrl}/api/customers/*")
                .WithQueryString("companyCode", "001")
                .Respond(HttpStatusCode.NotFound, new StringContent("test"));

            var response = await CreateRequest(GET_CUSTOMER_PROFILE_URL, CustomerStepUpClaims).GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.InternalServerError);
        }

        [Fact]
        public async void Get_ShouldReturnForbiddenWhenNotEmulationOrNotSteppedUp()
        {
            MockHttp
                .When(HttpMethod.Get, $"{AppSettings.DownstreamSettings.WealthApiCustomerBaseUrl}/api/customers/*")
                .WithQueryString("companyCode", "001")
                .Respond(HttpStatusCode.NotFound, new StringContent("test"));

            var response = await CreateRequest(GET_CUSTOMER_PROFILE_URL, CustomerClaims).GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.Forbidden);
        }

        [Fact]
        public async void Get_ShouldReturnSuccessWhenAbleToGetCustomerProfile()
        {
            var customer = new Customer
            {
                Surname = "Smith"
            };
            var json = JsonConvert.SerializeObject(customer);
            MockHttp
                .When(HttpMethod.Get, $"{AppSettings.DownstreamSettings.WealthApiCustomerBaseUrl}/api/customers/*")
                .WithQueryString("companyCode", "001")
                .Respond(HttpStatusCode.OK, new StringContent(json));

            var response = await CreateRequest(GET_CUSTOMER_PROFILE_URL, CustomerStepUpClaims).GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.OK);
        }

        [Fact]
        public async void Get_ShouldReturnSuccessWhenAbleToGetCustomerProfileAndIsEmulation()
        {
            var customer = new Customer
            {
                Surname = "Smith"
            };
            var json = JsonConvert.SerializeObject(customer);
            MockHttp
                .When(HttpMethod.Get, $"{AppSettings.DownstreamSettings.WealthApiCustomerBaseUrl}/api/customers/*")
                .WithQueryString("companyCode", "001")
                .Respond(HttpStatusCode.OK, new StringContent(json));

            var response = await CreateRequest(GET_CUSTOMER_PROFILE_URL, StaffClaims).GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.OK);
        }

        [Fact]
        public async void Get_ShouldReturnUnauthorizedWhenAccessTokenMissing()
        {
            var response = await Server.CreateRequest(GET_CUSTOMER_PROFILE_URL)
                .AddAntiForgeryHeader()
                .GetAsync();

            Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        }

        [Fact]
        public async void Get_ShouldReturnForbiddenWhenAntiForgeryMissing()
        {
            var response = await CreateRequest(GET_CUSTOMER_PROFILE_URL, withAntiForgeryHeader:false)
                .GetAsync();

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }

        [Fact]
        public async void Update_ShouldReturnForbiddenWhenAccessTokenMissing()
        {
            var profileViewModel = _fixture.Create<CustomerProfileViewModel>();

            var response = await Server.CreateRequest(UPDATE_CUSTOMER_PROFILE_URL)
                .And(r => r.Content = JsonFormatter.CreateStringContent(profileViewModel))
                .PostAsync();

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }

        [Fact]
        public async void Update_ShouldReturnForbiddenWhenIsEmulation()
        {
            var profileViewModel = _fixture.Create<CustomerProfileViewModel>();

            var response = await CreateRequest(UPDATE_CUSTOMER_PROFILE_URL, StaffClaims)
                .And(r => r.Content = JsonFormatter.CreateStringContent(profileViewModel))
                .PostAsync();

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }

        [Fact]
        public async void Update_ShouldReturnSuccessWhenAbleToUpdateCustomerProfile()
        {
            var profileViewModel = _fixture.Create<CustomerProfileViewModel>();
            var updateCustomerResponse = new UpdateCustomerResponse
            {
                ConfirmationId = "123"
            };
            MockHttp
                .When(HttpMethod.Patch, $"{AppSettings.DownstreamSettings.WealthApiCustomerBaseUrl}/api/customers/*")
                .Respond(HttpStatusCode.OK, JsonFormatter.CreateStringContent(updateCustomerResponse));

            var response = await CreateRequest(UPDATE_CUSTOMER_PROFILE_URL, CustomerStepUpClaims)
                .And(r => r.Content = JsonFormatter.CreateStringContent(profileViewModel))
                .PostAsync();

            response.StatusCode.Should().Be(HttpStatusCode.OK);
        }

        [Fact]
        public async void UpdateCustomer_ShouldReturnForbiddenWhenIsEmulation()
        {
            var response = await CreateRequest(UPDATE_CUSTOMER_PROFILE_URL, StaffClaims)
                .PostAsync();

            response.StatusCode.Should().Be(HttpStatusCode.Forbidden);
        }

        [Theory]
        [ExcelData("FunctionalTests\\TestData\\Entitlements_TestData.xlsx")]
        public async void Get_ShouldEvaluateCustomerProfileIsReadOnlyFromExcelFile(string customerNo, string customerAccessMode, string accountNumbers, string accountsAccessModes, string isCustomerProfileReadOnly, string isAccountReadOnly)
        {
            var accounts = accountNumbers.Replace("-", "").Split(',').ToList();
            var accessModes = accountsAccessModes.Split(',').ToList();

            MockGetCustomerProfileResponse(customerNo, customerAccessMode, accounts, accessModes);

            var response = await CreateRequest(GET_CUSTOMER_PROFILE_URL, CustomerStepUpClaims).GetAsync();
            response.StatusCode.Should().Be(HttpStatusCode.OK);

            var customerProfile = JsonConvert.DeserializeObject<CustomerProfileViewModel>(await response.Content.ReadAsStringAsync());
            customerProfile.IsReadOnly.Should().Be(bool.Parse(isCustomerProfileReadOnly));
            customerProfile.Accounts.Select(p => p.IsReadOnly).Should().BeEquivalentTo(isAccountReadOnly.Split(',').Select(bool.Parse).ToList());
        }

        private void MockGetCustomerProfileResponse(string customerNo, string customerAccessMode, IReadOnlyList<string> accountNos, IReadOnlyList<string> accountModes)
        {
            Enum.TryParse<AccessMode>(customerAccessMode, out var accessMode);

            var accounts = _fixture.Build<Account>().CreateMany(accountNos.Count).ToList();
            for (int i = 0; i < accountNos.Count; i++)
            {
                accounts[i].AccountNumber = accountNos[i];
                accounts[i].AccessMode = Enum.Parse<AccessMode>(accountModes[i]);
            }

            var customerResponse = _fixture.Build<Customer>()
                .With(p => p.CustomerNumber, customerNo)
                .With(p => p.AccessMode, accessMode)
                .With(p => p.Accounts, accounts)
                .Create();

            MockHttp
                .When(HttpMethod.Get, $"{AppSettings.DownstreamSettings.WealthApiCustomerBaseUrl}/api/customers/*")
                .WithQueryString("companyCode", "001")
                .Respond(HttpStatusCode.OK, new StringContent(JsonConvert.SerializeObject(customerResponse)));

            var countries = _fixture.Build<Country>().CreateMany().ToList().AsReadOnly();

            MockHttp
                .When(HttpMethod.Get, $"{AppSettings.DownstreamSettings.ProductApiSettings.BaseUrl}/products/1/countries")
                .WithHeaders("cba-api-key", AppSettings.DownstreamSettings.ProductApiSettings.CbaApiKey)
                .Respond(HttpStatusCode.OK, new StringContent(JsonConvert.SerializeObject(countries)));
        }

        private void MockCountryApi()
        {
            var countries = _fixture.CreateMany<Country>();
            var json = JsonConvert.SerializeObject(countries);
            MockHttp
                .When(HttpMethod.Get, ProductApi.GetCountriesUri(AppSettings.DownstreamSettings.ProductApiSettings.BaseUrl, "1"))
                .WithHeaders("cba-api-key", AppSettings.DownstreamSettings.ProductApiSettings.CbaApiKey)
                .Respond(HttpStatusCode.OK, new StringContent(json));
        }
    }
}