﻿using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AutoFixture;
using FirstNet.Investor.WebApi.Application.SmsAuthentication.Models;
using FirstNet.Investor.WebApi.Domain.Customers;
using FirstNet.Investor.WebApi.Domain.TwoFactorAuthentication;
using FirstNet.Investor.WebApi.Infrastructure.Services.Authentication;
using FirstNet.Investor.WebApi.Infrastructure.Services.Authentication.Models;
using FirstNet.Investor.WebApi.Infrastructure.Services.Customer;
using FirstNet.Investor.WebApi.Infrastructure.Services.SmsAuthentication;
using FirstNet.Investor.WebApi.Tests.FunctionalTests.Setup;
using FluentAssertions;
using Newtonsoft.Json;
using RichardSzalay.MockHttp;
using Wealth.Toolkit.HttpService.HttpService;
using Wealth.Toolkit.Response.Models;
using Xunit;
using Constants = FirstNet.Investor.WebApi.Application.TwoFactorAuthentication.Models.Constants;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public partial class SmsAuthenticationControllerTests : BaseTests
    {
        private const string STATUS_URL = "api/SmsAuthentication/status";

        public SmsAuthenticationControllerTests()
        {
            _fixture = new Fixture();
            _baseUrl = AppSettings.DownstreamSettings.SmsAuthenticationApiSettings.BaseUrl;
            _smsAuthenticationErrorMessages = AppSettings.SmsAuthenticationSettings.ErrorMessages;
            _customerServiceBaseUrl = $"{ AppSettings.DownstreamSettings.WealthApiCustomerBaseUrl}/api/customers";
            _authServiceBaseUrl = AppSettings.DownstreamSettings.AuthenticationApiBaseUrl;
        }

        private readonly string _baseUrl;
        private readonly Dictionary<string, string> _smsAuthenticationErrorMessages;
        private readonly Fixture _fixture;
        private readonly string _customerServiceBaseUrl;
        private readonly string _authServiceBaseUrl;


        [Fact]
        private async void GetSmsStatus_ShouldReturnErrorInvalidResponse()
        {
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.BadRequest, new StringContent("test"));

            var response = await CreateRequest(STATUS_URL).GetAsync();
            var responseBody = await HttpHelper.HandleResponse<Error>(response, false);

            response.StatusCode.Should().Be(HttpStatusCode.InternalServerError);
            responseBody.Code.Should().Be(Common.Constants.ErrorCodes.TwoFactorAuthenticationApiError);
            responseBody.Message.Should().Be(_smsAuthenticationErrorMessages["Error"]);
        }

        [Fact]
        private async void GetSmsStatus_ShouldReturnErrorWhenAnyErrorMessage()
        {
            var statusResponse = new SmsStatusResponse
            {
                IsLocked = false,
                IsRegistered = true,
                Message = _fixture.Create<string>()
            };
            var json = JsonConvert.SerializeObject(statusResponse);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(json));

            var response = await CreateRequest(STATUS_URL).GetAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsStatusViewModel>(response, false);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.Message.Should().Be(statusResponse.Message);
        }

        [Fact]
        private async void GetSmsStatus_ShouldReturnErrorWhenIsLocked()
        {
            var customer = new SmsStatusResponse
            {
                IsLocked = true,
                IsRegistered = true
            };
            var json = JsonConvert.SerializeObject(customer);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(json));

            var response = await CreateRequest(STATUS_URL).GetAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsStatusViewModel>(response, false);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.Locked.Should().BeTrue();
            responseBody.Message.Should()
                .Be(_smsAuthenticationErrorMessages[Constants.SmsAuthenticationCodes.Locked]);
        }

        [Fact]
        private async void GetSmsStatus_ShouldReturnErrorWhenNotRegistered()
        {
            var mockMobileNumber = "";

            var customer = new SmsStatusResponse
            {
                IsRegistered = false,
                Mobile = ""
            };
            var json = JsonConvert.SerializeObject(customer);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(json));

            var customerResponse = _fixture.Create<Customer>();
            customerResponse.ContactDetails.Mobile = mockMobileNumber;

            MockHttp
                .When(HttpMethod.Get, CustomerApi.CreateGetCustomerUri(_customerServiceBaseUrl, "13579", "001"))
                .Respond(HttpStatusCode.OK, new StringContent(JsonConvert.SerializeObject(customerResponse)));

            var response = await CreateRequest(STATUS_URL).GetAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsStatusViewModel>(response, false);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.NotRegistered.Should().BeTrue();
            responseBody.Message.Should()
                .Be(_smsAuthenticationErrorMessages[Constants.SmsAuthenticationCodes.NotRegistered]);
        }

        [Fact]
        private async void GetSmsStatus_ShouldReturnSuccess()
        {
            var statusResponse = new SmsStatusResponse
            {
                IsRegistered = true,
                Mobile = _fixture.Create<string>()
            };
            var json = JsonConvert.SerializeObject(statusResponse);
            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(json));

            var response = await CreateRequest(STATUS_URL).GetAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsStatusViewModel>(response);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.NotRegistered.Should().BeFalse();
            responseBody.Locked.Should().BeFalse();
            responseBody.Message.Should().BeNullOrWhiteSpace();
        }

        [Fact]
        public async void GetSmsStatus_ShouldReturnForbiddenWhenIsEmulation()
        {
            var response = await CreateRequest(STATUS_URL, StaffClaims)
                .GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.Forbidden);
        }

        [Fact]
        public async Task GetSmsStatus_ShouldReturnForbiddenWhenAntiForgeryMissing()
        {
            var response = await CreateRequest(STATUS_URL, withAntiForgeryHeader: false).GetAsync();

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }

        [Fact]
        private async void GetSmsStatus_ShouldAutoRegisterAndReturnSuccessWhenMobileNumberNotRegistered()
        {
            var mockMobileNumber = "0412341234";

            var statusResponse = new SmsStatusResponse
            {
                IsRegistered = false,
                Mobile = ""
            };
            var json = JsonConvert.SerializeObject(statusResponse);

            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(json));

            var customerResponse = _fixture.Create<Customer>();
            customerResponse.ContactDetails.Mobile = mockMobileNumber;

            MockHttp
                .When(HttpMethod.Get, CustomerApi.CreateGetCustomerUri(_customerServiceBaseUrl, "13579", "001"))
                .Respond(HttpStatusCode.OK, new StringContent(JsonConvert.SerializeObject(customerResponse)));

            var smsAuthenticationRequest = new SmsAuthenticationRegisterRequest
            {
                Oin = "12345678",
                Mobile = mockMobileNumber
            };

            MockHttp
                .When(HttpMethod.Post, AuthenticationApi.CreateSmsAuthenticationRegisterUrl(_authServiceBaseUrl))
                .Respond(HttpStatusCode.OK);


            var response = await CreateRequest(STATUS_URL).GetAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsStatusViewModel>(response);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.NotRegistered.Should().BeFalse();
            responseBody.Locked.Should().BeFalse();
            responseBody.Message.Should().BeNullOrWhiteSpace();
        }

        [Fact]
        private async void GetSmsStatus_ShouldReturnNotRegisteredWhenMobileNumberDoesNotExist()
        {
            var mockMobileNumber = "";

            var statusResponse = new SmsStatusResponse
            {
                IsRegistered = false,
                Mobile = ""
            };
            var json = JsonConvert.SerializeObject(statusResponse);

            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(json));

            var customerResponse = _fixture.Create<Customer>();
            customerResponse.ContactDetails.Mobile = mockMobileNumber;

            MockHttp
                .When(HttpMethod.Get, CustomerApi.CreateGetCustomerUri(_customerServiceBaseUrl, "13579", "001"))
                .Respond(HttpStatusCode.OK, new StringContent(JsonConvert.SerializeObject(customerResponse)));

            var response = await CreateRequest(STATUS_URL).GetAsync();
            var responseBody = await HttpHelper.HandleResponse<SmsStatusViewModel>(response);

            response.StatusCode.Should().Be(HttpStatusCode.OK);
            responseBody.NotRegistered.Should().BeTrue();
            responseBody.Locked.Should().BeFalse();
        }

        [Fact]
        private async void GetSmsStatus_ShouldReturnErrorWhenAutoRegistrationFails()
        {
            var mockMobileNumber = "0412341234";

            var statusResponse = new SmsStatusResponse
            {
                IsRegistered = false,
                Mobile = ""
            };
            var json = JsonConvert.SerializeObject(statusResponse);

            MockHttp
                .When(HttpMethod.Get, SmsAuthenticationApi.CreateGetRegistrationStatusUri(_baseUrl))
                .Respond(HttpStatusCode.OK, new StringContent(json));

            var customerResponse = _fixture.Create<Customer>();
            customerResponse.ContactDetails.Mobile = mockMobileNumber;

            MockHttp
                .When(HttpMethod.Get, CustomerApi.CreateGetCustomerUri(_customerServiceBaseUrl, "13579", "001"))
                .Respond(HttpStatusCode.BadRequest, new StringContent(JsonConvert.SerializeObject(customerResponse)));

            var response = await CreateRequest(STATUS_URL).GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.InternalServerError);
        }

    }
}
