﻿using System.IO;
using System.Net;
using System.Threading.Tasks;
using FirstNet.Investor.WebApi.Tests.FunctionalTests.Setup;
using FirstNet.Investor.WebApi.Tests.Helpers;
using FluentAssertions;
using Newtonsoft.Json.Linq;
using NSubstitute;
using Xunit;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public class ContentsControllerTests : BaseTests
    {
        private const string GET_CONTENT_URL = "api/contents";
        private const string CONTENT_PATH = "FunctionalTests\\TestData\\contents.json";

        [Fact]
        public async Task ShouldReturnSuccessWhenAbleToGetContent()
        {
            var response = await CreateRequest($"{GET_CONTENT_URL}/account").GetAsync();
            var actual = await response.Content.ReadAsStringAsync();

            var content = File.ReadAllText(CONTENT_PATH);
            var expected = JObject.Parse(content)["account"];

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            JToken.DeepEquals(JToken.FromObject(expected), JToken.Parse(actual)).Should().BeTrue();
        }

        [Fact]
        public async Task ShouldReturnUnAuthenticatedWhenAccessTokenMissing()
        {
            var response = await Server.CreateRequest(GET_CONTENT_URL)
                .AddAntiForgeryHeader()
                .GetAsync();

            Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        }

        [Fact]
        public async Task ShouldReturnUnAuthenticatedWhenAntiForgeryMissing()
        {
            var response = await CreateRequest(GET_CONTENT_URL, withAntiForgeryHeader: false).GetAsync();

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }
    }
}
