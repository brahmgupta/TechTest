﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using FirstNet.Investor.WebApi.Domain.Accounts;
using FirstNet.Investor.WebApi.Domain.SSO;
using FirstNet.Investor.WebApi.Infrastructure.Services.Accounts;
using FirstNet.Investor.WebApi.Tests.FunctionalTests.Setup;
using FluentAssertions;
using Newtonsoft.Json;
using RichardSzalay.MockHttp;
using Xunit;

namespace FirstNet.Investor.WebApi.Tests.FunctionalTests
{
    public class JumpPageControllerTests : BaseTests
    {
        private string _landingPage = "";
        private string _code = "";
        private const string GET_JUMPPAGE_URL = "jumppage";

        public string Uri => $"{GET_JUMPPAGE_URL}?dst={_landingPage}&code={_code}";

        [Fact]
        public async void Given_AuthAPIReturnsFmsSessionForModernFNI_Then_JumpPage_ShouldReturnRedirectToModernFni()
        {
            _landingPage = "fp/investor/v2/profile/contactdetails/edit";

            MockHttp
                .When(HttpMethod.Get, $"{AppSettings.DownstreamSettings.AuthenticationApiBaseUrl}/api/usersession")
                .WithHeaders("oin", DefaultCustomerNumber)
                .WithHeaders("companyCode", DefaultCompanyCode)
                .WithHeaders("EnforceNew", "true")
                .Respond(HttpStatusCode.OK, new StringContent(DefaultSessionId));

            var response = await CreateRequest(Uri, SsoClaims).GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.Redirect);
            response.Headers.FirstOrDefault(p => p.Key == "Set-Cookie").Value.FirstOrDefault().Should()
                .StartWith("InvestorCookie=");
        }

        [Fact]
        public async void Given_AuthAPIReturnsSSOCodeForStatements_Then_JumpPage_ShouldReturnAFormPostToStatements()
        {
            _landingPage = "statements";
            _code = "dbadafea-1c39-42c2-ac49-a67ea881562c";

            var account = new Account()
            {
                AccountType = AccountType.Superannuation,
                AccountNumber = "1010007758335"
            };
            var accounts = new List<Account>() {account}.AsEnumerable();

            MockHttp
                .When(HttpMethod.Get, $"{AppSettings.DownstreamSettings.AuthenticationApiBaseUrl}/api/ssocode/" + _code+ "/detail")
                .Respond(HttpStatusCode.OK,
                    new StringContent(JsonConvert.SerializeObject(new SSOCode() {Code = Guid.Parse(_code), CustomerNumber = DefaultCustomerNumber, Parameters = "{\"AccountNumber\":\"1010007758335\",\"AccountType\":\"Superannuation\"}" })));

            MockHttp
                .When(HttpMethod.Get, $"{AppSettings.DownstreamSettings.AuthenticationApiBaseUrl}/api/usersession")
                .WithHeaders("oin", DefaultCustomerNumber)
                .WithHeaders("companyCode", DefaultCompanyCode)
                .WithHeaders("EnforceNew", "true")
                .Respond(HttpStatusCode.OK, new StringContent(DefaultSessionId));

            MockHttp
                .When(HttpMethod.Get, $"{AppSettings.DownstreamSettings.WealthApiAccountBaseUrl}/api/accounts")
                .WithHeaders(AccountsConstants.SessionIdHeaderName, DefaultSessionId)
                .WithHeaders(AccountsConstants.CompanyCodeHeaderName, DefaultCompanyCode)
                .WithQueryString("customerNumber", DefaultCustomerNumber)
                .WithQueryString("details", "False")
                .Respond(HttpStatusCode.OK, new StringContent(JsonConvert.SerializeObject(accounts)));

            var response = await CreateRequest(Uri, SsoClaims).GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.OK);
        }

        [Fact]
        public async void Given_AuthAPIReturnsNullParameterSSOCodeForStatements_Then_JumpPage_ShouldRedirectToLogin()
        {
            _landingPage = "statements";
            _code = "dbadafea-1c39-42c2-ac49-a67ea881562c";

            MockHttp
                .When(HttpMethod.Get, $"{AppSettings.DownstreamSettings.AuthenticationApiBaseUrl}/api/ssocode/" + _code + "/detail")
                .Respond(HttpStatusCode.OK,
                    new StringContent(JsonConvert.SerializeObject(new SSOCode() { Code = Guid.Parse(_code)})));

            var response = await CreateRequest(Uri, SsoClaims).GetAsync();

            response.StatusCode.Should().Be(HttpStatusCode.Redirect);
        }
    }
}