﻿using System.Linq;
using System.Security.Claims;
using FirstNet.Investor.WebApi.Common.Settings;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Options;
using Wealth.Lib.InvestorAuthentication.MultiFactorAuth;

namespace FirstNet.Investor.WebApi.Application.CurrentContext
{
    public class CurrentContextProvider : ICurrentContextProvider
    {
        private readonly UpstreamSettings _upstreamSettings;
        private readonly IMultiFactorAuthHandler _multiFactorAuthHandler;
        private readonly IHostingEnvironment _hostingEnvironment;

        public CurrentContextProvider(IOptions<UpstreamSettings> options, IMultiFactorAuthHandler multiFactorAuthHandler, IHostingEnvironment hostingEnvironment)
        {
            _multiFactorAuthHandler = multiFactorAuthHandler;
            _upstreamSettings = options.Value;
            _hostingEnvironment = hostingEnvironment;
        }
        public UserContext GetUserContext(ClaimsPrincipal user)
        {
            var claims = user.Claims.ToDictionary(c => c.Type, c => c.Value);
            return new UserContext
            {
                CompanyCode = claims[UserContext.Claims.CompanyCode],
                CustomerNumber = claims[UserContext.Claims.CustomerNumber],
                SessionId = claims[UserContext.Claims.SessionId],
                FullName = claims[UserContext.Claims.FullName],
                IsEmulation = bool.Parse(claims[UserContext.Claims.IsEmulation]),
                IsSmsAuthenticated = _multiFactorAuthHandler.ValidateMultiFactorClaim(claims, Factor.Sms)
            };
        }

        public ExperienceSettings GetExperienceSettings(UserContext userContext)
        {
            return new ExperienceSettings
            {
                CompanyCode = userContext.CompanyCode,
                FullName = userContext.FullName,
                DataToolsKey = _upstreamSettings.DataToolsKey,
                DataToolsBaseUrl = _upstreamSettings.DataToolsBaseUrl,
                DataToolsTimeout = _upstreamSettings.DataToolsTimeout,
                NewFniBaseUrl = _upstreamSettings.NewFniBaseUrl,
                LogoutUrl = _upstreamSettings.LogoutUrl,
                CfsBaseUrl = _upstreamSettings.CfsBaseUrl,
                AnalyticsEnvironment = _upstreamSettings.AnalyticsEnvironment,
                AnalyticsRSId = _upstreamSettings.AnalyticsRSId,
                AnalyticsVersion = _upstreamSettings.AnalyticsVersion,
                IsEmulation = userContext.IsEmulation,
                IsSmsAuthenticated = userContext.IsSmsAuthenticated,
                EnvironmentName = _hostingEnvironment.EnvironmentName.ToLower()
            };
        }
    }
}
