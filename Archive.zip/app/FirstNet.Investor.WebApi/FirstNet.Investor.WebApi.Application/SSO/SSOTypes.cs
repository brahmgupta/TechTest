﻿namespace FirstNet.Investor.WebApi.Application.SSO
{
    public class SSOTypes
    {
        public const string STATEMENTS = "statements";
        public const string FNI = "fni";
    }
}
