﻿using System;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace FirstNet.Investor.WebApi.Application.Infrastructure
{
    public static class StringExtensions
    {
        private static readonly Regex DigitsOnly = new Regex(@"[^\d]");

        // Creates a TextInfo based on the "en-AU" culture.
        private static readonly TextInfo AuTextInfo = new CultureInfo("en-AU", false).TextInfo;

        public static string ToSentenceCase(this string @this)
        {
            if (string.IsNullOrWhiteSpace(@this))
            {
                return @this;
            }

            var sentence = @this.ToLower();
            return sentence[0].ToString().ToUpper() + sentence.Substring(1);
        }

        public static string ToTitleCase(this string @this)
        {
            return string.IsNullOrWhiteSpace(@this) ? @this : AuTextInfo.ToTitleCase(@this.ToLower());
        }

        public static string SafeJoin(string separator, params string[] value)
        {
            return value == null ? string.Empty : string.Join(separator, value.Where(s => !string.IsNullOrWhiteSpace(s)));
        }

        public static string Masked(this string source, int start, int count)
        {
            return source.Masked('*', start, count);
        }

        public static string Masked(this string source, char maskValue, int start, int count)
        {
            if (string.IsNullOrWhiteSpace(source))
            {
                return source;
            }

            var firstPart = source.Substring(0, start);
            var lastPart = source.Substring(start + count);
            var middlePart = new string(maskValue, count);

            return $"{firstPart}{middlePart}{lastPart}";
        }

        public static string Truncate(this string str, int maxLength)
        {
            return string.IsNullOrEmpty(str) ? str : str.Substring(0, Math.Min(str.Length, maxLength));
        }

        public static string ToDigitsOnly(this string @this)
        {
            var trimmed = @this?.Trim();
            return string.IsNullOrEmpty(trimmed) ? trimmed : DigitsOnly.Replace(trimmed, "");
        }

        public static string Last(this string str, int maxLength)
        {
            if (string.IsNullOrEmpty(str) || str.Length <= maxLength)
            {
                return str;
            }

            return str.Substring(str.Length - maxLength);
        }

        public static string MaskEmailAddress(this string emailAddress, int start, int count, int maskLength)
        {
            if (string.IsNullOrEmpty(emailAddress) || start >= emailAddress.Length)
            {
                return emailAddress;
            }

            var mask = new string('*', maskLength);
            var maskedEmailAddress = emailAddress.Substring(start, count) + mask;
            int position = emailAddress.IndexOf('@');
            if (position >= 0)
            {
                maskedEmailAddress = maskedEmailAddress + emailAddress.Substring(position);
            }

            return maskedEmailAddress;
        }
    }
}
