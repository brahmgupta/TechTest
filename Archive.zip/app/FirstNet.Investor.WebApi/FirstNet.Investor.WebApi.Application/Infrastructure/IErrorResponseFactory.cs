﻿using FluentResults;
using Wealth.Toolkit.Response.Models;

namespace FirstNet.Investor.WebApi.Application.Infrastructure
{
    public interface IErrorResponseFactory
    {
        Response CreateErrorResponse(ResultBase result, string message);
        Response CreateProblemResponse(ResultBase result, string message);
    }
}