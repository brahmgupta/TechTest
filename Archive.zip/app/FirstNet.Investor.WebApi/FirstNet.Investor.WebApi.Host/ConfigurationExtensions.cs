﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Wealth.Toolkit.Configuration;

namespace FirstNet.Investor.WebApi.Host
{
    public static class ConfigurationExtensions
    {
        public static IConfiguration LoadAppSecrets(this IConfiguration config, IHostingEnvironment env)
        {
            var secrets = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsecrets.json", optional: false, reloadOnChange: false)
                .Build();

            config.LoadAppSecrets(secrets);
            return config;
        }
    }
}
