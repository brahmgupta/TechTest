﻿using System.ComponentModel.DataAnnotations;
using System.Threading;
using System.Threading.Tasks;
using FirstNet.Investor.WebApi.Application.Contents.Queries.GetContent;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Wealth.Toolkit.Response.Extensions;
using Wealth.Toolkit.Response.Filters;
using Wealth.Toolkit.Response.Models;

namespace FirstNet.Investor.WebApi.Host.Controllers
{
    public class ContentsController : BaseController
    {
        [HttpGet("{contentKey}", Name = "getContent")]
        [ValidateModelState]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<IActionResult> Get(
            [FromRoute] [Required] string contentKey,
            CancellationToken cancellationToken)
        {
            var response = await Mediator.Send(new GetContentQuery
                {
                    ContentKey = contentKey
                },
                cancellationToken);

            return response.ToActionResult<string>();
        }
    }
}
