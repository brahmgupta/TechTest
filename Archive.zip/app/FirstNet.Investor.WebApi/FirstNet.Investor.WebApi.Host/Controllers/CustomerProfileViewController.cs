﻿using System.Threading;
using System.Threading.Tasks;
using FirstNet.Investor.WebApi.Application.CustomerProfile.Models;
using FirstNet.Investor.WebApi.Application.CustomerProfile.Queries.GetCustomerProfile;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Wealth.Toolkit.Response.Extensions;
using Wealth.Toolkit.Response.Models;

namespace FirstNet.Investor.WebApi.Host.Controllers
{
    public class CustomerProfileViewController : BaseController
    {
        [HttpGet(Name="getCustomerProfileView")]
        [ProducesResponseType(typeof(CustomerProfileViewModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<CustomerProfileViewModel>> Get(CancellationToken cancellationToken)
        {
            var response = await Mediator.Send(new GetCustomerProfileQuery
            {
                CustomerNumber = UserContext.CustomerNumber,
                SessionId = UserContext.SessionId,
                CompanyCode = UserContext.CompanyCode
            }, cancellationToken);

            return response.ToTypedActionResult<CustomerProfileViewModel>();
        }
    }
}
