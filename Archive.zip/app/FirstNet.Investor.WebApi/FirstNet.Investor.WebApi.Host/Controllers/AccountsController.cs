﻿using System.ComponentModel.DataAnnotations;
using System.Threading;
using System.Threading.Tasks;
using FirstNet.Investor.WebApi.Application.Accounts.Commands.UpdateInsurance;
using FirstNet.Investor.WebApi.Application.Accounts.Models;
using FirstNet.Investor.WebApi.Domain.Accounts;
using FirstNet.Investor.WebApi.Application.Accounts.Queries.GetAccount;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Wealth.Toolkit.Response.Extensions;
using Wealth.Toolkit.Response.Filters;
using Wealth.Toolkit.Response.Models;
using FirstNet.Investor.WebApi.Host.Infrastructure.Authorization;
using Microsoft.AspNetCore.Authorization;
using Wealth.Lib.ReleaseFeatureToggles;
using FirstNet.Investor.WebApi.Application.AccountTransactions.Queries.GetAccountTransactions;
using FirstNet.Investor.WebApi.Application.AccountTransactions.Models;

namespace FirstNet.Investor.WebApi.Host.Controllers
{
    public class AccountsController : BaseController
    {
        [HttpGet("{accountNumber}", Name = "getAccount")]
        [ValidateModelState]
        [ProducesResponseType(typeof(AccountViewModel), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<AccountViewModel>> Get(
            [FromRoute][Required]string accountNumber,
            CancellationToken cancellationToken)
        {
            var request = new GetAccountQuery
            {
                AccountNumber = accountNumber,
                SessionId = UserContext.SessionId,
                CustomerNumber = UserContext.CustomerNumber,
                CompanyCode = UserContext.CompanyCode
            };

            var response = await Mediator.Send(request, cancellationToken);

            return response.ToTypedActionResult<AccountViewModel>();
        }

        [HttpGet("{accountNumber}/transactions", Name = "getAccountTransactions")]
        [FeatureToggle(FeatureName = "Transactions")]
        [ValidateModelState]
        [ProducesResponseType(typeof(TransactionViewModel), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public virtual async Task<ActionResult<TransactionViewModel>> GetAccountTransactions(
            [FromRoute][Required]string accountNumber,
            CancellationToken cancellationToken)
        {
            var request = new GetAccountTransactionsQuery
            {
                AccountNumber = accountNumber,
                SessionId = UserContext.SessionId,
                CustomerNumber = UserContext.CustomerNumber,
                CompanyCode = UserContext.CompanyCode
            };

            var response = await Mediator.Send(request, cancellationToken);

            return response.ToTypedActionResult<TransactionViewModel>();
        }

        [HttpPost("{accountNumber}/insurance", Name = "updateInsurance")]
        [Authorize(Policy = AuthorizationPolicyTypes.UpdateDetails)]
        [ProducesResponseType(typeof(UpdateInsuranceResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status403Forbidden)]
        [ProducesResponseType(typeof(Error), StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<UpdateInsuranceResponse>> UpdateInsurance([FromRoute] [Required] string accountNumber, UpdateInsuranceModel insurance, CancellationToken cancellationToken)
        {
            var response = await Mediator.Send(new UpdateInsuranceCommand
            {
                AccountNumber = accountNumber,
                CustomerNumber = UserContext.CustomerNumber,
                SessionId = UserContext.SessionId,
                CompanyCode = UserContext.CompanyCode,
                Insurance = insurance
            }, cancellationToken);

            return response.ToTypedActionResult<UpdateInsuranceResponse>();
        }
    }
}
