﻿namespace FirstNet.Investor.WebApi.Host
{
    public static class Constants
    {
        public static class Headers
        {
            public const string FirstNetCodePurposeHeader = "X-FirstNet-Code-Purpose";
        }
    }
}
