﻿namespace FirstNet.Investor.WebApi.Common
{
    public static class Constants
    {
        public static class ErrorCodes
        {
            public const string NotFound = "NOT_FOUND";
            public const string InvalidRequest = "INVALID_REQUEST";
            public const string ApiError = "API_ERROR";
            public const string TwoFactorAuthenticationApiError = "2FA_API_ERROR";
        }

        public static class DownstreamErrorCodes
        {
            public const string SessionExpired = "SESSION_EXPIRED";
        }

        public static class ProductCodes
        {
            public const string UnitTrust = "UT";
            public const string Pension = "PP";
            public const string Super = "SF";
            public const string CashManagementTrust = "CM";
            public const string CashManagementFund = "CF";
        }
    }
}