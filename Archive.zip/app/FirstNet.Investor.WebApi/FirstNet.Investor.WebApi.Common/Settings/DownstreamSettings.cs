﻿namespace FirstNet.Investor.WebApi.Common.Settings
{
    public class DownstreamSettings
    {
        public string WealthApiAccountBaseUrl { get; set; }
        public string WealthApiCustomerBaseUrl { get; set; }
        public SmsAuthenticationApiSettings SmsAuthenticationApiSettings { get; set; }
        public ProductApiSettings ProductApiSettings { get; set; }
        public string AuthenticationApiBaseUrl { get; set; }
        public string WealthApiAccountTransactionBaseUrl { get; set; }
    }
}