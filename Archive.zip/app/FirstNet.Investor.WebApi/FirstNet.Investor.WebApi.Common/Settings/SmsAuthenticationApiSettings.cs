﻿using System.Collections.Generic;

namespace FirstNet.Investor.WebApi.Common.Settings
{
    public sealed class SmsAuthenticationApiSettings
    {
        public string BaseUrl { get; set; }

        public string ChannelUsername { get; set; }

        public string ChannelPassword { get; set; }

        public string CbaSecApiToken { get; set; }

        public string CbaSecApiReferer { get; set; }

        public string RequestingApplication { get; set; }

        public string ProxyUsername { get; set; }

        public string ProxyPassword { get; set; }

        public string ProxyApiKey { get; set; }

        public string SenderLabel { get; set; }

        public Dictionary<string, string> Messages { get; set; }
    }
}