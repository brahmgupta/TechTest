﻿namespace FirstNet.Investor.WebApi.Common.Settings
{
    public class Logging
    {
        public bool IncludeScopes { get; set; }
        public LogLevel LogLevel { get; set; }
    }
}