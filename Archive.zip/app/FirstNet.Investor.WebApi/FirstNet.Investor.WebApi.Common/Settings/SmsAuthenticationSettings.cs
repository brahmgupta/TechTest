﻿using System.Collections.Generic;

namespace FirstNet.Investor.WebApi.Common.Settings
{
    public class SmsAuthenticationSettings
    {
        public Dictionary<string, string> ErrorMessages { get; set; }
    }
}