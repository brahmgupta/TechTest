﻿namespace FirstNet.Investor.WebApi.Common.Settings
{
    public class LogLevel
    {
        public string Default { get; set; }
        public string System { get; set; }
        public string Microsoft { get; set; }
    }
}