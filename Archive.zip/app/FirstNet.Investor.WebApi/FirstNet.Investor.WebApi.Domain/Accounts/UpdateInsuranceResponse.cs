﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstNet.Investor.WebApi.Domain.Accounts
{
    public class UpdateInsuranceResponse
    {
        public string ConfirmationId { get; set; }
    }
}
