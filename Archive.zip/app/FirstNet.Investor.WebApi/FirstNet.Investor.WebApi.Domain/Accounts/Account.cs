using System;
using System.Collections.Generic;

namespace FirstNet.Investor.WebApi.Domain.Accounts
{
    public class Account
    {
        public string AccountNumber { get; set; }

        public AccountType AccountType { get; set; }

        public string AccountDesignation { get; set; }

        public string ProductName { get; set; }

        public string ProductCode { get; set; }

        public decimal AccountBalance { get; set; }

        public DateTime? EffectiveDate { get; set; }

        public IEnumerable<Beneficiary> Beneficiaries { get; set; }

        public IEnumerable<InvestmentOption> InvestmentOptions { get; set; }

        public Insurance Insurance { get; set; }

        public Status Status { get; set; }

        public string ProductAbbreviation { get; set; }

        public string DealerType { get; set; }

        public int OpenAccountsCount { get; set; }

        public bool IsFirstChoiceEmployerSuper => ProductAbbreviation == "FCESUP";

        public AccessMode AccessMode { get; set; }
    }
}
