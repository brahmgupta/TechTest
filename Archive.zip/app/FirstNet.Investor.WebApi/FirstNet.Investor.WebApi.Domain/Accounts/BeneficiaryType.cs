﻿namespace FirstNet.Investor.WebApi.Domain.Accounts
{
    public enum BeneficiaryType
    {
        Unknown,
        NonLapsing,
        Reversionary,
        Nominated,
        AnnuityNominated,
        AnnuitySubsequent,
        AnnuityReversionary,
        AnnuityReversionaryLifeInsured
    }
}
