﻿using System;

namespace FirstNet.Investor.WebApi.Domain.Accounts
{
    public class UpdateInsurance
    {
        public DateTime? InsuranceElectionDate { get; set; }
        public bool? IsSmoker { get; set; }
    }
}
