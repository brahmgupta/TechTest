﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using FirstNet.Investor.WebApi.Domain.Menu;
using FluentResults;

namespace FirstNet.Investor.WebApi.Domain.Accounts
{
    public interface IAccountMenuService
    {
        Task<Result<IEnumerable<MenuItem>>> GetMenuItems(Account account, string path, CancellationToken cancellationToken = default(CancellationToken));
    }
}