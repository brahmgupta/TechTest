﻿namespace FirstNet.Investor.WebApi.Domain.TwoFactorAuthentication
{
    public class SmsGenerateResponse : IErrorMessage
    {
        public bool Status { get; set; }
        public string Challenge { get; set; }
        public string Message { get; set; }
    }
}