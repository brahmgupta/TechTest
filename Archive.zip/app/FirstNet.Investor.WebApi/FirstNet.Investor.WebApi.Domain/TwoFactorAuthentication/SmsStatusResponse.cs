﻿namespace FirstNet.Investor.WebApi.Domain.TwoFactorAuthentication
{
    public class SmsStatusResponse : IErrorMessage
    {
        public bool IsLocked { get; set; }

        public bool IsRegistered { get; set; }

        public string Mobile { get; set; }

        public string Message { get; set; }

        public bool IsValid=> string.IsNullOrWhiteSpace(Message) && !string.IsNullOrWhiteSpace(Mobile) &&
                                     IsRegistered && !IsLocked;

        public override string ToString()
        {
            return $"IsLocked: {IsLocked} IsRegistered: {IsRegistered} Message: {Message}";
        }
    }
}