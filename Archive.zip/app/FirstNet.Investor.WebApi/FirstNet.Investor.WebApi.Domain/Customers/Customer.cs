﻿using System;
using System.Collections.Generic;

namespace FirstNet.Investor.WebApi.Domain.Customers
{
    public class Customer
    {
        public string CustomerNumber { get; set; }
        public string Title { get; set; }
        public string GivenName { get; set; }
        public string Surname { get; set; }
        public DateTime DateOfBirth { get; set; }
        public Address ResidentialAddress { get; set; }
        public Address MailingAddress { get; set; }
        public ContactDetails ContactDetails { get; set; }
        public IEnumerable<CommunicationPreference> CommunicationPreferences { get; set; }
        public IEnumerable<Account> Accounts { get; set; }
        public string EmployerAndSalarySacrifice { get; set; }
        public AccessMode AccessMode { get; set; }
        public int AccountsCount { get; set; }
    }
}