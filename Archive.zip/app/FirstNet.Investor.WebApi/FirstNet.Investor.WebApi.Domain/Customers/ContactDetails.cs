﻿namespace FirstNet.Investor.WebApi.Domain.Customers
{
    public class ContactDetails
    {
        public string HomePhone { get; set; }
        public string WorkPhone { get; set; }
        public string Mobile { get; set; }
        public string Fax { get; set; }
        public string EmailAddress { get; set; }
    }
}