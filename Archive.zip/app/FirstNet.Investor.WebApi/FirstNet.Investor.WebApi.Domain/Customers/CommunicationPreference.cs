﻿namespace FirstNet.Investor.WebApi.Domain.Customers
{
    public class CommunicationPreference
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }
        public string Value { get; set; }
    }
}