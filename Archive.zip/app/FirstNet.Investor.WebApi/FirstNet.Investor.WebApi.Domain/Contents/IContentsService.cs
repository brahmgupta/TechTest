﻿using System.Threading;
using System.Threading.Tasks;
using FluentResults;

namespace FirstNet.Investor.WebApi.Domain.Content
{
    public interface IContentsService
    {
        Task<Result<string>> GetContent(string contentKey, string filePath,
            CancellationToken cancellationToken = default(CancellationToken));
    }
}