﻿namespace FirstNet.Investor.WebApi.Domain.Menu
{
    public class MenuItem
    {
        public string Key { get; set; }
        public int Order { get; set; }
        public string Label { get; set; }
        public MenuUrl Url { get; set; }
    }
}