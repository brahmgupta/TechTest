﻿namespace FirstNet.Investor.WebApi.Domain.Menu
{
    public class MenuConfigItem
    {
        public string Key { get; set; }
        public int Order { get; set; }
        public string Label { get; set; }
        public MenuUrl[] Urls { get; set; }
        public string Rule { get; set; }
    }
}