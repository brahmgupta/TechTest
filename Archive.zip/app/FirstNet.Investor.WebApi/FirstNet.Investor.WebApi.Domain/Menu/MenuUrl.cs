﻿using System.Collections.Generic;

namespace FirstNet.Investor.WebApi.Domain.Menu
{
    public class MenuUrl
    {
        public string Href { get; set; }
        public string Target { get; set; }
        public string Method { get; set; }
        public Dictionary<string, object> Body { get; set; }
        public string Rule { get; set; }
    }
}