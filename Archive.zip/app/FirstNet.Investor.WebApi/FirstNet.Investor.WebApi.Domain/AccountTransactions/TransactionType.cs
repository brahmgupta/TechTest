﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FirstNet.Investor.WebApi.Domain.AccountTransactions
{
    public enum TransactionType
    {
        Credit = 1,
        Debit = 2,
        Switch = 13
    }
}
