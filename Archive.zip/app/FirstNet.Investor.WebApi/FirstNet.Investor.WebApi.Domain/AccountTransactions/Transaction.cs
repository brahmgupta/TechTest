﻿using System;
using System.Collections.Generic;

namespace FirstNet.Investor.WebApi.Domain.AccountTransactions
{
    public class Transaction
    {
        public DateTime? Date { get; set; }

        public string Description { get; set; }

        public decimal Amount { get; set; }

        public decimal UnitPrice { get; set; }

        public decimal Units { get; set; }

        public decimal UnitBalance { get; set; }

        public bool IsRefunded { get; set; }

        public TransactionRefund Refund { get; set; }

        public decimal Fees { get; set; }

        public decimal Net { get; set; }

        public decimal AccountBalance { get; set; }

        public string Status { get; set; }

        public TransactionRefundType RefundType { get; set; }

        public TransactionType TransactionType { get; set; }

        public int DescriptionCode { get; set; }

        public IEnumerable<TransactionComponent> TransactionComponents { get; set; }
    }
}