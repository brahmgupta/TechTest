﻿using System.Collections.Generic;

namespace FirstNet.Investor.WebApi.Domain.AccountTransactions
{
    public class AccountTransaction
    {
        public string AccountNumber { get; set; }

        public string AccountType { get; set; }

        public bool TransactionLimitReached { get; set; }

        public IEnumerable<Transaction> Transactions { get; set; }
    }
}
